Flat Icon Theme (c) by Kamil Nęcek <http://www.pixelsource.pl>
Flat Icon Theme is licensed under a Creative Commons Attribution 4.0 International License.
You should have received a copy of the license along with this work. If not, see <http://creativecommons.org/licenses/by/4.0/>.
