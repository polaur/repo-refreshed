<?xml version="1.0" ?><!DOCTYPE TS><TS language="lt" version="2.1">
<context>
    <name>Otter::AcceptCookieDialog</name>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="14"/>
        <source>Accept Cookie</source>
        <translation>Priimti slapuką</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="35"/>
        <source>Name:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="45"/>
        <source>Value:</source>
        <translation>Reikšmė:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="55"/>
        <source>Expiration date:</source>
        <translation>Galioja iki:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="69"/>
        <source>Send for:</source>
        <translation>Siųsti:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="83"/>
        <source>Accessible using JavaScript:</source>
        <translation>Prieinamas naudojant JavaScript:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="100"/>
        <source>Domain:</source>
        <translation>Domenas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="47"/>
        <source>Website %1 requested to add new cookie.</source>
        <translation>Svetainė %1 paprašė pridėti naują slapuką.</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="51"/>
        <source>Website %1 requested to update existing cookie.</source>
        <translation>Svetainė %1 paprašė atnaujinti esamą slapuką.</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="55"/>
        <source>Website %1 requested to remove existing cookie.</source>
        <translation>Svetainė %1 paprašė pašalinti esamą slapuką.</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="61"/>
        <source>This session only</source>
        <translation>Tik šiam seansui</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="62"/>
        <source>Secure connections only</source>
        <translation>Tik saugiu ryšiu</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="62"/>
        <source>Any type of connection</source>
        <translation>Bet kokiu ryšiu</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="63"/>
        <source>Yes</source>
        <translation>Taip</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="63"/>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="64"/>
        <source>Accept</source>
        <translation>Priimti</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="68"/>
        <source>Accept For This Session Only</source>
        <translation>Priimti tik šiam seansui</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="71"/>
        <source>Discard</source>
        <translation>Atmesti</translation>
    </message>
</context>
<context>
    <name>Otter::AcceptLanguageDialog</name>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="14"/>
        <source>Preferred Webpage Language</source>
        <translation>Pageidaujama tinklalapių kalba</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="20"/>
        <source>To add language, please choose one from list or type its code.</source>
        <translation>Norėdami pridėti kalbą, pasirinkite ją iš sąrašo arba įrašykite jos kodą.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="39"/>
        <source>Add</source>
        <translation>Pridėti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="82"/>
        <source>Remove</source>
        <translation>Pašalinti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="107"/>
        <source>Move Up</source>
        <translation>Pakelti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="133"/>
        <source>Move Down</source>
        <translation>Nuleisti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="38"/>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="113"/>
        <source>Name</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="38"/>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="113"/>
        <source>Code</source>
        <translation>Kodas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="61"/>
        <source>Unknown [%1]</source>
        <translation>Nežinoma [%1]</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="78"/>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="142"/>
        <source>Any other</source>
        <translation>Bet kokia kita</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="79"/>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="146"/>
        <source>System language (%1 - %2)</source>
        <translation>Sistemos kalba (%1 - %2)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="154"/>
        <source>Custom</source>
        <translation>Tinkinta</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="158"/>
        <source>Unknown</source>
        <translation>Nežinoma</translation>
    </message>
</context>
<context>
    <name>Otter::Action</name>
    <message>
        <location filename="../../src/ui/Action.cpp" line="119"/>
        <source>Creating instance of deprecated action: %1</source>
        <translation>Kuriamas pasenusio veiksmo egzempliorius: %1</translation>
    </message>
</context>
<context>
    <name>Otter::ActionComboBoxWidget</name>
    <message>
        <location filename="../../src/ui/ActionComboBoxWidget.cpp" line="84"/>
        <source>Select Action</source>
        <translation>Pasirinkite veiksmą</translation>
    </message>
    <message>
        <location filename="../../src/ui/ActionComboBoxWidget.cpp" line="155"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
</context>
<context>
    <name>Otter::AdblockContentFiltersProfile</name>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="708"/>
        <source>(Unknown)</source>
        <translation>(Nežinoma)</translation>
    </message>
</context>
<context>
    <name>Otter::AddonsContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Ieškoti...</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="119"/>
        <source>User Scripts</source>
        <translation>Naudotojo scenarijai</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="147"/>
        <source>Select Files</source>
        <translation>Pasirinkite failus</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="147"/>
        <source>User Script files (*.js)</source>
        <translation>Naudotojo scenarijaus failai (*.js)</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="183"/>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="365"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="184"/>
        <source>User Script with this name already exists:
%1</source>
        <translation>Naudotojo scenarijus tokiu pavadinimu jau yra:
%1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="185"/>
        <source>Do you want to replace it?</source>
        <translation>Ar norite jį pakeisti?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="192"/>
        <source>Apply to all</source>
        <translation>Taikyti visiems</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="237"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="237"/>
        <source>Failed to import following User Script file(s):
%1</source>
        <translation><numerusform>Nepavyko importuoti šio naudotojo scenarijaus failo:
%1</numerusform><numerusform>Nepavyko importuoti šių naudotojo scenarijaus failo:
%1</numerusform><numerusform>Nepavyko importuoti šių naudotojo scenarijaus failų:
%1</numerusform><numerusform>Nepavyko importuoti šių naudotojo scenarijaus failų:
%1</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="366"/>
        <source>You are about to irreversibly remove %n addon(s).</source>
        <translation><numerusform>Jūs ketinate negrįžtamai pašalinti %n priedą.</numerusform><numerusform>Jūs ketinate negrįžtamai pašalinti %n priedus.</numerusform><numerusform>Jūs ketinate negrįžtamai pašalinti %n priedų.</numerusform><numerusform>Jūs ketinate negrįžtamai pašalinti %n priedų.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="367"/>
        <source>Do you want to continue?</source>
        <translation>Ar norite tęsti?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="433"/>
        <source>Add Addon…</source>
        <translation>Pridėti priedą...</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="439"/>
        <source>Open Addon File</source>
        <translation>Atverti priedo failą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="440"/>
        <source>Reload Addon</source>
        <translation>Iš naujo įkelti priedą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="444"/>
        <source>Remove Addon…</source>
        <translation>Šalinti priedą…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="485"/>
        <source>Addons</source>
        <translation>Priedai</translation>
    </message>
</context>
<context>
    <name>Otter::AddressCompletionModel</name>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="93"/>
        <source>Search with %1</source>
        <translation>Ieškoti, naudojant %1</translation>
    </message>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="111"/>
        <source>Bookmarks</source>
        <translation>Adresynas</translation>
    </message>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="145"/>
        <source>Local files</source>
        <translation>Vietiniai failai</translation>
    </message>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="161"/>
        <source>History</source>
        <translation>Žurnalas</translation>
    </message>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="176"/>
        <source>Typed history</source>
        <translation>Įvestų adresų žurnalas</translation>
    </message>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="198"/>
        <source>Special pages</source>
        <translation>Specialūs puslapiai</translation>
    </message>
</context>
<context>
    <name>Otter::AddressWidget</name>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="341"/>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="372"/>
        <source>Enter address or search…</source>
        <translation>Įrašykite adresą arba paieškos žodžius…</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="540"/>
        <source>Remove this Icon</source>
        <translation>Šalinti šią piktogramą</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="631"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="662"/>
        <source>Add to Bookmarks</source>
        <translation>Įtraukti į adresyną</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="674"/>
        <source>Add to Start Page</source>
        <translation>Pridėti į pradžios puslapį</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1045"/>
        <source>Show website information</source>
        <translation>Rodyti svetainės informaciją</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1059"/>
        <source>Show feed list</source>
        <translation>Rodyti kanalų sąrašą</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1071"/>
        <source>Remove bookmark</source>
        <translation>Šalinti adresyno įrašą</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1076"/>
        <source>Add bookmark</source>
        <translation>Įtraukti į adresyną</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1085"/>
        <source>Load all plugins on the page</source>
        <translation>Įkelti visus puslapyje esančius papildinius</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1093"/>
        <source>Log in</source>
        <translation>Prisijungti</translation>
    </message>
</context>
<context>
    <name>Otter::Application</name>
    <message>
        <location filename="../../src/core/Application.cpp" line="322"/>
        <location filename="../../src/core/Application.cpp" line="353"/>
        <location filename="../../src/core/Application.cpp" line="442"/>
        <location filename="../../src/core/Application.cpp" line="1017"/>
        <source>Warning</source>
        <translation>Įspėjimas</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="322"/>
        <source>Profile directory (%1) is not writable, application will be running in read-only mode.</source>
        <translation>Profilio katalogas (%1) nėra įrašomas, programa bus vykdoma tik skaitymo veiksenoje.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="345"/>
        <source>Your profile directory (%1) ran out of free disk space.
This may lead to malfunctions or even data loss.</source>
        <translation>Jūsų profilio kataloge (%1) nėra laisvos vietos diske.
Tai gali privesti prie sutrikimų ar net duomenų praradimo.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="349"/>
        <source>Your profile directory (%1) is running low on free disk space (%2 remaining).
This may lead to malfunctions or even data loss.</source>
        <translation>Jūsų profilio kataloge (%1) baigiasi laisva vieta diske (liko %2).
Tai gali privesti prie sutrikimų ar net duomenų praradimo.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="355"/>
        <location filename="../../src/core/Application.cpp" line="1643"/>
        <location filename="../../src/core/Application.cpp" line="1692"/>
        <source>Do you want to continue?</source>
        <translation>Ar norite tęsti?</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="357"/>
        <location filename="../../src/core/Application.cpp" line="1647"/>
        <location filename="../../src/core/Application.cpp" line="1696"/>
        <source>Do not show this message again</source>
        <translation>Daugiau neberodyti šio pranešimo</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="358"/>
        <source>Continue in Read-only Mode</source>
        <translation>Tęsti tik skaitymo veiksenoje</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="360"/>
        <source>Ignore</source>
        <translation>Ignoruoti</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="361"/>
        <source>Quit</source>
        <translation>Išeiti</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="442"/>
        <source>SSL support is not available or incomplete.
Some websites may work incorrectly or do not work at all.</source>
        <translation>SSL palaikymas yra neprieinamas arba neužbaigtas.
Kai kurios svetainės gali veikti neteisingai arba visai neveikti.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="741"/>
        <source>&lt;b&gt;Otter %1&lt;/b&gt;&lt;br&gt;Web browser controlled by the user, not vice-versa.&lt;br&gt;&lt;a href=&quot;https://www.otter-browser.org/&quot;&gt;https://www.otter-browser.org/&lt;/a&gt;</source>
        <translation>&lt;b&gt;Otter %1&lt;/b&gt;&lt;br&gt;Naršyklė, kurią valdo naudotojas, o ne atvirkščiai.&lt;br&gt;&lt;a href=&quot;https://www.otter-browser.org/&quot;&gt;https://www.otter-browser.org/&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="747"/>
        <source>Web backend: %1 %2.</source>
        <translation>Atvaizdavimo varikliukas: %1 %2.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="751"/>
        <source>SSL library not available.</source>
        <translation>SSL biblioteka yra neprieinama.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="755"/>
        <source>SSL library version: %1.</source>
        <translation>SSL bibliotekos versija: %1.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1017"/>
        <source>This session was not saved correctly.
Are you sure that you want to restore this session anyway?</source>
        <translation>Seansas buvo blogai įrašytas.
Ar tikrai norite jį atkurti?</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1171"/>
        <source>New update %1 from %2 channel is available!</source>
        <translation>Yra prieinamas naujas atnaujinimas %1 iš %2 kanalo!</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1641"/>
        <location filename="../../src/core/Application.cpp" line="1690"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/core/Application.cpp" line="1642"/>
        <source>You are about to quit while %n files are still being downloaded.</source>
        <translation><numerusform>Jūs ketinate baigti darbą %n failo atsiuntimo metu.</numerusform><numerusform>Jūs ketinate baigti darbą %n failų atsiuntimo metu.</numerusform><numerusform>Jūs ketinate baigti darbą %n failų atsiuntimo metu.</numerusform><numerusform>Jūs ketinate baigti darbą %n failų atsiuntimo metu.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1649"/>
        <location filename="../../src/core/Application.cpp" line="1698"/>
        <source>Hide</source>
        <translation>Slėpti</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1691"/>
        <source>You are about to quit the current Otter Browser session.</source>
        <translation>Jūs ketinate baigti esamą Otter Naršyklės seansą.</translation>
    </message>
</context>
<context>
    <name>Otter::ApplicationComboBoxWidget</name>
    <message>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="34"/>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="47"/>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="122"/>
        <source>Default Application</source>
        <translation>Numatytoji programa</translation>
    </message>
    <message>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="36"/>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="48"/>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="144"/>
        <source>Other…</source>
        <translation>Kita…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="60"/>
        <source>Select Application</source>
        <translation>Pasirinkite programą</translation>
    </message>
    <message>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="130"/>
        <source>Unknown</source>
        <translation>Nežinoma</translation>
    </message>
</context>
<context>
    <name>Otter::AtomFeedParser</name>
    <message>
        <location filename="../../src/core/FeedParser.cpp" line="215"/>
        <source>Failed to parse feed file: %1</source>
        <translation>Nepavyko išanalizuoti kanalo failo: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedParser.cpp" line="226"/>
        <source>Failed to parse feed: no valid entries found</source>
        <translation>Nepavyko išanalizuoti kanalo: nerasta jokių teisingų įrašų</translation>
    </message>
</context>
<context>
    <name>Otter::AuthenticationDialog</name>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="14"/>
        <source>Authentication Required</source>
        <translation>Prašome prisijungti</translation>
    </message>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="22"/>
        <source>Server:</source>
        <translation>Serveris:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="42"/>
        <source>Message:</source>
        <translation>Pranešimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="62"/>
        <source>User:</source>
        <translation>Abonento vardas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="72"/>
        <source>Password:</source>
        <translation>Slaptažodis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="101"/>
        <source>Remember password</source>
        <translation>Įsiminti slaptažodį</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarkPropertiesDialog</name>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="19"/>
        <source>Title:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="29"/>
        <source>Description:</source>
        <translation>Aprašas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="39"/>
        <source>Address:</source>
        <translation>Adresas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="49"/>
        <source>Folder:</source>
        <translation>Aplankas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="71"/>
        <source>New…</source>
        <translation>Naujas…</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="96"/>
        <source>Visits:</source>
        <translation>Apsilankymai:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="103"/>
        <source>Last visit:</source>
        <translation>Paskutinis apsilankymas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="110"/>
        <source>Created:</source>
        <translation>Sukurta:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="138"/>
        <source>Modified:</source>
        <translation>Keista:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="152"/>
        <source>Keyword:</source>
        <translation>Raktažodis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="50"/>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="51"/>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="62"/>
        <source>Unknown</source>
        <translation>Nežinoma</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="75"/>
        <source>View Bookmark</source>
        <translation>Žiūrėti adresyno įrašą</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="87"/>
        <source>Edit Bookmark</source>
        <translation>Redaguoti</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="116"/>
        <source>Add Bookmark</source>
        <translation>Įtraukti į adresyną</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="159"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="159"/>
        <source>Bookmark with this keyword already exists.</source>
        <translation>Žyma tokiu pačiu raktažodžiu jau yra.</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarkWidget</name>
    <message>
        <location filename="../../src/modules/widgets/bookmark/BookmarkWidget.cpp" line="97"/>
        <source>Title: %1</source>
        <translation>Pavadinimas: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/bookmark/BookmarkWidget.cpp" line="101"/>
        <source>Address: %1</source>
        <translation>Adresas: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/bookmark/BookmarkWidget.cpp" line="106"/>
        <source>Description: %1</source>
        <translation>Aprašas: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/bookmark/BookmarkWidget.cpp" line="111"/>
        <source>Created: %1</source>
        <translation>Sukurta: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/bookmark/BookmarkWidget.cpp" line="116"/>
        <source>Visited: %1</source>
        <translation>Aplankyta: %1</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarksComboBoxWidget</name>
    <message>
        <location filename="../../src/ui/BookmarksComboBoxWidget.cpp" line="43"/>
        <source>Folder Name</source>
        <translation>Aplanko pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksComboBoxWidget.cpp" line="43"/>
        <source>Select name of new folder:</source>
        <translation>Įrašykite naujo aplanko pavadinimą:</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarksContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="85"/>
        <source>Address:</source>
        <translation>Adresas:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="92"/>
        <source>Title:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="99"/>
        <source>Description:</source>
        <translation>Aprašas:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="115"/>
        <source>Keyword:</source>
        <translation>Raktažodis:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="130"/>
        <source>Add</source>
        <translation>Pridėti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="140"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="246"/>
        <source>Properties…</source>
        <translation>Savybės…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="150"/>
        <source>Delete</source>
        <translation>Ištrinti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="50"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="168"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="221"/>
        <source>Add Folder…</source>
        <translation>Pridėti aplanką…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="51"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="169"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="222"/>
        <source>Add Bookmark…</source>
        <translation>Įtraukti į adresyną…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="52"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="170"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="223"/>
        <source>Add Separator</source>
        <translation>Pridėti skirtuką</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Title</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Address</source>
        <translation>Adresas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Description</source>
        <translation>Aprašas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Keyword</source>
        <translation>Raktažodis</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Added</source>
        <translation>Pridėta</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Modified</source>
        <translation>Keista</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Visited</source>
        <translation>Aplankyta</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Visits</source>
        <translation>Apsilankymai</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="160"/>
        <source>Empty Trash</source>
        <translation>Ištuštinti šiukšlinę</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="219"/>
        <source>Add Bookmark</source>
        <translation>Įtraukti į adresyną</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="232"/>
        <source>Restore Bookmark</source>
        <translation>Atkurti adresyno įrašą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="337"/>
        <source>Bookmarks</source>
        <translation>Adresynas</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarksImporterWidget</name>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="17"/>
        <source>Remove existing bookmarks</source>
        <translation>Pašalinti esamus adresyno įrašus</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="51"/>
        <source>Import into folder:</source>
        <translation>Importuoti į aplanką:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="70"/>
        <source>New…</source>
        <translation>Naujas…</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="81"/>
        <source>Allow to duplicate already existing bookmarks</source>
        <translation>Leisti dubliuoti jau esamus adresyno įrašus</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="107"/>
        <source>Import into subfolder</source>
        <translation>Importuoti į poaplankį</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="120"/>
        <source>Leave empty to import into main folder</source>
        <translation>Palikite tuščią, norėdami importuoti į pagrindinį aplanką</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="127"/>
        <source>Subfolder name:</source>
        <translation>Poaplankio pavadinimas:</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarksModel</name>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="155"/>
        <source>Notes</source>
        <translation>Pastabos</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="159"/>
        <source>Bookmarks</source>
        <translation>Adresynas</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="161"/>
        <source>Trash</source>
        <translation>Šiukšlinė</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="185"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="362"/>
        <source>Failed to open notes file: %1</source>
        <translation>Nepavyko atverti pastabų failo: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="362"/>
        <source>Failed to open bookmarks file: %1</source>
        <translation>Nepavyko atverti adresyno failo: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="386"/>
        <source>Failed to load notes file: %1</source>
        <translation>Nepavyko įkelti pastabų failo: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="386"/>
        <source>Failed to load bookmarks file: %1</source>
        <translation>Nepavyko įkelti adresyno failo: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="388"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="388"/>
        <source>Failed to load notes file.</source>
        <translation>Nepavyko įkelti pastabų failo.</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="388"/>
        <source>Failed to load bookmarks file.</source>
        <translation>Nepavyko įkelti adresyno failo.</translation>
    </message>
</context>
<context>
    <name>Otter::CacheContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="97"/>
        <source>Address:</source>
        <translation>Adresas:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="107"/>
        <source>Type:</source>
        <translation>Tipas:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="117"/>
        <source>Size:</source>
        <translation>Dydis:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="127"/>
        <source>Last Modified:</source>
        <translation>Paskutinį kartą pakeista:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="137"/>
        <source>Expires:</source>
        <translation>Galioja iki:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="147"/>
        <source>Location:</source>
        <translation>Vieta:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="168"/>
        <source>Preview</source>
        <translation>Peržiūra</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="207"/>
        <source>Delete</source>
        <translation>Ištrinti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="115"/>
        <source>Address</source>
        <translation>Adresas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="115"/>
        <source>Type</source>
        <translation>Tipas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="115"/>
        <source>Size</source>
        <translation>Dydis</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="115"/>
        <source>Last Modified</source>
        <translation>Paskutinį kartą pakeista</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="115"/>
        <source>Expires</source>
        <translation>Galioja iki</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="368"/>
        <source>Copy Link to Clipboard</source>
        <translation>Kopijuoti saito adresą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="372"/>
        <source>Remove Entry</source>
        <translation>Pašalinti įrašą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="381"/>
        <source>Remove All Entries from This Domain</source>
        <translation>Pašalinti visus domeno įrašus</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="449"/>
        <source>Unknown</source>
        <translation>Nežinoma</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="535"/>
        <source>Cache</source>
        <translation>Podėlis</translation>
    </message>
</context>
<context>
    <name>Otter::CertificateDialog</name>
    <message>
        <location filename="../../src/ui/CertificateDialog.ui" line="17"/>
        <source>Certificate chain:</source>
        <translation>Liudijimų hierarchija:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.ui" line="34"/>
        <source>Certificate fields:</source>
        <translation>Liudijimo laukai:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.ui" line="51"/>
        <source>Field value:</source>
        <translation>Lauko reikšmė:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="44"/>
        <source>Export…</source>
        <translation>Eksportuoti…</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="48"/>
        <source>Invalid Certificate</source>
        <translation>Negaliojantis liudijimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="53"/>
        <source>View Certificate for %1</source>
        <translation>Rodyti &quot;%1&quot; liudijimą</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="62"/>
        <location filename="../../src/ui/CertificateDialog.cpp" line="456"/>
        <source>Unknown</source>
        <translation>Nežinoma</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="116"/>
        <source>Select File</source>
        <translation>Pasirinkti failą</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="116"/>
        <source>DER encoded X.509 certificates (*.der)</source>
        <translation>DER šifruoti X.509 liudijimai (*.der)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="116"/>
        <source>PEM encoded X.509 certificates (*.pem)</source>
        <translation>PEM šifruoti X.509 liudijimai (*.pem)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="116"/>
        <source>Text files (*.txt)</source>
        <translation>Tekstiniai failai (*.txt)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="124"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="124"/>
        <source>Failed to open file for writing.</source>
        <translation>Nepavyko atverti failo rašymui.</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="183"/>
        <source>Authority Key Identifier</source>
        <translation>Liudijimų įstaigos rakto identifikatorius</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="187"/>
        <source>Subject Key Identifier</source>
        <translation>Subjekto rakto identifikatorius</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="191"/>
        <source>Key Usage</source>
        <translation>Rakto naudojimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="195"/>
        <source>Certificate Policies</source>
        <translation>Liudijimo politikos</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="199"/>
        <source>Policy Mappings</source>
        <translation>Politikos atvaizdavimai</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="203"/>
        <source>Subject Alternative Name</source>
        <translation>Subjekto alternatyvusis pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="207"/>
        <source>Issuer Alternative Name</source>
        <translation>Išdavėjo alternatyvusis pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="211"/>
        <source>Subject Directory Attributes</source>
        <translation>Subjekto katalogo atributai</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="215"/>
        <source>Basic Constraints</source>
        <translation>Pagrindiniai apribojimai</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="219"/>
        <source>Name Constraints</source>
        <translation>Pavadinimų apribojimai</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="223"/>
        <source>Policy Constraints</source>
        <translation>Politikos apribojimai</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="227"/>
        <source>Extended Key Usage</source>
        <translation>Išplėstinis rakto naudojimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="231"/>
        <source>CRL Distribution Points</source>
        <translation>CRL skirstomieji punktai</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="235"/>
        <source>Inhibit Any Policy</source>
        <translation>Uždrausti bet kurią politiką</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="239"/>
        <source>Delta CRL Distribution Point</source>
        <translation>Delta CRL skirstomasis punktas</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="243"/>
        <source>Authority Information Access</source>
        <translation>Liudijimų įstaigos informacijos prieiga</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="247"/>
        <source>Subject Information Access</source>
        <translation>Subjekto informacijos prieiga</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="336"/>
        <source>Modulus:
%1

Exponent: %2</source>
        <translation>Modulis:
%1

Skaičiaus eilė: %2</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="349"/>
        <source>Critical</source>
        <translation>Kritinis</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="349"/>
        <source>Not Critical</source>
        <translation>Nekritinis</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="350"/>
        <source>OID: %1</source>
        <translation>OID: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="354"/>
        <source>Value:</source>
        <translation>Reikšmė:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="408"/>
        <source>Version</source>
        <translation>Versija</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="412"/>
        <source>Serial Number</source>
        <translation>Serijos numeris</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="416"/>
        <source>Certificate Signature Algorithm</source>
        <translation>Liudijimo parašo algoritmas</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="420"/>
        <source>Issuer</source>
        <translation>Išdavėjas</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="424"/>
        <source>Validity</source>
        <translation>Galiojimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="428"/>
        <source>Not Before</source>
        <translation>Ne anksčiau</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="432"/>
        <source>Not After</source>
        <translation>Ne vėliau</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="436"/>
        <source>Subject</source>
        <translation>Subjektas</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="440"/>
        <source>Subject Public Key</source>
        <translation>Subjekto viešasis raktas</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="444"/>
        <source>Algorithm</source>
        <translation>Algoritmas</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="448"/>
        <source>Public Key</source>
        <translation>Viešasis raktas</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="452"/>
        <source>Extensions</source>
        <translation>Plėtiniai</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="460"/>
        <source>Fingerprint</source>
        <translation>Kontroliniai kodai</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="464"/>
        <source>SHA-1 Fingerprint</source>
        <translation>SHA-1 kontrolinis kodas</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="468"/>
        <source>SHA-256 Fingerprint</source>
        <translation>SHA-256 kontrolinis kodas</translation>
    </message>
</context>
<context>
    <name>Otter::ClearHistoryDialog</name>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="14"/>
        <source>Clear History</source>
        <translation>Valyti naršymo duomenis</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="35"/>
        <source>Period to clear:</source>
        <translation>Išvalymo laikotarpis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="42"/>
        <source>All</source>
        <translation>Išvalyti viską</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="45"/>
        <source> h</source>
        <translation> val.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="61"/>
        <source>Clear browsing history</source>
        <translation>Išvalyti aplankytų puslapių žurnalą</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="68"/>
        <source>Clear cookies</source>
        <translation>Pašalinti visus slapukus</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="78"/>
        <source>Clear forms history</source>
        <translation>Išvalyti formų duomenis</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="85"/>
        <source>Clear downloads history</source>
        <translation>Išvalyti atsiuntimų žurnalą</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="95"/>
        <source>Clear search history</source>
        <translation>Išvalyti paieškų žurnalą</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="102"/>
        <source>Clear caches</source>
        <translation>Išvalyti visą podėlį</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="112"/>
        <source>Clear websites storage data</source>
        <translation>Išvalyti saitų talpyklų duomenis</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="119"/>
        <source>Clear passwords</source>
        <translation>Pašalinti slaptažodžius</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.cpp" line="54"/>
        <location filename="../../src/ui/ClearHistoryDialog.cpp" line="85"/>
        <source>Clear Now</source>
        <translation>Valyti dabar</translation>
    </message>
</context>
<context>
    <name>Otter::ColorWidget</name>
    <message>
        <location filename="../../src/ui/ColorWidget.cpp" line="56"/>
        <location filename="../../src/ui/ColorWidget.cpp" line="177"/>
        <source>Invalid</source>
        <translation>Blogai nurodyta spalva</translation>
    </message>
    <message>
        <location filename="../../src/ui/ColorWidget.cpp" line="105"/>
        <source>Select Color…</source>
        <translation>Pasirinkti spalvą...</translation>
    </message>
    <message>
        <location filename="../../src/ui/ColorWidget.cpp" line="106"/>
        <source>Copy Color</source>
        <translation>Kopijuoti spalvą</translation>
    </message>
    <message>
        <location filename="../../src/ui/ColorWidget.cpp" line="113"/>
        <source>Clear</source>
        <translation>Išvalyti</translation>
    </message>
</context>
<context>
    <name>Otter::ConfigurationContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="69"/>
        <source>Option Name:</source>
        <translation>Parinkties pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="76"/>
        <source>Current Value:</source>
        <translation>Dabartinė reikšmė:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="83"/>
        <source>Default Value:</source>
        <translation>Numatytoji reikšmė:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="106"/>
        <source>Save All</source>
        <translation>Įrašyti visus</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="116"/>
        <source>Restore Defaults</source>
        <translation>Atkurti numatytuosius</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="212"/>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="262"/>
        <source>Name</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="212"/>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="262"/>
        <source>Type</source>
        <translation>Tipas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="212"/>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="262"/>
        <source>Value</source>
        <translation>Reikšmė</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="290"/>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="363"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="290"/>
        <source>The settings have been changed.
Do you want to save them?</source>
        <translation>Nustatymai buvo pakeisti.
Ar norite juos įrašyti?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="363"/>
        <source>Do you really want to restore default values of all options?</source>
        <translation>Ar tikrai norite atkurti visų parinkčių numatytąsias reikšmes?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="500"/>
        <source>Copy Option Name</source>
        <translation>Kopijuoti parinkties pavadinimą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="501"/>
        <source>Copy Option Value</source>
        <translation>Kopijuoti parinkties reikšmę</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="505"/>
        <source>Save Value</source>
        <translation>Įrašyti reikšmę</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="508"/>
        <source>Restore Default Value</source>
        <translation>Atkurti numatytąją reikšmę</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="517"/>
        <source>Expand All</source>
        <translation>Išskleisti visus</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="518"/>
        <source>Collapse All</source>
        <translation>Suskleisti visus</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="544"/>
        <source>Advanced Configuration</source>
        <translation>Išplėstinė konfigūracija</translation>
    </message>
</context>
<context>
    <name>Otter::ConfigurationOptionWidget</name>
    <message>
        <location filename="../../src/modules/widgets/configurationOption/ConfigurationOptionWidget.cpp" line="46"/>
        <source>Choose option</source>
        <translation>Pasirinkti parinktį</translation>
    </message>
</context>
<context>
    <name>Otter::ContentBlockingDialog</name>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="14"/>
        <source>Content Blocking</source>
        <translation>Turinio blokavimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="24"/>
        <source>General</source>
        <translation>Bendra</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="36"/>
        <source>Profiles</source>
        <translation>Profiliai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="43"/>
        <source>Select lists which you want to use for content blocking (AdBlock Plus compatible):</source>
        <translation>Pasirinkite sąrašus, kuriuos norite naudoti turinio blokavimui (suderinama su AdBlock Plus):</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="76"/>
        <source>Settings</source>
        <translation>Nustatymai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="85"/>
        <source>Cosmetic filters:</source>
        <translation>Kosmetiniai filtrai:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="95"/>
        <source>Enable wildcard expressions</source>
        <translation>Įjungti pakaitos simbolių reiškinius</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="102"/>
        <source>Enable custom rules</source>
        <translation>Įjungti tinkintas taisykles</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="115"/>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="190"/>
        <source>Add</source>
        <translation>Pridėti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="125"/>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="197"/>
        <source>Edit</source>
        <translation>Redaguoti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="135"/>
        <source>Update</source>
        <translation>Atnaujinti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="145"/>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="204"/>
        <source>Remove</source>
        <translation>Pašalinti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="170"/>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="510"/>
        <source>Custom Rules</source>
        <translation>Tinkintos taisyklės</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="183"/>
        <source>All</source>
        <translation>Visi</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="184"/>
        <source>Domain specific only</source>
        <translation>Tik domenams specifiniai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="185"/>
        <source>None</source>
        <translation>Nėra</translation>
    </message>
</context>
<context>
    <name>Otter::ContentBlockingInformationWidget</name>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="45"/>
        <source>Active Profiles</source>
        <translation>Aktyvūs profiliai</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="46"/>
        <source>Blocked Elements</source>
        <translation>Užblokuoti elementai</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="150"/>
        <source>main frame</source>
        <translation>pagrindinis rėmelis</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="154"/>
        <source>subframe</source>
        <translation>po-rėmelis</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="158"/>
        <source>pop-up</source>
        <translation>iškylantysis langas</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="162"/>
        <source>stylesheet</source>
        <translation>stilių aprašas</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="166"/>
        <source>script</source>
        <translation>scenarijus</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="170"/>
        <source>image</source>
        <translation>paveikslas</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="174"/>
        <source>object</source>
        <translation>objektas</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="178"/>
        <source>object subrequest</source>
        <translation>objekto po-užklausa</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="182"/>
        <source>XHR</source>
        <translation>XHR</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="186"/>
        <source>WebSocket</source>
        <translation>WebSocket</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="190"/>
        <source>other</source>
        <translation>kita</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="209"/>
        <source>Enable Content Blocking</source>
        <translation>Įjungti turinio blokavimą</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="339"/>
        <source>Blocked Elements: {amount}</source>
        <translation>Užblokuoti elementai: {amount}</translation>
    </message>
</context>
<context>
    <name>Otter::ContentBlockingIntervalDelegate</name>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="145"/>
        <source> day(s)</source>
        <translation>dieną(-ų)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="146"/>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="166"/>
        <source>Never</source>
        <translation>Niekada</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="166"/>
        <source>%n day(s)</source>
        <translation><numerusform>%n diena</numerusform><numerusform>%n dienos</numerusform><numerusform>%n dienų</numerusform><numerusform>%n dienų</numerusform></translation>
    </message>
</context>
<context>
    <name>Otter::ContentBlockingProfileDialog</name>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="14"/>
        <source>Profile Settings</source>
        <translation>Profilio nustatymai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="22"/>
        <source>Title:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="35"/>
        <source>Category:</source>
        <translation>Kategorija:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="55"/>
        <source>Address:</source>
        <translation>Adresas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="68"/>
        <source>Update interval:</source>
        <translation>Atnaujinimo intervalas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="78"/>
        <source>Never</source>
        <translation>Niekada</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="81"/>
        <source> days</source>
        <translation> dienų</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="91"/>
        <source>Last update:</source>
        <translation>Paskutinis atnaujinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="40"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="77"/>
        <source>Advertisements</source>
        <translation>Reklamos</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="41"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="78"/>
        <source>Annoyance</source>
        <translation>Erzinimai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="42"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="79"/>
        <source>Privacy</source>
        <translation>Privatumas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="43"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="80"/>
        <source>Social</source>
        <translation>Socialiniai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="44"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="81"/>
        <source>Regional</source>
        <translation>Regioniniai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="45"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="82"/>
        <source>Other</source>
        <translation>Kita</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="93"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="114"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="121"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="93"/>
        <source>Valid update URL is required.</source>
        <translation>Reikalingas teisingas atnaujinimo URL.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="114"/>
        <source>Profile with name %1.txt already exists.</source>
        <translation>Profilis pavadinimu %1.txt jau yra.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="121"/>
        <source>Failed to create profile file: %1.</source>
        <translation>Nepavyko sukurti profilio failo: %1.</translation>
    </message>
</context>
<context>
    <name>Otter::ContentBlockingTitleDelegate</name>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="90"/>
        <source>Failed to read profile file</source>
        <translation>Nepavyko perskaityti profilio failo</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="94"/>
        <source>Failed to download profile rules</source>
        <translation>Nepavyko atsisiųsti profilio taisyklių</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="98"/>
        <source>Failed to verify profile rules using checksum</source>
        <translation>Nepavyko patvirtinti profilio taisyklių, naudojant kontrolinę sumą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="107"/>
        <source>Profile was never updated</source>
        <translation>Profilis nebuvo niekada atnaujintas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="111"/>
        <source>Profile was last updated more than one week ago</source>
        <translation>Profilis paskutinį kartą buvo atnaujintas seniau nei prieš savaitę</translation>
    </message>
</context>
<context>
    <name>Otter::ContentFiltersManager</name>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="197"/>
        <source>Custom Rules</source>
        <translation>Tinkintos taisyklės</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="318"/>
        <source>Failed to remove content blocking profile file: %1</source>
        <translation>Nepavyko pašalinti turinio blokavimo profilio failo: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="318"/>
        <source>Unknown</source>
        <translation>Nežinoma</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="353"/>
        <source>Title</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="353"/>
        <source>Update Interval</source>
        <translation>Atnaujinimo intervalas</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="353"/>
        <source>Last Update</source>
        <translation>Paskutinis atnaujinimas</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Advertisements</source>
        <translation>Reklamos</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Annoyance</source>
        <translation>Erzinimai</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Privacy</source>
        <translation>Privatumas</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Social</source>
        <translation>Socialiniai</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Regional</source>
        <translation>Regioniniai</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Other</source>
        <translation>Kita</translation>
    </message>
</context>
<context>
    <name>Otter::ContentsDialog</name>
    <message>
        <location filename="../../src/ui/ContentsDialog.cpp" line="75"/>
        <source>Close</source>
        <translation>Užverti</translation>
    </message>
</context>
<context>
    <name>Otter::ContentsWidget</name>
    <message>
        <location filename="../../src/ui/ContentsWidget.cpp" line="149"/>
        <source>Print Page</source>
        <translation>Spausdinti puslapį</translation>
    </message>
    <message>
        <location filename="../../src/ui/ContentsWidget.cpp" line="166"/>
        <source>Print Preview</source>
        <translation>Spaudinio peržiūra</translation>
    </message>
</context>
<context>
    <name>Otter::CookiePropertiesDialog</name>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="22"/>
        <source>Name:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="38"/>
        <source>Value:</source>
        <translation>Reikšmė:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="51"/>
        <source>Expires:</source>
        <translation>Galioja iki:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="64"/>
        <source>this session only</source>
        <translation>tik šiam seansui</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="71"/>
        <source>MM.dd.yyyy HH:mm</source>
        <comment>Date and time format</comment>
        <translation>yyyy-MM-dd HH:mm</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="81"/>
        <source>Domain:</source>
        <translation>Domenas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="97"/>
        <source>Path:</source>
        <translation>Kelias:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="112"/>
        <source>Send only for secure connections</source>
        <translation>Siųsti tik saugiu ryšiu</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="119"/>
        <source>Allow accessing using JavaScript</source>
        <translation>Leisti priėjimą iš JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.cpp" line="35"/>
        <source>Add Cookie</source>
        <translation>Pridėti slapuką</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.cpp" line="39"/>
        <source>Edit Cookie</source>
        <translation>Redaguoti slapuką</translation>
    </message>
</context>
<context>
    <name>Otter::CookiesContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="99"/>
        <source>Name:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="109"/>
        <source>Value:</source>
        <translation>Reikšmė:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="116"/>
        <source>Expires:</source>
        <translation>Galioja iki:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="126"/>
        <source>Domain:</source>
        <translation>Domenas:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="151"/>
        <source>Path:</source>
        <translation>Kelias:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="165"/>
        <source>Add…</source>
        <translation>Pridėti…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="175"/>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="359"/>
        <source>Properties…</source>
        <translation>Savybės…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="185"/>
        <source>Delete</source>
        <translation>Ištrinti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="201"/>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="222"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="202"/>
        <source>You are about to delete %n cookie(s).</source>
        <translation><numerusform>Jūs ketinate ištrinti %n slapuką.</numerusform><numerusform>Jūs ketinate ištrinti %n slapukus.</numerusform><numerusform>Jūs ketinate ištrinti %n slapukų.</numerusform><numerusform>Jūs ketinate ištrinti %n slapukų.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="203"/>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="224"/>
        <source>Do you want to continue?</source>
        <translation>Ar norite tęsti?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="223"/>
        <source>You are about to delete all cookies.</source>
        <translation>Jūs ketinate ištrinti visus slapukus.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="335"/>
        <source>Add Cookie…</source>
        <translation>Pridėti slapuką…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="346"/>
        <source>Remove All Cookies from This Domain…</source>
        <translation>Šalinti visus domeno slapukus…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="349"/>
        <source>Remove All Cookies…</source>
        <translation>Šalinti visus slapukus…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="423"/>
        <source>this session only</source>
        <translation>tik šiam seansui</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="447"/>
        <source>Cookies</source>
        <translation>Slapukai</translation>
    </message>
</context>
<context>
    <name>Otter::CookiesExceptionsDialog</name>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="14"/>
        <source>Third-party Cookies Exceptions</source>
        <translation>Trečiųjų šalių Slapukų Politika</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="26"/>
        <source>Always ACCEPT third-party cookies from:</source>
        <translation>Svetainės, kurių slapukus PRIIMTI visada:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="44"/>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="106"/>
        <source>Add</source>
        <translation>Pridėti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="51"/>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="113"/>
        <source>Edit</source>
        <translation>Redaguoti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="58"/>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="120"/>
        <source>Remove</source>
        <translation>Pašalinti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="88"/>
        <source>Always REJECT third-party cookies from:</source>
        <translation>Svetainės, kurių slapukų niekada NEPRIIMTI:</translation>
    </message>
</context>
<context>
    <name>Otter::ErrorConsoleWidget</name>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="31"/>
        <source>Scope</source>
        <translation>Sritis</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="60"/>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="163"/>
        <source>Network</source>
        <translation>Tinklas</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="76"/>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="167"/>
        <source>Security</source>
        <translation>Saugumas</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="92"/>
        <source>CSS</source>
        <translation>CSS</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="108"/>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="171"/>
        <source>JS</source>
        <translation>JS</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="124"/>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="175"/>
        <source>Other</source>
        <translation>Kita</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="156"/>
        <source>Clear</source>
        <translation>Išvalyti</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="185"/>
        <source>Filter…</source>
        <translation>Filtras…</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="195"/>
        <source>Close</source>
        <translation>Užverti</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="60"/>
        <source>All Tabs</source>
        <translation>Visos kortelės</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="65"/>
        <source>Current Tab Only</source>
        <translation>Tik esama kortelė</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="71"/>
        <source>Other Sources</source>
        <translation>Kiti šaltiniai</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="181"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;tuščia&gt;</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="272"/>
        <source>Copy</source>
        <translation>Kopijuoti</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="279"/>
        <source>Expand All</source>
        <translation>Išskleisti visus</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="280"/>
        <source>Collapse All</source>
        <translation>Suskleisti visus</translation>
    </message>
</context>
<context>
    <name>Otter::Feed</name>
    <message>
        <location filename="../../src/core/FeedsManager.cpp" line="289"/>
        <source>Feed updated:
%1</source>
        <translation>Kanalas atnaujintas:
%1</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsManager.cpp" line="322"/>
        <source>Failed to parse feed: invalid feed type</source>
        <translation>Nepavyko išanalizuoti kanalo: neteisingas kanalo tipas</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsManager.cpp" line="332"/>
        <source>Failed to download feed</source>
        <translation>Nepavyko atsisiųsti kanalo</translation>
    </message>
</context>
<context>
    <name>Otter::FeedPropertiesDialog</name>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="14"/>
        <source>Edit Feed</source>
        <translation>Taisyti kanalą</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="22"/>
        <source>Folder:</source>
        <translation>Aplankas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="44"/>
        <source>New…</source>
        <translation>Naujas…</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="53"/>
        <source>Title:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="80"/>
        <source>Change Icon…</source>
        <translation>Keisti piktogramą…</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="89"/>
        <source>Address:</source>
        <translation>Adresas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="102"/>
        <source>Update interval:</source>
        <translation>Atnaujinimo intervalas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="112"/>
        <source>Never</source>
        <translation>Niekada</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="115"/>
        <source> minutes</source>
        <translation> minučių</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.cpp" line="50"/>
        <source>Add Feed</source>
        <translation>Pridėti kanalą</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.cpp" line="80"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.cpp" line="80"/>
        <source>Valid address is required.</source>
        <translation>Reikalingas teisingas adresas</translation>
    </message>
</context>
<context>
    <name>Otter::FeedsComboBoxWidget</name>
    <message>
        <location filename="../../src/ui/FeedsComboBoxWidget.cpp" line="41"/>
        <source>Folder Name</source>
        <translation>Aplanko pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedsComboBoxWidget.cpp" line="41"/>
        <source>Select name of new folder:</source>
        <translation>Pasirinkite naujo aplanko pavadinimą:</translation>
    </message>
</context>
<context>
    <name>Otter::FeedsContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.ui" line="67"/>
        <source>OK</source>
        <translation>Gerai</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.ui" line="74"/>
        <source>Cancel</source>
        <translation>Atsisakyti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.ui" line="107"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.ui" line="151"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.ui" line="161"/>
        <source>Categories</source>
        <translation>Kategorijos</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="148"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="535"/>
        <source>Title</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="148"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="535"/>
        <source>From</source>
        <translation>Nuo</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="148"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="535"/>
        <source>Published</source>
        <translation>Paskelbta</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="194"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="195"/>
        <source>You already subscribed this feed.</source>
        <translation>Jūs jau esate užsiprenumeravę šį kanalą.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="196"/>
        <source>Do you want to continue?</source>
        <translation>Ar norite tęsti?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="214"/>
        <source>Select Folder Name</source>
        <translation>Pasirinkite aplanko pavadinimą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="214"/>
        <source>Enter folder name:</source>
        <translation>Įveskite aplanko pavadinimą:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="359"/>
        <source>Open</source>
        <translation>Atverti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="378"/>
        <source>Empty Trash</source>
        <translation>Išvalyti šiukšlinę</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="386"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="411"/>
        <source>Add Folder…</source>
        <translation>Pridėti aplanką…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="387"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="412"/>
        <source>Add Feed…</source>
        <translation>Pridėti kanalą…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="409"/>
        <source>Add New</source>
        <translation>Pridėti naują</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="421"/>
        <source>Restore Feed</source>
        <translation>Atkurti kanalą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="435"/>
        <source>Properties…</source>
        <translation>Savybės…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="477"/>
        <source>Send email to %1</source>
        <translation>Siųsti el. laišką į %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="479"/>
        <source>Go to %1</source>
        <translation>Pereiti į %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="615"/>
        <source>All (%1)</source>
        <translation>Visi (%1)</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="665"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="802"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="733"/>
        <source>Subscribe to this feed using:</source>
        <translation>Prenumeruoti šį kanalą, naudojant:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="802"/>
        <source>Feed: %1</source>
        <translation>Kanalas: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="805"/>
        <source>Feeds</source>
        <translation>Kanalai</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="912"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="921"/>
        <source>Title: %1</source>
        <translation>Pavadinimas: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="912"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="925"/>
        <source>Address: %1</source>
        <translation>Adresas: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="916"/>
        <source>Last update: %1</source>
        <translation>Paskutinis atnaujinimas: %1</translation>
    </message>
</context>
<context>
    <name>Otter::FeedsModel</name>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="57"/>
        <source>Feeds</source>
        <translation>Kanalai</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="59"/>
        <source>Trash</source>
        <translation>Šiukšlinė</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="63"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="230"/>
        <source>Failed to open feeds file: %1</source>
        <translation>Nepavyko atverti kanalų failo: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="253"/>
        <source>Failed to load feeds file: %1</source>
        <translation>Nepavyko įkelti kanalų failo: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="255"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="255"/>
        <source>Failed to load feeds file.</source>
        <translation>Nepavyko įkelti kanalų failo</translation>
    </message>
</context>
<context>
    <name>Otter::FilePasswordsStorageBackend</name>
    <message>
        <location filename="../../src/modules/backends/passwords/file/FilePasswordsStorageBackend.cpp" line="53"/>
        <source>Failed to open passwords file: %1</source>
        <translation>Nepavyko atverti slaptažodžių failo: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/passwords/file/FilePasswordsStorageBackend.cpp" line="109"/>
        <source>Failed to save passwords file: %1</source>
        <translation>Nepavyko įrašyti slaptažodžių failo: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/passwords/file/FilePasswordsStorageBackend.cpp" line="196"/>
        <source>Failed to remove passwords file</source>
        <translation>Nepavyko pašalinti slaptažodžių failo</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/passwords/file/FilePasswordsStorageBackend.cpp" line="325"/>
        <source>Encrypted File</source>
        <translation>Šifruotas failas</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/passwords/file/FilePasswordsStorageBackend.cpp" line="330"/>
        <source>Stores passwords in AES encrypted file.</source>
        <translation>Laiko slaptažodžius AES šifruotame faile.</translation>
    </message>
</context>
<context>
    <name>Otter::FilePathWidget</name>
    <message>
        <location filename="../../src/ui/FilePathWidget.cpp" line="49"/>
        <location filename="../../src/ui/FilePathWidget.cpp" line="74"/>
        <source>Browse…</source>
        <translation>Pasirinkti…</translation>
    </message>
    <message>
        <location filename="../../src/ui/FilePathWidget.cpp" line="88"/>
        <source>Select File</source>
        <translation>Pasirinkti failą</translation>
    </message>
    <message>
        <location filename="../../src/ui/FilePathWidget.cpp" line="88"/>
        <source>Select Directory</source>
        <translation>Pasirinkti aplanką</translation>
    </message>
</context>
<context>
    <name>Otter::FreeDesktopOrgPlatformIntegration</name>
    <message>
        <location filename="../../src/modules/platforms/freedesktoporg/FreeDesktopOrgPlatformIntegration.cpp" line="212"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/freedesktoporg/FreeDesktopOrgPlatformIntegration.cpp" line="216"/>
        <source>Warning</source>
        <translation>Įspėjimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/freedesktoporg/FreeDesktopOrgPlatformIntegration.cpp" line="220"/>
        <source>Information</source>
        <translation>Informacija</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/freedesktoporg/FreeDesktopOrgPlatformIntegration.cpp" line="230"/>
        <source>Notification</source>
        <translation>Pranešimas</translation>
    </message>
</context>
<context>
    <name>Otter::HandlersManager</name>
    <message>
        <location filename="../../src/core/HandlersManager.cpp" line="172"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/core/HandlersManager.cpp" line="172"/>
        <source>Profile with this address already exists.</source>
        <translation>Profilis su šiuo adresu jau yra.</translation>
    </message>
    <message>
        <location filename="../../src/core/HandlersManager.cpp" line="174"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message>
        <location filename="../../src/core/HandlersManager.cpp" line="174"/>
        <source>Do you want to add this content blocking profile?</source>
        <translation>Ar norite pridėti šį turinio blokavimo profilį?</translation>
    </message>
</context>
<context>
    <name>Otter::HeaderViewWidget</name>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="65"/>
        <source>Sorting</source>
        <translation>Rikiavimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="66"/>
        <source>Sort Ascending</source>
        <translation>Rikiuoti didėjimo tvarka</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="71"/>
        <source>Sort Descending</source>
        <translation>Rikiuoti mažėjimo tvarka</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="78"/>
        <source>No Sorting</source>
        <translation>Nerikiuoti</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="91"/>
        <source>Visible Columns</source>
        <translation>Matomi stulpeliai</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="99"/>
        <source>Show All</source>
        <translation>Rodyti visus</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="111"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
</context>
<context>
    <name>Otter::HistoryContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Today</source>
        <translation>Šiandien</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Yesterday</source>
        <translation>Vakar</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Earlier This Week</source>
        <translation>Anksčiau šią savaitę</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Previous Week</source>
        <translation>Praėjusią savaitę</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Earlier This Month</source>
        <translation>Anksčiau šį mėnesį</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Earlier This Year</source>
        <translation>Anksčiau šiais metais</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Older</source>
        <translation>Ankstesnis</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="52"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="93"/>
        <source>Address</source>
        <translation>Adresas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="52"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="93"/>
        <source>Title</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="52"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="93"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="388"/>
        <source>Add to Bookmarks…</source>
        <translation>Įtraukti į adresyną…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="389"/>
        <source>Copy Link to Clipboard</source>
        <translation>Kopijuoti saito adresą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="393"/>
        <source>Remove Entry</source>
        <translation>Pašalinti įrašą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="394"/>
        <source>Remove All Entries from This Domain</source>
        <translation>Pašalinti visus domeno įrašus</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="431"/>
        <source>History</source>
        <translation>Žurnalas</translation>
    </message>
</context>
<context>
    <name>Otter::HistoryEntryItem</name>
    <message>
        <location filename="../../src/core/HistoryModel.cpp" line="58"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
</context>
<context>
    <name>Otter::HistoryModel</name>
    <message>
        <location filename="../../src/core/HistoryModel.cpp" line="90"/>
        <source>Failed to open history file: %1</source>
        <translation>Nepavyko atverti žurnalo failo: %1</translation>
    </message>
</context>
<context>
    <name>Otter::HtmlBookmarksImporter</name>
    <message>
        <location filename="../../src/modules/importers/html/HtmlBookmarksImporter.cpp" line="178"/>
        <source>HTML Bookmarks</source>
        <translation>HTML adresynas</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/html/HtmlBookmarksImporter.cpp" line="183"/>
        <source>Imports bookmarks from HTML file (Netscape format).</source>
        <translation>Importuoja adresyną iš HTML failo (Netscape formatas).</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/html/HtmlBookmarksImporter.cpp" line="228"/>
        <source>HTML files (*.htm *.html)</source>
        <translation>HTML failai (*.htm *.html)</translation>
    </message>
</context>
<context>
    <name>Otter::IconWidget</name>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="37"/>
        <location filename="../../src/ui/IconWidget.cpp" line="51"/>
        <location filename="../../src/ui/IconWidget.cpp" line="76"/>
        <location filename="../../src/ui/IconWidget.cpp" line="86"/>
        <source>Select Icon</source>
        <translation>Pasirinkite piktogramą</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="76"/>
        <source>Images (*.png *.jpg *.bmp *.gif *.svg *.svgz *.ico)</source>
        <translation>Paveikslai (*.png *.jpg *.bmp *.gif *.svg *.svgz *.ico)</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="86"/>
        <source>Icon Name:</source>
        <translation>Piktogramos pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="98"/>
        <source>Select From File…</source>
        <translation>Pasirinkti iš failo...</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="99"/>
        <source>Select From Theme…</source>
        <translation>Pasirinkti iš temos...</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="105"/>
        <source>Reset</source>
        <translation>Atstatyti</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="113"/>
        <source>Clear</source>
        <translation>Išvalyti</translation>
    </message>
</context>
<context>
    <name>Otter::ImagePropertiesDialog</name>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="14"/>
        <source>Image Properties</source>
        <translation>Paveikslo savybės</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="22"/>
        <source>Size:</source>
        <translation>Dydis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="29"/>
        <source>Type:</source>
        <translation>Tipas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="36"/>
        <source>File size:</source>
        <translation>Failo dydis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="43"/>
        <source>Address:</source>
        <translation>Adresas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="50"/>
        <source>Alternative text:</source>
        <translation>Alternatyvusis tekstas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="57"/>
        <source>Long description:</source>
        <translation>Pilnas aprašas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="38"/>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="39"/>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="40"/>
        <source>Unknown</source>
        <translation>Nežinoma</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="70"/>
        <source>%1 x %2 pixels @ %3 bits per pixel in %n frame(s)</source>
        <translation><numerusform>%1 x %2 taškų @ %3 bitų pikselyje %n kadre</numerusform><numerusform>%1 x %2 taškų @ %3 bitų pikselyje %n kadruose</numerusform><numerusform>%1 x %2 taškų @ %3 bitų pikselyje %n kadruose</numerusform><numerusform>%1 x %2 taškų @ %3 bitų pikselyje %n kadruose</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="74"/>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="81"/>
        <source>%1 x %2 pixels @ %3 bits per pixel</source>
        <translation>%1 x %2 taškai @ %3 bitai taškui</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="85"/>
        <source>%1 x %2 pixels</source>
        <translation>%1 x %2 taškų</translation>
    </message>
</context>
<context>
    <name>Otter::ImportDialog</name>
    <message>
        <location filename="../../src/ui/ImportDialog.ui" line="42"/>
        <source>Options</source>
        <translation>Parinktys</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.ui" line="54"/>
        <source>Source:</source>
        <translation>Šaltinis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.ui" line="98"/>
        <source>Results</source>
        <translation>Rezultatai</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.ui" line="123"/>
        <source>Initializing…</source>
        <translation>Inicijuojama…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.ui" line="135"/>
        <source>%p% (%v/%m)</source>
        <translation>%p% (%v/%m)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="125"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="125"/>
        <source>Unable to import selected type.</source>
        <translation>Negalima importuoti pasirinkto tipo.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="158"/>
        <source>Processing…</source>
        <translation>Apdorojama…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="186"/>
        <source>Failed to import data.</source>
        <translation>Nepavyko importuoti duomenų.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="190"/>
        <source>Import cancelled by the user.</source>
        <translation>Naudotojas atsisakė importavimo.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="194"/>
        <source>Import finished successfully.</source>
        <translation>Importavimas sėkmingai užbaigtas.</translation>
    </message>
</context>
<context>
    <name>Otter::JavaScriptPreferencesDialog</name>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="14"/>
        <source>JavaScript Options</source>
        <translation>JavaScript parinktys</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="26"/>
        <source>Allow moving and resizing of windows</source>
        <translation>Leisti langų perkėlimą ir dydžio keitimą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="39"/>
        <source>Allow changing of status field</source>
        <translation>Leisti keisti būsenos lauką</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="49"/>
        <source>Allow script to hide address bar</source>
        <translation>Leisti scenarijui slėpti adreso juostą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="56"/>
        <source>Allow access to clipboard</source>
        <translation>Leisti prieigą prie iškarpinės</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="63"/>
        <source>Allow to receive right mouse button clicks</source>
        <translation>Leisti gauti dešiniojo pelės mygtuko spustelėjimus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="72"/>
        <source>Allow to close windows:</source>
        <translation>Leisti užverti langus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="88"/>
        <source>Allow to enter full screen mode:</source>
        <translation>Leisti įjungti viso ekrano veikseną:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="37"/>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="40"/>
        <source>Ask</source>
        <translation>Klausti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="38"/>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="41"/>
        <source>Always</source>
        <translation>Visada</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="39"/>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="42"/>
        <source>Never</source>
        <translation>Niekada</translation>
    </message>
</context>
<context>
    <name>Otter::KeyboardProfile</name>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="190"/>
        <location filename="../../src/core/ActionsManager.cpp" line="224"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
</context>
<context>
    <name>Otter::KeyboardProfileDialog</name>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="14"/>
        <source>Profile Configuration</source>
        <translation>Profilio konfigūracija</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="24"/>
        <source>Actions</source>
        <translation>Veiksmai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="32"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="71"/>
        <source>Add</source>
        <translation>Pridėti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="81"/>
        <source>Remove</source>
        <translation>Šalinti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="107"/>
        <source>Information</source>
        <translation>Informacija</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="113"/>
        <source>Title:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="123"/>
        <source>Description:</source>
        <translation>Aprašas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="133"/>
        <source>Version:</source>
        <translation>Versija:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="143"/>
        <source>Author:</source>
        <translation>Autorius:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="233"/>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="270"/>
        <source>Status</source>
        <translation>Būsena</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="233"/>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="270"/>
        <source>Action</source>
        <translation>Veiksmas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="233"/>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="270"/>
        <source>Parameters</source>
        <translation>Parametrai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="233"/>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="270"/>
        <source>Shortcut</source>
        <translation>Spartusis klavišas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="390"/>
        <source>This shortcut already used by %1</source>
        <translation>Šis spartusis klavišas jau yra naudojamas veiksmo %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="390"/>
        <source>unknown action</source>
        <translation>nežinomas veiksmas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="401"/>
        <source>This shortcut cannot be used because it would be overriden by a native hotkey used by an editing action</source>
        <translation>Šis spartusis klavišas negali būti naudojamas, nes jis būtų nustelbtas kitos klavišų kombinacijos, kuri yra naudojama redagavimo veiksmui</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="409"/>
        <source>Single key shortcuts are currently disabled</source>
        <translation>Vieno klavišo spartieji klavišai šiuo metu yra išjungti</translation>
    </message>
</context>
<context>
    <name>Otter::LinksContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="252"/>
        <source>Lock Panel</source>
        <translation>Užrakinti skydelį</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="266"/>
        <source>Links</source>
        <translation>Nuorodos</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="318"/>
        <source>Title: %1</source>
        <translation>Pavadinimas: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="321"/>
        <source>Address: %1</source>
        <translation>Adresas: %1</translation>
    </message>
</context>
<context>
    <name>Otter::LocalListingNetworkReply</name>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="61"/>
        <source>Directory does not exist</source>
        <translation>Katalogo nėra</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="66"/>
        <source>Directory is not readable</source>
        <translation>Katalogas yra neskaitomas</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="67"/>
        <source>Cannot read directory listing</source>
        <translation>Nepavyksta perskaityti katalogo sąrašo</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="109"/>
        <source>Directory Contents</source>
        <translation>Aplanko turinys</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="112"/>
        <source>Name</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="113"/>
        <source>Type</source>
        <translation>Tipas</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="114"/>
        <source>Size</source>
        <translation>Dydis</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="115"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
</context>
<context>
    <name>Otter::LocaleDialog</name>
    <message>
        <location filename="../../src/ui/LocaleDialog.ui" line="14"/>
        <source>Switch Application Language</source>
        <translation>Perjungti programos kalbą</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.ui" line="22"/>
        <source>Language:</source>
        <translation>Kalba:</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.ui" line="32"/>
        <source>Custom path:</source>
        <translation>Tinkintas kelias:</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.ui" line="43"/>
        <source>System</source>
        <translation>Sistemos</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.ui" line="48"/>
        <source>Custom</source>
        <translation>Tinkinta</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.cpp" line="47"/>
        <source>Unknown [%1]</source>
        <translation>Nežinoma [%1]</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.cpp" line="72"/>
        <source>Translation files (*.qm)</source>
        <translation>Vertimų failai (*.qm)</translation>
    </message>
</context>
<context>
    <name>Otter::MacPlatformIntegration</name>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="370"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="374"/>
        <source>Warning</source>
        <translation>Įspėjimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="378"/>
        <source>Information</source>
        <translation>Informacija</translation>
    </message>
</context>
<context>
    <name>Otter::MainWindow</name>
    <message>
        <location filename="../../src/ui/MainWindow.cpp" line="832"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/MainWindow.cpp" line="833"/>
        <source>You are about to open %n bookmark(s).</source>
        <translation><numerusform>Jūs ketinate atverti %n adresyno įrašą.</numerusform><numerusform>Jūs ketinate atverti %n adresyno įrašus.</numerusform><numerusform>Jūs ketinate atverti %n adresyno įrašų.</numerusform><numerusform>Jūs ketinate atverti %n adresyno įrašų.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/ui/MainWindow.cpp" line="834"/>
        <source>Do you want to continue?</source>
        <translation>Ar norite tęsti?</translation>
    </message>
    <message>
        <location filename="../../src/ui/MainWindow.cpp" line="838"/>
        <source>Do not show this message again</source>
        <translation>Daugiau neberodyti šio pranešimo</translation>
    </message>
    <message>
        <location filename="../../src/ui/MainWindow.cpp" line="2177"/>
        <source>Empty</source>
        <translation>Tuščias</translation>
    </message>
</context>
<context>
    <name>Otter::MasterPasswordDialog</name>
    <message>
        <location filename="../../src/ui/MasterPasswordDialog.ui" line="14"/>
        <source>Set Master Password</source>
        <translation>Nustatyti pagrindinį slaptažodį</translation>
    </message>
    <message>
        <location filename="../../src/ui/MasterPasswordDialog.ui" line="22"/>
        <source>Current password:</source>
        <translation>Dabartinis slaptažodis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/MasterPasswordDialog.ui" line="32"/>
        <source>New password:</source>
        <translation>Naujas slaptažodis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/MasterPasswordDialog.ui" line="42"/>
        <source>Confirm new password:</source>
        <translation>Patvirtinkite naują slaptažodį:</translation>
    </message>
</context>
<context>
    <name>Otter::Menu</name>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="491"/>
        <location filename="../../src/ui/Menu.cpp" line="580"/>
        <source>Failed to create menu action: %1</source>
        <translation>Nepavyko sukurti meniu veiksmo: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="917"/>
        <source>Window - %1</source>
        <translation>Langas - %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1173"/>
        <location filename="../../src/ui/Menu.cpp" line="1188"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/Menu.cpp" line="1188"/>
        <source>%1 (%n tab(s))</source>
        <translation><numerusform>%1 (%n kortelė)</numerusform><numerusform>%1 (%n kortelės)</numerusform><numerusform>%1 (%n kortelių)</numerusform><numerusform>%1 (%n kortelių)</numerusform></translation>
    </message>
</context>
<context>
    <name>Otter::MenuButtonWidget</name>
    <message>
        <location filename="../../src/modules/widgets/menuButton/MenuButtonWidget.cpp" line="35"/>
        <source>Menu</source>
        <translation>Meniu</translation>
    </message>
</context>
<context>
    <name>Otter::Migrator</name>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="586"/>
        <source>Settings Migration</source>
        <translation>Nustatymų perkėlimas</translation>
    </message>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="589"/>
        <source>Configuration of the components listed below needs to be updated to new version.
Do you want to migrate it?</source>
        <translation>Žemiau išvardintų komponentų konfigūracija turi būti atnaujinta į naują versiją.
Ar norite perkelti konfigūraciją?</translation>
    </message>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="612"/>
        <source>Create backup</source>
        <translation>Sukurti atsarginę kopiją</translation>
    </message>
</context>
<context>
    <name>Otter::MouseProfile</name>
    <message>
        <location filename="../../src/core/GesturesManager.cpp" line="493"/>
        <location filename="../../src/core/GesturesManager.cpp" line="532"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
</context>
<context>
    <name>Otter::MouseProfileDialog</name>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="14"/>
        <source>Profile Configuration</source>
        <translation>Profilio konfigūracija</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="24"/>
        <source>Actions</source>
        <translation>Veiksmai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="30"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="78"/>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="144"/>
        <source>Add</source>
        <translation>Pridėti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="88"/>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="154"/>
        <source>Remove</source>
        <translation>Šalinti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="169"/>
        <source>Move Up</source>
        <translation>Pakelti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="186"/>
        <source>Move Down</source>
        <translation>Nuleisti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="200"/>
        <source>Information</source>
        <translation>Informacija</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="206"/>
        <source>Title:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="216"/>
        <source>Description:</source>
        <translation>Aprašas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="226"/>
        <source>Version:</source>
        <translation>Versija:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="236"/>
        <source>Author:</source>
        <translation>Autorius:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Generic</source>
        <translation>Bendri</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Link</source>
        <translation>Nuorodos</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Editable Content</source>
        <translation>Redaguojamas turinys</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Tab Handle</source>
        <translation>Kortelės ąselė</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Tab Handle of Active Tab</source>
        <translation>Aktyvios kortelės ąselė</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Empty Area of Tab Bar</source>
        <translation>Tuščias kortelės plotas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Any Toolbar</source>
        <translation>Bet kuri įrankių juosta</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="139"/>
        <source>Context and Action</source>
        <translation>Kontekstas ir veiksmas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="139"/>
        <source>Parameters</source>
        <translation>Parametrai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="139"/>
        <source>Steps</source>
        <translation>Žingsniai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="143"/>
        <source>Step</source>
        <translation>Žingsnis</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="201"/>
        <source>Select Action</source>
        <translation>Pasirinkite veiksmą</translation>
    </message>
</context>
<context>
    <name>Otter::NavigationActionWidget</name>
    <message>
        <location filename="../../src/modules/widgets/action/ActionWidget.cpp" line="340"/>
        <source>Remove Entry</source>
        <translation>Pašalinti įrašą</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/action/ActionWidget.cpp" line="343"/>
        <source>Purge Entry</source>
        <translation>Sunaikinti įrašą</translation>
    </message>
</context>
<context>
    <name>Otter::NetworkAutomaticProxy</name>
    <message>
        <location filename="../../src/core/NetworkAutomaticProxy.cpp" line="322"/>
        <location filename="../../src/core/NetworkAutomaticProxy.cpp" line="342"/>
        <source>Failed to load proxy auto-config (PAC): %1</source>
        <translation>Nepavyko įkelti įgaliotojo serverio automatinės konfigūracijos (PAC): %1</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkAutomaticProxy.cpp" line="357"/>
        <source>Failed to load proxy auto-config (PAC). Invalid URL: %1</source>
        <translation>Nepavyko įkelti įgaliotojo serverio automatinės konfigūracijos (PAC). Neteisingas URL: %1</translation>
    </message>
</context>
<context>
    <name>Otter::NetworkManager</name>
    <message>
        <location filename="../../src/core/NetworkManager.cpp" line="125"/>
        <source>Warning</source>
        <translation>Įspėjimas</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkManager.cpp" line="125"/>
        <source>SSL errors occurred:

%1

Do you want to continue?</source>
        <translation>Atsirado SSL klaidų:

%1

Ar norite tęsti?</translation>
    </message>
</context>
<context>
    <name>Otter::NetworkManagerFactory</name>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.cpp" line="708"/>
        <source>Custom</source>
        <translation>Tinkintas</translation>
    </message>
</context>
<context>
    <name>Otter::NotesContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.ui" line="98"/>
        <source>Address:</source>
        <translation>Adresas:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.ui" line="105"/>
        <source>Date:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.ui" line="136"/>
        <source>Add</source>
        <translation>Pridėti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.ui" line="146"/>
        <source>Delete</source>
        <translation>Ištrinti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="48"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="164"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="195"/>
        <source>Add Folder…</source>
        <translation>Pridėti aplanką…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="49"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="165"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="193"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="196"/>
        <source>Add Note</source>
        <translation>Pridėti pastabą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="50"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="166"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="197"/>
        <source>Add Separator</source>
        <translation>Pridėti skirtuką</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="60"/>
        <source>Add note…</source>
        <translation>Pridėti pastabą…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="106"/>
        <source>Select Folder Name</source>
        <translation>Pasirinkite aplanko pavadinimą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="106"/>
        <source>Enter folder name:</source>
        <translation>Įveskite aplanko pavadinimą:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="156"/>
        <source>Empty Trash</source>
        <translation>Ištuštinti šiukšlinę</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="181"/>
        <source>Open source page</source>
        <translation>Atverti šaltinio puslapį</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="206"/>
        <source>Restore Note</source>
        <translation>Atkurti pastabą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="340"/>
        <source>Notes</source>
        <translation>Pastabos</translation>
    </message>
</context>
<context>
    <name>Otter::NotificationDialog</name>
    <message>
        <location filename="../../src/ui/NotificationDialog.cpp" line="74"/>
        <location filename="../../src/ui/NotificationDialog.cpp" line="122"/>
        <source>Close</source>
        <translation>Užverti</translation>
    </message>
</context>
<context>
    <name>Otter::OpenAddressDialog</name>
    <message>
        <location filename="../../src/ui/OpenAddressDialog.ui" line="14"/>
        <source>Go to Page</source>
        <translation>Eiti į puslapį</translation>
    </message>
    <message>
        <location filename="../../src/ui/OpenAddressDialog.ui" line="20"/>
        <source>Enter a web address or choose one from the list:</source>
        <translation>Įveskite saityno adresą arba pasirinkite vieną iš sąrašo:</translation>
    </message>
</context>
<context>
    <name>Otter::OpenBookmarkDialog</name>
    <message>
        <location filename="../../src/ui/OpenBookmarkDialog.ui" line="14"/>
        <source>Go to Bookmark</source>
        <translation>Eiti į adresyno įrašą</translation>
    </message>
    <message>
        <location filename="../../src/ui/OpenBookmarkDialog.ui" line="20"/>
        <source>Enter the keyword of bookmark:</source>
        <translation>Įveskite adresyno įrašo raktažodį:</translation>
    </message>
</context>
<context>
    <name>Otter::OperaBookmarksImporter</name>
    <message>
        <location filename="../../src/modules/importers/opera/OperaBookmarksImporter.cpp" line="51"/>
        <source>Opera Bookmarks</source>
        <translation>Opera adresynas</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaBookmarksImporter.cpp" line="56"/>
        <source>Imports bookmarks from Opera Browser version 12 or earlier</source>
        <translation>Importuoja adresyną iš Opera Naršyklės 12 ar ankstesnės versijos</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaBookmarksImporter.cpp" line="101"/>
        <source>Opera bookmarks files (bookmarks.adr)</source>
        <translation>Opera adresyno failai (bookmarks.adr)</translation>
    </message>
</context>
<context>
    <name>Otter::OperaNotesImporter</name>
    <message>
        <location filename="../../src/modules/importers/opera/OperaNotesImporter.cpp" line="57"/>
        <source>Import into folder:</source>
        <translation>Importuoti į aplanką:</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaNotesImporter.cpp" line="65"/>
        <source>Opera Notes</source>
        <translation>Opera pastabos</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaNotesImporter.cpp" line="70"/>
        <source>Imports notes from Opera Browser version 12 or earlier</source>
        <translation>Importuoja pastabas iš Opera Naršyklės versijos 12 ar ankstesnės</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaNotesImporter.cpp" line="115"/>
        <source>Opera notes files (notes.adr)</source>
        <translation>Opera pastabų failai (notes.adr)</translation>
    </message>
</context>
<context>
    <name>Otter::OperaSearchEnginesImporter</name>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSearchEnginesImporter.cpp" line="45"/>
        <source>Remove existing search engines</source>
        <translation>Šalinti esamas paieškos sistemas</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSearchEnginesImporter.cpp" line="54"/>
        <source>Opera search engines</source>
        <translation>Opera paieškos sistemos</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSearchEnginesImporter.cpp" line="59"/>
        <source>Imports search engines from Opera Browser version 12 or earlier</source>
        <translation>Importuoja paieškos sistemas iš „Opera“ naršyklės 12 ar ankstesnės versijos</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSearchEnginesImporter.cpp" line="105"/>
        <source>Opera search engines files (search.ini)</source>
        <translation>Opera paieškos sistemų failai (search.ini)</translation>
    </message>
</context>
<context>
    <name>Otter::OperaSessionImporter</name>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSessionImporter.cpp" line="44"/>
        <source>Opera Session</source>
        <translation>Opera seansas</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSessionImporter.cpp" line="49"/>
        <source>Imports session from Opera Browser version 12 or earlier</source>
        <translation>Importuoti seansus iš „Opera“ naršyklės 12 ar ankstesnės versijos</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSessionImporter.cpp" line="94"/>
        <source>Opera session files (*.win)</source>
        <translation>Opera seanso failai (*.win)</translation>
    </message>
</context>
<context>
    <name>Otter::OpmlImporter</name>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporter.cpp" line="84"/>
        <source>OPML Feeds</source>
        <translation>OPML kanalai</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporter.cpp" line="89"/>
        <source>Imports feeds from OPML file</source>
        <translation>Importuoti kanalus iš OPML failo</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporter.cpp" line="119"/>
        <source>OPML files (*.opml)</source>
        <translation>OPML failai (*.opml)</translation>
    </message>
</context>
<context>
    <name>Otter::OpmlImporterWidget</name>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporterWidget.ui" line="22"/>
        <source>Import into folder:</source>
        <translation>Importuoti į aplanką:</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporterWidget.ui" line="41"/>
        <source>New…</source>
        <translation>Naujas…</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporterWidget.ui" line="52"/>
        <source>Allow to duplicate already existing feeds</source>
        <translation>Leisti dubliuoti jau esamus kanalus</translation>
    </message>
</context>
<context>
    <name>Otter::OptionWidget</name>
    <message>
        <location filename="../../src/ui/OptionWidget.cpp" line="50"/>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <location filename="../../src/ui/OptionWidget.cpp" line="51"/>
        <source>Yes</source>
        <translation>Taip</translation>
    </message>
    <message>
        <location filename="../../src/ui/OptionWidget.cpp" line="194"/>
        <source>Defaults</source>
        <translation>Numatytieji</translation>
    </message>
</context>
<context>
    <name>Otter::PageInformationContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="42"/>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="110"/>
        <source>Name</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="42"/>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="110"/>
        <source>Value</source>
        <translation>Reikšmė</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="136"/>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="137"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;tuščia&gt;</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="158"/>
        <source>General</source>
        <translation>Bendra</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="164"/>
        <source>Title</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="168"/>
        <source>MIME type</source>
        <translation>MIME tipas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="169"/>
        <source>Document size</source>
        <translation>Dokumento dydis</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="170"/>
        <source>Total size</source>
        <translation>Bendras dydis</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="174"/>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="178"/>
        <source>Number of requests</source>
        <translation>Užklausų skaičius</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="174"/>
        <source>%1 (%n blocked)</source>
        <translation><numerusform>%1 (%n užblokuota)</numerusform><numerusform>%1 (%n užblokuotos)</numerusform><numerusform>%1 (%n užblokuotų)</numerusform><numerusform>%1 (%n užblokuotų)</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="181"/>
        <source>Downloaded</source>
        <translation>Atsisiųsta</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="187"/>
        <source>Headers</source>
        <translation>Antraštės</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="202"/>
        <source>Meta</source>
        <translation>Meta</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="220"/>
        <source>Permissions</source>
        <translation>Leidimai</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="224"/>
        <source>Security</source>
        <translation>Saugumas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="232"/>
        <source>Cipher protocol</source>
        <translation>Šifro protokolas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="233"/>
        <source>Cipher authentication method</source>
        <translation>Šifro tapatybės nustatymo metodas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="234"/>
        <source>Cipher encryption method</source>
        <translation>Šifro šifravimo metodas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="235"/>
        <source>Cipher key exchange method</source>
        <translation>Šifro apsikeitimo raktais metodas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="262"/>
        <source>Page Information</source>
        <translation>Puslapio informacija</translation>
    </message>
</context>
<context>
    <name>Otter::PasswordBarWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.ui" line="61"/>
        <source>Save</source>
        <translation>Įrašyti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.ui" line="68"/>
        <source>Cancel</source>
        <translation>Atsisakyti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.cpp" line="37"/>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.cpp" line="55"/>
        <source>Do you want to update login data for %1?</source>
        <translation>Ar norite atnaujinti prisijungimo duomenis svetainei %1?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.cpp" line="37"/>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.cpp" line="55"/>
        <source>Do you want to save login data for %1?</source>
        <translation>Ar norite įrašyti prisijungimo duomenis svetainei %1?</translation>
    </message>
</context>
<context>
    <name>Otter::PasswordsContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Ieškoti...</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="70"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="77"/>
        <source>Name</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="70"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="77"/>
        <source>Value</source>
        <translation>Reikšmė</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="91"/>
        <source>Set #%1</source>
        <translation>Rinkinys #%1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="179"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="235"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="254"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="180"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="236"/>
        <source>You are about to delete %n password(s).</source>
        <translation><numerusform>Jūs ketinate ištrinti %n slaptažodį.</numerusform><numerusform>Jūs ketinate ištrinti %n slaptažodžius.</numerusform><numerusform>Jūs ketinate ištrinti %n slaptažodžių.</numerusform><numerusform>Jūs ketinate ištrinti %n slaptažodžių.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="181"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="237"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="256"/>
        <source>Do you want to continue?</source>
        <translation>Ar norite tęsti?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="255"/>
        <source>You are about to delete all passwords.</source>
        <translation>Jūs ketinate ištrinti visus slaptažodžius.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="277"/>
        <source>Remove Password</source>
        <translation>Šalinti slaptažodį</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="280"/>
        <source>Remove All Passwords from This Domain…</source>
        <translation>Šalinti visus šio domeno slaptažodžius…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="283"/>
        <source>Remove All Passwords…</source>
        <translation>Šalinti visus slaptažodžius…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="369"/>
        <source>Passwords</source>
        <translation>Slaptažodžiai</translation>
    </message>
</context>
<context>
    <name>Otter::PermissionBarWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.ui" line="62"/>
        <source>Allow this time</source>
        <translation>Leisti šį kartą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.ui" line="67"/>
        <source>Always allow</source>
        <translation>Visada leisti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.ui" line="72"/>
        <source>Always deny</source>
        <translation>Visada drausti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.ui" line="80"/>
        <source>OK</source>
        <translation>Gerai</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.ui" line="87"/>
        <source>Cancel</source>
        <translation>Atsisakyti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="66"/>
        <source>%1 wants to enter full screen mode.</source>
        <translation>%1 nori įjungti viso ekrano veikseną.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="71"/>
        <source>%1 wants access to your location.</source>
        <translation>%1 nori gauti prieigą prie jūsų vietos.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="76"/>
        <source>%1 wants to show notifications.</source>
        <translation>%1 nori rodyti pranešimus.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="81"/>
        <source>%1 wants to lock mouse pointer.</source>
        <translation>%1 nori užrakinti pelės rodyklę.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="86"/>
        <source>%1 wants to access your microphone.</source>
        <translation>%1 nori gauti prieigą prie jūsų mikrofono.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="91"/>
        <source>%1 wants to access your camera.</source>
        <translation>%1 nori gauti prieigą prie jūsų kameros.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="96"/>
        <source>%1 wants to access your microphone and camera.</source>
        <translation>%1 nori gauti prieigą prie jūsų mikrofono ir kameros.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="101"/>
        <source>%1 wants to play audio.</source>
        <translation>%1 nori groti garsą.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="106"/>
        <source>Invalid permission request from %1.</source>
        <translation>Neteisinga leidimo užklausa iš %1.</translation>
    </message>
</context>
<context>
    <name>Otter::PlatformIntegration</name>
    <message>
        <location filename="../../src/core/PlatformIntegration.cpp" line="137"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/core/PlatformIntegration.cpp" line="137"/>
        <source>Failed to install update.</source>
        <translation>Nepavyko įdiegti atnaujinimo.</translation>
    </message>
</context>
<context>
    <name>Otter::PopupsBarWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.ui" line="61"/>
        <source>Details</source>
        <translation>Išsamiau</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.ui" line="71"/>
        <source>Close</source>
        <translation>Užverti</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="62"/>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="70"/>
        <source>%1 wants to open %n pop-up window(s).</source>
        <translation><numerusform>%1 nari atverti %n iškylantįjį langą</numerusform><numerusform>%1 nari atverti %n iškylančiuosius langus</numerusform><numerusform>%1 nori atverti %n iškylančiųjų langų</numerusform><numerusform>%1 nori atverti %n iškylančiųjų langų</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="104"/>
        <source>Open All Pop-Ups from This Website</source>
        <translation>Atidaryti visus šios svetainės iškylančiuosius langus</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="104"/>
        <source>Open Pop-Ups from This Website in Background</source>
        <translation>Atverti iškylančiuosius svetainės langus fone</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="104"/>
        <source>Block All Pop-Ups from This Website</source>
        <translation>Blokuoti visus šios svetainės iškylančiuosius langus</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="104"/>
        <source>Always Ask What to Do for This Website</source>
        <translation>Šiai svetainei visada klausti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="118"/>
        <source>Blocked Pop-ups</source>
        <translation>Užblokuoti iškylantieji langai</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="119"/>
        <source>Open All</source>
        <translation>Atverti visus</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesAdvancedPageWidget</name>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="55"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="374"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="768"/>
        <source>General</source>
        <translation>Bendra</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="62"/>
        <source>Smooth scrolling</source>
        <translation>Glotnus slinkimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="69"/>
        <source>Check spelling</source>
        <translation>Tikrinti rašybą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="82"/>
        <source>Address Field Suggestions</source>
        <translation>Adreso lauko pasiūlymai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="91"/>
        <source>Suggest bookmarks</source>
        <translation>Siūlyti adresyno įrašus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="98"/>
        <source>Suggest history</source>
        <translation>Siūlyti žurnalo įrašus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="108"/>
        <source>Suggest search results</source>
        <translation>Siūlyti paieškos rezultatus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="115"/>
        <source>Local paths</source>
        <translation>Vietiniai keliai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="130"/>
        <source>Address Completion</source>
        <translation>Adresų užbaigimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="139"/>
        <source>Show category headers</source>
        <translation>Rodyti kategorijų pavadinimus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="148"/>
        <source>Display mode:</source>
        <translation>Rodymo veiksena:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="185"/>
        <source>Events</source>
        <translation>Įvykiai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="225"/>
        <source>Play sound:</source>
        <translation>Groti garsą:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="240"/>
        <source>Show notification</source>
        <translation>Rodyti pranešimus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="247"/>
        <source>Mark taskbar entry</source>
        <translation>Žymėti užduočių juostos įrašą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="263"/>
        <source>Options</source>
        <translation>Parinktys</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="270"/>
        <source>Prefer native notifications</source>
        <translation>Teikti pirmenybę saviesiems pranešimams</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="300"/>
        <source>Style</source>
        <translation>Stilius</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="309"/>
        <source>Widget style:</source>
        <translation>Valdiklių stilius:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="319"/>
        <source>Interface style sheet:</source>
        <translation>Sąsajos stilių aprašas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="343"/>
        <source>Other</source>
        <translation>Kita</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="350"/>
        <source>Show tray icon</source>
        <translation>Rodyti dėklo piktogramą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="383"/>
        <source>Images:</source>
        <translation>Paveikslai:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="397"/>
        <source>Enable JavaScript</source>
        <translation>Įjungti JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="404"/>
        <source>JavaScript Options…</source>
        <translation>JavaScript parinktys…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="415"/>
        <source>Plugins:</source>
        <translation>Papildiniai:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="425"/>
        <source>User style sheet:</source>
        <translation>Naudotojo stilių aprašas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="443"/>
        <source>Website Preferences</source>
        <translation>Svetainės nuostatos</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="454"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="481"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="559"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="821"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="904"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1016"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1239"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1392"/>
        <source>Add</source>
        <translation>Pridėti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="491"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="831"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="914"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1249"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1402"/>
        <source>Edit…</source>
        <translation>Redaguoti…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="501"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="569"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="841"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="924"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1026"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1269"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1422"/>
        <source>Remove</source>
        <translation>Pašalinti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="535"/>
        <source>MIME Types</source>
        <translation>MIME tipai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="611"/>
        <source>Show download dialog</source>
        <translation>Rodyti atsiuntimo dialogą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="621"/>
        <source>Save to disk</source>
        <translation>Įrašyti į diską</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="664"/>
        <source>Do not ask for folder, save directly to</source>
        <translation>Neklausti aplanko, įrašyti tiesiai į</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="679"/>
        <source>Open with application</source>
        <translation>Atverti per programą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="725"/>
        <source>Pass web address directly to application</source>
        <translation>Perduoti saityno adresą tiesiogiai programai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="775"/>
        <source>Send referrer information</source>
        <translation>Siųsti adresą iš kurio kreipiamasi</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="788"/>
        <source>User Agent</source>
        <translation>Naršyklės identifikavimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="871"/>
        <source>Proxy</source>
        <translation>Įgaliotasis serveris</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="971"/>
        <source>SSL Ciphers</source>
        <translation>SSL šifrai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1051"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1294"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1447"/>
        <source>Move Up</source>
        <translation>Pakelti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1077"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1320"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1473"/>
        <source>Move Down</source>
        <translation>Nuleisti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1100"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Updates</source>
        <translation>Atnaujinimai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1107"/>
        <source>Select channels from which you want to receive updates:</source>
        <translation>Pasirinkite iš kur norite gauti atnaujinimus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1149"/>
        <source>Check for updates every</source>
        <translation>Tikrinti atnaujinimus kas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1159"/>
        <source>day(s)</source>
        <translation>dieną(-as)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1168"/>
        <source>Install updates automatically</source>
        <translation>Automatiškai įdiegti atnaujinimus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1200"/>
        <source>Keyboard Shortcuts</source>
        <translation>Spartieji klavišai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1259"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1412"/>
        <source>Clone</source>
        <translation>Klonuoti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1333"/>
        <source>Enable single key shortcuts</source>
        <translation>Įjungti pavienio klavišo sparčiuosius klavišus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1353"/>
        <source>Mouse Actions and Gestures</source>
        <translation>Pelės veiksmai ir gestai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1486"/>
        <source>Enable mouse gestures</source>
        <translation>Įjungti pelės gestus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Browsing</source>
        <translation>Naršymas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Notifications</source>
        <translation>Pranešimai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Appearance</source>
        <translation>Išvaizda</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Content</source>
        <translation>Turinys</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Downloads</source>
        <translation>Atsiuntimai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Programs</source>
        <translation>Programos</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>History</source>
        <translation>Žurnalas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Network</source>
        <translation>Tinklas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Security</source>
        <translation>Saugumas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Keyboard</source>
        <translation>Klaviatūra</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Mouse</source>
        <translation>Pelė</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="107"/>
        <source>Compact</source>
        <translation>Kompaktiška</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="108"/>
        <source>Columns</source>
        <translation>Stulpeliai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="115"/>
        <source>WAV files (*.wav)</source>
        <translation>WAV failai (*.wav)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="118"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="186"/>
        <source>Name</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="118"/>
        <source>Description</source>
        <translation>Aprašas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="140"/>
        <source>System Style</source>
        <translation>Sistemos stilius</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="149"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="169"/>
        <source>Style sheets (*.css)</source>
        <translation>Stilių aprašai (*.css)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="152"/>
        <source>All images</source>
        <translation>Visi paveikslai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="153"/>
        <source>Cached images</source>
        <translation>Podėlio paveikslai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="154"/>
        <source>No images</source>
        <translation>Be paveikslų</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="161"/>
        <source>Enabled</source>
        <translation>Įjungta</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="162"/>
        <source>On demand</source>
        <translation>Pareikalavus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="163"/>
        <source>Disabled</source>
        <translation>Išjungta</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="209"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="224"/>
        <source>Title</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="209"/>
        <source>Value</source>
        <translation>Reikšmė</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="217"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="232"/>
        <source>Add Folder…</source>
        <translation>Pridėti aplanką…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="218"/>
        <source>Add User Agent…</source>
        <translation>Pridėti naršyklės identifikavimą…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="219"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="234"/>
        <source>Add Separator</source>
        <translation>Pridėti skirtuką</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="233"/>
        <source>Add Proxy…</source>
        <translation>Pridėti įgaliotąjį serverį…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="291"/>
        <source>Stable version</source>
        <translation>Stabili versija</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="291"/>
        <source>Beta version</source>
        <translation>Beta versija</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="291"/>
        <source>Weekly development version</source>
        <translation>Savaitinė aktyviai kuriama versija</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="339"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="375"/>
        <source>New…</source>
        <translation>Naują…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="340"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="376"/>
        <source>Readd</source>
        <translation>Pridėti iš naujo</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="576"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1265"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1460"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="576"/>
        <source>Do you really want to remove preferences for this website?</source>
        <translation>Ar tikrai norite pašalinti šios svetainės nuostatas?</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="594"/>
        <source>MIME Type Name</source>
        <translation>MIME tipo pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="594"/>
        <source>Select name of MIME Type:</source>
        <translation>Pasirinkite MIME tipo pavadinimą:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="614"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="614"/>
        <source>Invalid MIME Type name.</source>
        <translation>Neteisingas MIME tipo pavadinimas.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="739"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="801"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="905"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="967"/>
        <source>Folder Name</source>
        <translation>Aplanko pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="739"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="801"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="905"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="967"/>
        <source>Select folder name:</source>
        <translation>Pasirinkite aplanko pavadinimą:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="743"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="767"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="805"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="822"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="909"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="934"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="971"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="987"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1156"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1351"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="757"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="923"/>
        <source>Custom</source>
        <translation>Tinkintas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1266"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1461"/>
        <source>Do you really want to remove this profile?</source>
        <translation>Ar tikrai norite pašalinti šį profilį?</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1275"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1470"/>
        <source>Delete profile permanently</source>
        <translation>Ištrinti profilį visam laikui</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesContentPageWidget</name>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="23"/>
        <source>Blocking</source>
        <translation>Blokavimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="35"/>
        <source>Pop-ups:</source>
        <translation>Iškylantieji langai:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="56"/>
        <source>Zoom</source>
        <translation>Mastelis</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="68"/>
        <source>Default zoom:</source>
        <translation>Numatytasis mastelis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="78"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="96"/>
        <source>Zoom text only</source>
        <translation>Keisti tik teksto mastelį</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="109"/>
        <source>Fonts</source>
        <translation>Šriftai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="143"/>
        <source>Default proportional font size:</source>
        <translation>Numatytasis proporcionalusis šrifto dydis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="153"/>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="179"/>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="208"/>
        <source> px</source>
        <translation>tšk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="169"/>
        <source>Default fixed-width font size:</source>
        <translation>Numatytasis lygiapločio šrifto dydis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="195"/>
        <source>Minimum font size:</source>
        <translation>Mažiausias šrifto dydis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="205"/>
        <source>None</source>
        <translation>Nėra</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="229"/>
        <source>Colors</source>
        <translation>Spalvos</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="119"/>
        <source>Ask</source>
        <translation>Klausti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="120"/>
        <source>Block all</source>
        <translation>Visus blokuoti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="121"/>
        <source>Open all</source>
        <translation>Visus atverti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="122"/>
        <source>Open all in background</source>
        <translation>Visus atverti fone</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="134"/>
        <source>Style</source>
        <translation>Stilius</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="134"/>
        <source>Font</source>
        <translation>Šriftas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="134"/>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="157"/>
        <source>Preview</source>
        <translation>Peržiūra</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Standard font</source>
        <translation>Standartinis šriftas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Fixed-width font</source>
        <translation>Lygiaplotis šriftas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Serif font</source>
        <translation>Serifinis šriftas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Sans-serif font</source>
        <translation>Neserifinis šriftas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Cursive font</source>
        <translation>Rankraštinis šriftas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Fantasy font</source>
        <translation>Fantasy šriftas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="143"/>
        <source>The quick brown fox jumps over the lazy dog</source>
        <translation>Įlinkusi fechtuotojo špaga blykčiodama gręžė apvalų arbūzą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="157"/>
        <source>Type</source>
        <translation>Tipas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="161"/>
        <source>Background Color</source>
        <translation>Fono spalva</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="161"/>
        <source>Text Color</source>
        <translation>Teksto spalva</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="161"/>
        <source>Link Color</source>
        <translation>Nuorodos spalva</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="161"/>
        <source>Visited Link Color</source>
        <translation>Lankytų nuorodų spalva</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesDialog</name>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="17"/>
        <source>Preferences</source>
        <translation>Nuostatos</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="27"/>
        <source>General</source>
        <translation>Pagrindinės</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="33"/>
        <source>Content</source>
        <translation>Turinys</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="39"/>
        <source>Privacy</source>
        <translation>Privatumas</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="45"/>
        <source>Search</source>
        <translation>Paieška</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="51"/>
        <source>Advanced</source>
        <translation>Kitos</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="62"/>
        <source>All Settings</source>
        <translation>Visi nustatymai</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesGeneralPageWidget</name>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="23"/>
        <source>Startup</source>
        <translation>Paleistis</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="35"/>
        <source>Startup behavior:</source>
        <translation>Paleidus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="48"/>
        <source>Home page:</source>
        <translation>Pradinis puslapis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="76"/>
        <source>Use Current Page</source>
        <translation>Naudoti esamą puslapį</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="83"/>
        <source>Use Bookmark</source>
        <translation>Naudoti adresyno įrašą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="90"/>
        <source>Restore to Default</source>
        <translation>Atkurti numatytuosius</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="99"/>
        <source>Do not load the tab contents until selected</source>
        <translation>Neįkelti kortelės turinio tol, kol ji nepasirinkta</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="114"/>
        <source>Downloads</source>
        <translation>Atsiuntimai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="126"/>
        <source>Save files to:</source>
        <translation>Atsiuntimų aplankas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="141"/>
        <source>Always ask me where to save files</source>
        <translation>Visada klausti kur įrašyti failus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="154"/>
        <source>Tabs</source>
        <translation>Kortelės</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="161"/>
        <source>Open new windows in new tabs instead</source>
        <translation>Vietoje naujų langų atverti naujas korteles</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="168"/>
        <source>Reuse current tab</source>
        <translation>Iš naujo naudoti esamą kortelę</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="175"/>
        <source>Open new tab next to active</source>
        <translation>Naują kortelę atverti šalia aktyvios</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="184"/>
        <source>When closing tab:</source>
        <translation>Užveriant kortelę:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="198"/>
        <source>Activate the last active tab</source>
        <translation>Aktyvinti paskutinę aktyvią kortelę</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="203"/>
        <source>Activate the next tab</source>
        <translation>Aktyvinti šalia esančią kortelę</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="208"/>
        <source>Activate the first tab opened from current tab</source>
        <translation>Aktyvinti pirmą kortelę atidarytą iš aktyvios kortelės</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="224"/>
        <source>Language</source>
        <translation>Kalba</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="233"/>
        <source>Preferred webpage language:</source>
        <translation>Pageidaujama tinklalapių kalba:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="258"/>
        <source>Edit…</source>
        <translation>Redaguoti…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="275"/>
        <source>System Defaults</source>
        <translation>Sistemos numatyta</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="287"/>
        <source>Set as a default browser</source>
        <translation>Nustatyti kaip numatytąją naršyklę</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.cpp" line="45"/>
        <source>Show windows and tabs from the last time</source>
        <translation>Rodyti langus ir korteles iš praeito karto</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.cpp" line="46"/>
        <source>Show startup dialog</source>
        <translation>Rodyti paleisties dialogą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.cpp" line="47"/>
        <source>Show home page</source>
        <translation>Rodyti pradinį puslapį</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.cpp" line="48"/>
        <source>Show start page</source>
        <translation>Rodyti pradžios puslapį</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.cpp" line="49"/>
        <source>Show empty page</source>
        <translation>Rodyti tuščią puslapį</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesPrivacyPageWidget</name>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="23"/>
        <source>Tracking</source>
        <translation>Sekimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="32"/>
        <source>Do Not Track:</source>
        <translation>Sekimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="57"/>
        <source>History</source>
        <translation>Žurnalas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="64"/>
        <source>Private mode</source>
        <translation>Privataus naršymo veiksena</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="107"/>
        <source>Remember browsing history</source>
        <translation>Vesti naršymo žurnalą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="114"/>
        <source>Remember downloads history</source>
        <translation>Vesti siuntų žurnalą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="124"/>
        <source>Remember search history</source>
        <translation>Vesti paieškų žurnalą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="136"/>
        <source>Remember form history</source>
        <translation>Įsiminti į formas vedamus duomenis</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="159"/>
        <source>Template…</source>
        <translation>Šablonas…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="170"/>
        <source>Enable cookies</source>
        <translation>Įjungti slapukus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="215"/>
        <source>Accept cookies:</source>
        <translation>Priimti slapukus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="228"/>
        <source>Keep until:</source>
        <translation>Laikyti iki:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="241"/>
        <source>Accept third-party cookies:</source>
        <translation>Priimti trečiųjų šalių slapukus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="263"/>
        <source>Exceptions…</source>
        <translation>Išimtys…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="279"/>
        <source>Clear history when application closes</source>
        <translation>Išvalyti žurnalą uždarant programą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="299"/>
        <source>Settings…</source>
        <translation>Nustatymai…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="319"/>
        <source>Passwords</source>
        <translation>Slaptažodžiai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="328"/>
        <source>Remember passwords</source>
        <translation>Įsiminti slaptažodžius</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="348"/>
        <source>Manage…</source>
        <translation>Tvarkyti…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="362"/>
        <source>Use a master password</source>
        <translation>Naudoti papildomą pagrindinį slaptažodį</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="385"/>
        <source>Change…</source>
        <translation>Keisti…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="40"/>
        <source>Inform websites that I do not want to be tracked</source>
        <translation>Nurodyti svetainėms, kad jos manęs nesektų</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="41"/>
        <source>Inform websites that I allow tracking</source>
        <translation>Nurodyti svetainėms, kad jos mane sektų</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="42"/>
        <source>Do not inform websites about my preference</source>
        <translation>Neinformuoti svetainių apie mano požiūrį į stebėjimą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="53"/>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="67"/>
        <source>Always</source>
        <translation>Visada</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="54"/>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="68"/>
        <source>Only existing</source>
        <translation>Tik jau egzistuojančius</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="55"/>
        <source>Only read existing</source>
        <translation>Skaityti tik esamus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="60"/>
        <source>Expires</source>
        <translation>Galiojimo pabaigos</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="61"/>
        <source>Current session is closed</source>
        <translation>Seanso pabaigos</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="62"/>
        <source>Always ask</source>
        <translation>Visada klausti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="69"/>
        <source>Never</source>
        <translation>Niekada</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesSearchPageWidget</name>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="21"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="60"/>
        <source>Add</source>
        <translation>Pridėti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="70"/>
        <source>Edit…</source>
        <translation>Redaguoti…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="80"/>
        <source>Update</source>
        <translation>Atnaujinti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="90"/>
        <source>Remove</source>
        <translation>Šalinti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="115"/>
        <source>Move Up</source>
        <translation>Pakelti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="141"/>
        <source>Move Down</source>
        <translation>Nuleisti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="154"/>
        <source>Enable search suggestions</source>
        <translation>Įgalinti paieškos pasiūlymus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="98"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="163"/>
        <source>Name</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="98"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="163"/>
        <source>Keyword</source>
        <translation>Raktažodis</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="127"/>
        <source>New…</source>
        <translation>Naują…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="128"/>
        <source>File…</source>
        <translation>Failą...</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="130"/>
        <source>Readd</source>
        <translation>Pridėti iš naujo</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="178"/>
        <source>New Search Engine</source>
        <translation>Nauja paieškos sistema</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="199"/>
        <source>Select File</source>
        <translation>Pasirinkite failą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="199"/>
        <source>Open Search files (*.xml)</source>
        <translation>Open Search failai (*.xml)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="307"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="370"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="308"/>
        <source>Do you really want to remove this search engine?</source>
        <translation>Ar tikrai norite pašalinti šią paieškos sistemą?</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="317"/>
        <source>Delete search engine permanently</source>
        <translation>Ištrinti paieškos sistemą visam laikui</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="349"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="360"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="448"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="349"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="360"/>
        <source>Failed to open Open Search file.</source>
        <translation>Nepavyko atverti Open Search failo.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="371"/>
        <source>Keyword is already in use. Do you want to continue anyway?</source>
        <translation>Raktažodis jau naudojamas. Ar vis tiek norite tęsti?</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="448"/>
        <source>Failed to update search engine.</source>
        <translation>Nepavyko atnaujinti paieškos sistemos.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="511"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
</context>
<context>
    <name>Otter::PrivateWindowIndicatorWidget</name>
    <message>
        <location filename="../../src/modules/widgets/privateWindowIndicator/PrivateWindowIndicatorWidget.cpp" line="33"/>
        <location filename="../../src/modules/widgets/privateWindowIndicator/PrivateWindowIndicatorWidget.cpp" line="49"/>
        <source>Private Window</source>
        <translation>Privatus langas</translation>
    </message>
</context>
<context>
    <name>Otter::ProgressBarDelegate</name>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="57"/>
        <source>Unknown</source>
        <translation>Nežinoma</translation>
    </message>
</context>
<context>
    <name>Otter::ProgressInformationWidget</name>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="111"/>
        <source>Document: %p%</source>
        <translation>Dokumentas: %p%</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="111"/>
        <source>Document: ?</source>
        <translation>Dokumentas: ?</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="119"/>
        <source>Total: ?</source>
        <translation>Iš viso: ?</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="119"/>
        <source>Total: %p%</source>
        <translation>Iš viso: %p%</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="127"/>
        <source>Total: %1</source>
        <translation>Viso: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="134"/>
        <source>Elements: %1/%2</source>
        <translation>Elementai: %1/%2</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="141"/>
        <source>Speed: %1</source>
        <translation>Sparta: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="150"/>
        <source>Time: %1</source>
        <translation>Laikas: %1</translation>
    </message>
</context>
<context>
    <name>Otter::ProxyPropertiesDialog</name>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="19"/>
        <source>Title:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="38"/>
        <source>General</source>
        <translation>Bendra</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="44"/>
        <source>Manual</source>
        <translation>Nurodyti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="144"/>
        <source>Port</source>
        <translation>Prievadas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="151"/>
        <source>Protocol</source>
        <translation>Protokolas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="158"/>
        <source>Servers</source>
        <translation>Serveriai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="165"/>
        <source>FTP</source>
        <translation>FTP</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="172"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="179"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="193"/>
        <source>HTTPS</source>
        <translation>HTTPS</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="207"/>
        <source>All</source>
        <translation>Visi</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="229"/>
        <source>Automatic</source>
        <translation>Automatiškai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="273"/>
        <source>Path to PAC file:</source>
        <translation>PAC failas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="286"/>
        <source>Use system authentication</source>
        <translation>Naudoti sistemos tapatybės nustatymą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="301"/>
        <source>Exceptions</source>
        <translation>Išimtys</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="307"/>
        <source>Do not use this proxy for:</source>
        <translation>Nenaudoti šio įgaliotojo serverio šiems adresams:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="328"/>
        <source>Add</source>
        <translation>Pridėti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="338"/>
        <source>Edit</source>
        <translation>Redaguoti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="348"/>
        <source>Remove</source>
        <translation>Šalinti</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="372"/>
        <source>Example: domain.com, localhost, 127.0.0.1, 192.168.1.0/24</source>
        <translation>Pavyzdys: domain.com, localhost, 127.0.0.1, 192.168.1.0/24</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.cpp" line="93"/>
        <source>Edit Proxy</source>
        <translation>Redaguoti įgaliotąjį serverį</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.cpp" line="93"/>
        <source>Add Proxy</source>
        <translation>Pridėti įgaliotąjį serverį</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebEnginePage</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="120"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="582"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="622"/>
        <source>JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="121"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="583"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="623"/>
        <source>Disable JavaScript popups</source>
        <translation>Išjungti JavaScript iškylančiuosius langus</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="476"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="489"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="476"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="490"/>
        <source>Are you sure that you want to send form data again?</source>
        <translation>Ar tikrai norite siųsti formos duomenis dar kartą?</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="476"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="491"/>
        <source>Do you want to resend data?</source>
        <translation>Ar norite iš naujo persiųsti duomenis?</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="477"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="495"/>
        <source>Do not show this message again</source>
        <translation>Daugiau neberodyti šio pranešimo</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebEngineWebBackend</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebBackend.cpp" line="225"/>
        <source>Blink Backend (experimental)</source>
        <translation>Blink atvaizdavimo varikliukas (eksperimentinė)</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebBackend.cpp" line="230"/>
        <source>Backend utilizing QtWebEngine module</source>
        <translation>Atvaizdavimo varikliukas, naudojantis QtWebEngine modulį</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebEngineWebWidget</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebWidget.cpp" line="518"/>
        <source>file</source>
        <translation>failas</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebWidget.cpp" line="529"/>
        <source>Failed to save image: %1</source>
        <translation>Nepavyko įrašyti paveikslo: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebWidget.cpp" line="1420"/>
        <source>Blank Page</source>
        <translation>Tuščias puslapis</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebWidget.cpp" line="1433"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitFtpListingNetworkReply</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="79"/>
        <source>Network error %1</source>
        <translation>Tinklo klaida %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="96"/>
        <source>Unknown command</source>
        <translation>Nežinoma komanda</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="160"/>
        <source>Directory Contents</source>
        <translation>Aplanko turinys</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="163"/>
        <source>Name</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="164"/>
        <source>Type</source>
        <translation>Tipas</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="165"/>
        <source>Size</source>
        <translation>Dydis</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="166"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitInspector</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitInspector.cpp" line="42"/>
        <source>Close</source>
        <translation>Užverti</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitNetworkManager</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="201"/>
        <source>Receiving data from %1…</source>
        <translation>Gaunami duomenys iš %1…</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="273"/>
        <source>Completed request to %1</source>
        <translation>Įvykdyta užklausa į %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="310"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="339"/>
        <source>Waiting for authentication…</source>
        <translation>Laukiama tapatybės nustatymo…</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="421"/>
        <source>Loading finished</source>
        <translation>Įkėlimas užbaigtas</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="742"/>
        <source>Sending request to %1…</source>
        <translation>Siunčima užklausa į %1…</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitPage</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="423"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="674"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="714"/>
        <source>JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="424"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="675"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="715"/>
        <source>Disable JavaScript popups</source>
        <translation>Išjungti JavaScript iškylančiuosius langus</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="614"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="627"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="948"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="614"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="628"/>
        <source>Are you sure that you want to send form data again?</source>
        <translation>Ar tikrai norite siųsti formos duomenis dar kartą?</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="614"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="629"/>
        <source>Do you want to resend data?</source>
        <translation>Ar norite iš naujo persiųsti duomenis?</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="615"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="633"/>
        <source>Do not show this message again</source>
        <translation>Daugiau neberodyti šio pranešimo</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="787"/>
        <source>%1 error #%2: %3</source>
        <translation>%1 klaida #%2: %3</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="859"/>
        <source>Request blocked by rule from profile %1:&lt;br&gt;
%2</source>
        <translation>Užklausa užblokuota pagal taisyklę iš profilio %1:&lt;br&gt;
%2</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="859"/>
        <source>(Unknown)</source>
        <translation>(Nežinoma)</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="877"/>
        <source>WebKit error %1</source>
        <translation>WebKit klaida %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="881"/>
        <source>Network error %1</source>
        <translation>Tinklo klaida %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="948"/>
        <source>The script on this page appears to have a problem.</source>
        <translation>Atrodo, kad scenarijus šiame puslapyje susidūrė su problemomis.</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="948"/>
        <source>Do you want to stop the script?</source>
        <translation>Ar norite stabdyti scenarijų?</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitPluginWidget</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPluginWidget.cpp" line="34"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPluginWidget.cpp" line="43"/>
        <source>Click to load content (%1) handled by plugin from: %2</source>
        <translation>Spustelėkite, norėdami įkelti turinį (%1), kurį apdoroja papildinys iš: %2</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitWebBackend</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebBackend.cpp" line="196"/>
        <source>WebKit Backend (legacy)</source>
        <translation>WebKit varikliukas (senasis)</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebBackend.cpp" line="198"/>
        <source>WebKit Backend</source>
        <translation>WebKit varikliukas</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebBackend.cpp" line="204"/>
        <source>Backend utilizing QtWebKit module</source>
        <translation>Atvaizdavimas naudojant QtWebKit modulį</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitWebWidget</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="421"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="421"/>
        <source>Failed to open file for writing.</source>
        <translation>Nepavyko atverti failo rašymui.</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="441"/>
        <source>file</source>
        <translation>failas</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="449"/>
        <source>Failed to save image: %1</source>
        <translation>Nepavyko įrašyti paveikslo: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="583"/>
        <source>Print Preview</source>
        <translation>Spaudinio peržiūra</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="1696"/>
        <source>PNG image (*.png)</source>
        <translation>PNG paveikslas (*.png)</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="1696"/>
        <source>JPEG image (*.jpg *.jpeg)</source>
        <translation>JPEG paveikslas (*.jpg *.jpeg)</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="2127"/>
        <source>Blank Page</source>
        <translation>Tuščias puslapis</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="2140"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
</context>
<context>
    <name>Otter::ReloadTimeDialog</name>
    <message>
        <location filename="../../src/ui/ReloadTimeDialog.ui" line="14"/>
        <source>Automatic Page Reload</source>
        <translation>Automatinis puslapio įkėlimas iš naujo</translation>
    </message>
    <message>
        <location filename="../../src/ui/ReloadTimeDialog.ui" line="29"/>
        <source>minutes</source>
        <translation>minutės</translation>
    </message>
    <message>
        <location filename="../../src/ui/ReloadTimeDialog.ui" line="46"/>
        <source>seconds</source>
        <translation>sekundės</translation>
    </message>
</context>
<context>
    <name>Otter::ReportDialog</name>
    <message>
        <location filename="../../src/ui/ReportDialog.ui" line="14"/>
        <source>Diagnostic Report</source>
        <translation>Diagnostinė ataskaita</translation>
    </message>
    <message>
        <location filename="../../src/ui/ReportDialog.cpp" line="41"/>
        <source>Copy</source>
        <translation>Kopijuoti</translation>
    </message>
</context>
<context>
    <name>Otter::RssFeedParser</name>
    <message>
        <location filename="../../src/core/FeedParser.cpp" line="376"/>
        <source>Failed to parse feed file: %1</source>
        <translation>Nepavyko išanalizuoti kanalo failo: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedParser.cpp" line="387"/>
        <source>Failed to parse feed: no valid entries found</source>
        <translation>Nepavyko išanalizuoti kanalo: nerasta jokių teisingų įrašų</translation>
    </message>
</context>
<context>
    <name>Otter::SaveSessionDialog</name>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.ui" line="14"/>
        <source>Save Session</source>
        <translation>Įrašyti seansą</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.ui" line="22"/>
        <source>Session title:</source>
        <translation>Seanso pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.ui" line="32"/>
        <source>Session identifier:</source>
        <translation>Seanso identifikatorius:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.ui" line="50"/>
        <source>Store only current window</source>
        <translation>Išsaugoti tik aktyvų langą</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.cpp" line="68"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.cpp" line="68"/>
        <source>Session with specified indentifier already exists.
Do you want to overwrite it?</source>
        <translation>Seansas su tokiu pavadinimu jau egzistuoja.
Ar norite perrašyti egzistuojantį seansą?</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.cpp" line="81"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.cpp" line="81"/>
        <source>Failed to save session.</source>
        <translation>Nepavyko įrašyti seanso.</translation>
    </message>
</context>
<context>
    <name>Otter::SearchBarWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="35"/>
        <source>Find…</source>
        <translation>Rasti…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="45"/>
        <source>Find Next</source>
        <translation>Rasti kitą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="55"/>
        <source>Find Previous</source>
        <translation>Rasti ankstesnį</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="78"/>
        <source>Highlight</source>
        <translation>Paryškinti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="94"/>
        <source>Case Sensitive</source>
        <translation>Skirti didžiąsias ir mažąsias raides</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="107"/>
        <source>Close</source>
        <translation>Užverti</translation>
    </message>
</context>
<context>
    <name>Otter::SearchEnginePropertiesDialog</name>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="14"/>
        <source>Edit Search Engine</source>
        <translation>Redaguoti paieškos sistemą</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="22"/>
        <source>Title:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="49"/>
        <source>Change Icon…</source>
        <translation>Keisti piktogramą…</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="58"/>
        <source>Description:</source>
        <translation>Aprašas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="71"/>
        <source>Keyword:</source>
        <translation>Raktažodis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="84"/>
        <source>Encoding:</source>
        <translation>Koduotė:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="101"/>
        <source>Form address:</source>
        <translation>Formos adresas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="117"/>
        <source>Update address:</source>
        <translation>Atnaujinimo adresas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="133"/>
        <source>Results Query</source>
        <translation>Rezultatų užklausa</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="141"/>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="249"/>
        <source>Address:</source>
        <translation>Adresas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="154"/>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="265"/>
        <source>Query:</source>
        <translation>Užklausa:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="169"/>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="277"/>
        <source>POST method</source>
        <translation>POST metodas</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="210"/>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="318"/>
        <source>Data encoding (enctype):</source>
        <translation>Duomenų koduotė (enctype):</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="238"/>
        <source>Suggestions Query</source>
        <translation>Pasiūlymų užklausa</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.cpp" line="127"/>
        <source>Placeholders</source>
        <translation>Vietaženkliai</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.cpp" line="128"/>
        <source>Search Terms</source>
        <translation>Paieškos žodžiai</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.cpp" line="129"/>
        <source>Language</source>
        <translation>Kalba</translation>
    </message>
</context>
<context>
    <name>Otter::SearchEnginesManager</name>
    <message>
        <location filename="../../src/core/SearchEnginesManager.cpp" line="171"/>
        <source>Manage Search Engines…</source>
        <translation>Paieškos sistemų tvarkymas…</translation>
    </message>
    <message>
        <location filename="../../src/core/SearchEnginesManager.cpp" line="192"/>
        <source>Unknown</source>
        <translation>Nežinoma</translation>
    </message>
</context>
<context>
    <name>Otter::SearchWidget</name>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="193"/>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="194"/>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="670"/>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="671"/>
        <source>Search using %1</source>
        <translation>Ieškoti, naudojant %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="311"/>
        <source>Add %1</source>
        <translation>Pridėti %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="311"/>
        <source>(untitled)</source>
        <translation>(be pavadinimo)</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="438"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="438"/>
        <source>Failed to add search engine.</source>
        <translation>Nepavyko pridėti paieškos sistemos.</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="820"/>
        <source>Select Search Engine</source>
        <translation>Pasirinkti paieškos sistemą</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="824"/>
        <source>Add Search Engine…</source>
        <translation>Pridėti paieškos sistemą…</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="828"/>
        <source>Search</source>
        <translation>Ieškoti</translation>
    </message>
</context>
<context>
    <name>Otter::SelectPasswordDialog</name>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.ui" line="14"/>
        <source>Select Password</source>
        <translation>Pasirinkti slaptažodį</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.ui" line="20"/>
        <source>Select set of credentials:</source>
        <translation>Pasirinkite prisijungimo duomenų rinkinį:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.ui" line="41"/>
        <source>Remove</source>
        <translation>Pašalinti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="38"/>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="79"/>
        <source>Name</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="38"/>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="79"/>
        <source>Value</source>
        <translation>Reikšmė</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="42"/>
        <source>Set #%1</source>
        <translation>Rinkinys #%1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="87"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="87"/>
        <source>Do you really want to remove this credentials set?</source>
        <translation>Ar tikrai norite pašalinti šį prisijungimo duomenų rinkinį?</translation>
    </message>
</context>
<context>
    <name>Otter::SessionModel</name>
    <message>
        <location filename="../../src/core/SessionModel.cpp" line="247"/>
        <source>Session</source>
        <translation>Seansas</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionModel.cpp" line="250"/>
        <source>Trash</source>
        <translation>Šiukšlinė</translation>
    </message>
</context>
<context>
    <name>Otter::SessionsManager</name>
    <message>
        <location filename="../../src/core/SessionsManager.cpp" line="222"/>
        <source>Default</source>
        <translation>Įprastas</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionsManager.cpp" line="222"/>
        <location filename="../../src/core/SessionsManager.cpp" line="368"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionsManager.h" line="109"/>
        <source>Start Page</source>
        <translation>Pradžios puslapis</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionsManager.h" line="112"/>
        <source>(Unknown)</source>
        <translation>(Nežinoma)</translation>
    </message>
</context>
<context>
    <name>Otter::SessionsManagerDialog</name>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.ui" line="14"/>
        <source>Sessions Manager</source>
        <translation>Seansų tvarkytuvė</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.ui" line="52"/>
        <source>Open</source>
        <translation>Atverti</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.ui" line="59"/>
        <source>Delete</source>
        <translation>Ištrinti</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.ui" line="77"/>
        <source>Open session in current window</source>
        <translation>Atverti seansą aktyviame lange</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="45"/>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="69"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="49"/>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="98"/>
        <source>Title</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="49"/>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="98"/>
        <source>Identifier</source>
        <translation>Identifikatorius</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="49"/>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="98"/>
        <source>Windows</source>
        <translation>Langai</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="69"/>
        <source>%n window(s) (%1)</source>
        <translation><numerusform>%n langas (%1)</numerusform><numerusform>%n langai (%1)</numerusform><numerusform>%n langų (%1)</numerusform><numerusform>%n langų (%1)</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="69"/>
        <source>%n tab(s)</source>
        <translation><numerusform>%n kortelė</numerusform><numerusform>%n kortelės</numerusform><numerusform>%n kortelių</numerusform><numerusform>%n kortelių</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="106"/>
        <source>Warning</source>
        <translation>Įspėjimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="106"/>
        <source>This session was not saved correctly.
Are you sure that you want to restore this session anyway?</source>
        <translation>Seansas buvo blogai įrašytas.
Ar tikrai norite jį atkurti?</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="123"/>
        <source>Confirm</source>
        <translation>Patvirtinimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="123"/>
        <source>Are you sure that you want to delete session %1?</source>
        <translation>Ar tikrai norite ištrinti seansą %1?</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="131"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="131"/>
        <source>Failed to delete session.</source>
        <translation>Nepavyko ištrinti seanso.</translation>
    </message>
</context>
<context>
    <name>Otter::SettingsManager</name>
    <message>
        <location filename="../../src/core/SettingsManager.cpp" line="358"/>
        <source>Yes</source>
        <translation>Taip</translation>
    </message>
    <message>
        <location filename="../../src/core/SettingsManager.cpp" line="358"/>
        <source>No</source>
        <translation>Ne</translation>
    </message>
    <message>
        <location filename="../../src/core/SettingsManager.cpp" line="363"/>
        <source>Invalid</source>
        <translation>Neteisinga</translation>
    </message>
</context>
<context>
    <name>Otter::ShortcutWidget</name>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="41"/>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="71"/>
        <source>Clear</source>
        <translation>Išvalyti</translation>
    </message>
</context>
<context>
    <name>Otter::SidebarWidget</name>
    <message>
        <location filename="../../src/ui/SidebarWidget.ui" line="69"/>
        <source>Panels</source>
        <translation>Skydeliai</translation>
    </message>
    <message>
        <location filename="../../src/ui/SidebarWidget.cpp" line="160"/>
        <source>Add web panel</source>
        <translation>Pridėti saityno skydelį</translation>
    </message>
    <message>
        <location filename="../../src/ui/SidebarWidget.cpp" line="467"/>
        <source>Add Web Panel…</source>
        <translation>Pridėti saityno skydelį…</translation>
    </message>
</context>
<context>
    <name>Otter::SourceViewerWebWidget</name>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="87"/>
        <source>Failed to save file: %1</source>
        <translation>Nepavyko įrašyti failo: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="89"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="89"/>
        <source>Failed to save file.</source>
        <translation>Nepavyko įrašyti failo.</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="115"/>
        <source>Warning</source>
        <translation>Įspėjimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="115"/>
        <source>The document has been modified.
Do you want to save your changes or discard them?</source>
        <translation>Dokumentas buvo modifikuotas.
Norite įrašyti pakeitimus ar juos atmesti?</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="300"/>
        <source>Show Line Numbers</source>
        <translation>Rodyti eilučių numerius</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="425"/>
        <source>Source Viewer: %1</source>
        <translation>Šaltinio žiūryklė: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="425"/>
        <source>Source Viewer</source>
        <translation>Šaltinio žiūryklė</translation>
    </message>
</context>
<context>
    <name>Otter::StartPageModel</name>
    <message>
        <location filename="../../src/modules/windows/web/StartPageModel.cpp" line="100"/>
        <location filename="../../src/modules/windows/web/StartPageModel.cpp" line="101"/>
        <source>Add Tile…</source>
        <translation>Pridėti plytelę…</translation>
    </message>
</context>
<context>
    <name>Otter::StartPagePreferencesDialog</name>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="14"/>
        <source>Start Page Preferences</source>
        <translation>Pradžios puslapio nuostatos</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="20"/>
        <source>Use custom background image</source>
        <translation>Naudoti tinkintą fono paveikslą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="66"/>
        <source>Scaling mode:</source>
        <translation>Išklojimo veiksena:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="79"/>
        <source>Image path:</source>
        <translation>Paveikslo kelias:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="89"/>
        <source>Color:</source>
        <translation>Spalva:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="109"/>
        <source>Columns per row:</source>
        <translation>Stulpelių eilutėje:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="119"/>
        <source>Automatic</source>
        <translation>Automatiškai</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="126"/>
        <source>Zoom level:</source>
        <translation>Mastelio lygis:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="136"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="154"/>
        <source>Show search field</source>
        <translation>Rodyti paieškos lauką</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="161"/>
        <source>Show tile to add new entries</source>
        <translation>Rodyti naujų įrašų pridėjimo plytelę</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.cpp" line="40"/>
        <source>Images (*.png *.jpg *.bmp *.gif *.svg *.svgz)</source>
        <translation>Paveikslai (*.png *.jpg *.bmp *.gif *.svg *.svgz)</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.cpp" line="41"/>
        <source>Best fit</source>
        <translation>Geriausias priderinimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.cpp" line="42"/>
        <source>Center</source>
        <translation>Centruoti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.cpp" line="43"/>
        <source>Stretch</source>
        <translation>Ištempti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.cpp" line="44"/>
        <source>Tile</source>
        <translation>Iškloti</translation>
    </message>
</context>
<context>
    <name>Otter::StartPageWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="560"/>
        <source>Add Tile</source>
        <translation>Pridėti plytelę</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="847"/>
        <source>Edit…</source>
        <translation>Redaguoti…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="851"/>
        <source>Reload</source>
        <translation>Įkelti iš naujo</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="859"/>
        <source>Delete</source>
        <translation>Ištrinti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="863"/>
        <source>Configure…</source>
        <translation>Konfigūruoti…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="867"/>
        <source>Add Tile…</source>
        <translation>Pridėti plytelę…</translation>
    </message>
</context>
<context>
    <name>Otter::StartupDialog</name>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="14"/>
        <location filename="../../src/ui/StartupDialog.ui" line="27"/>
        <source>Welcome to Otter</source>
        <translation>Otter sveikina Jus</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="34"/>
        <source>Continue session</source>
        <translation>Tęsti seansą</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="104"/>
        <source>Begin with home page</source>
        <translation>Atverti pradinį puslapį</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="114"/>
        <source>Begin with start page</source>
        <translation>Atverti pradžios puslapį</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="124"/>
        <source>Begin with blank page</source>
        <translation>Pradėti nuo tuščio puslapio</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="134"/>
        <source>Enable plugins</source>
        <translation>Įjungti papildinius</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.cpp" line="55"/>
        <location filename="../../src/ui/StartupDialog.cpp" line="62"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.cpp" line="122"/>
        <source>Window %1</source>
        <translation>Langas %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.cpp" line="132"/>
        <source>Title: %1
Address: %2</source>
        <translation>Pavadinimas: %1
Adresas: %2</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.cpp" line="225"/>
        <source>Default</source>
        <translation>Įprastas</translation>
    </message>
</context>
<context>
    <name>Otter::TabBarToolBarWidget</name>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="1186"/>
        <source>Switch Tabs Using the Mouse Wheel</source>
        <translation>Perjungti korteles naudojant pelės ratuką</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="1190"/>
        <source>Show Thumbnails in Tabs</source>
        <translation>Rodyti kortelėse miniatiūras</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="1209"/>
        <source>Arrange</source>
        <translation>Sutvarkyti</translation>
    </message>
</context>
<context>
    <name>Otter::TabBarWidget</name>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="808"/>
        <source>Arrange</source>
        <translation>Sutvarkyti</translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="820"/>
        <source>Switch Tabs Using the Mouse Wheel</source>
        <translation>Perjungti korteles naudojant pelės ratuką</translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="824"/>
        <source>Show Thumbnails in Tabs</source>
        <translation>Rodyti kortelėse miniatiūras</translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="843"/>
        <source>Customize</source>
        <translation>Tinkinti</translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="1086"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/TabBarWidget.cpp" line="1087"/>
        <source>You are about to open %n URL(s).</source>
        <translation><numerusform>Jūs ketinate atverti %n URL.</numerusform><numerusform>Jūs ketinate atverti %n URL.</numerusform><numerusform>Jūs ketinate atverti %n URL.</numerusform><numerusform>Jūs ketinate atverti %n URL.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="1088"/>
        <source>Do you want to continue?</source>
        <translation>Ar norite tęsti?</translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="1092"/>
        <source>Do not show this message again</source>
        <translation>Daugiau neberodyti šio pranešimo</translation>
    </message>
</context>
<context>
    <name>Otter::TabHandleWidget</name>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="269"/>
        <source>Close Tab</source>
        <translation>Užverti kortelę</translation>
    </message>
</context>
<context>
    <name>Otter::TabHistoryContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="156"/>
        <source>Tab History</source>
        <translation>Kortelių žurnalas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="184"/>
        <source>Title: %1</source>
        <translation>Pavadinimas: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="184"/>
        <source>Address: %1</source>
        <translation>Adresas: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="188"/>
        <source>Date: %1</source>
        <translation>Data: %1</translation>
    </message>
</context>
<context>
    <name>Otter::TextLabelWidget</name>
    <message>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="42"/>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="98"/>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="138"/>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="182"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;empty&gt;</translation>
    </message>
    <message>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="70"/>
        <source>Copy</source>
        <translation>Kopijuoti</translation>
    </message>
    <message>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="76"/>
        <source>Copy Link Location</source>
        <translation>Kopijuoti nuorodos vietą</translation>
    </message>
    <message>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="81"/>
        <source>Select All</source>
        <translation>Pažymėti viską</translation>
    </message>
</context>
<context>
    <name>Otter::ToolBarDialog</name>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="14"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="64"/>
        <source>Edit Toolbar</source>
        <translation>Redaguoti įrankių juostą</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="22"/>
        <source>Name:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="45"/>
        <source>Entries</source>
        <translation>Įrašai</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="106"/>
        <source>Edit…</source>
        <translation>Redaguoti…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="115"/>
        <source>Current entries:</source>
        <translation>Dabartiniai įrašai:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="202"/>
        <source>Available entries:</source>
        <translation>Prieinami įrašai:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="209"/>
        <location filename="../../src/ui/ToolBarDialog.ui" line="219"/>
        <source>Filter…</source>
        <translation>Filtras…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="256"/>
        <source>Add Bookmark</source>
        <translation>Pridėti adresyno įrašą</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="269"/>
        <source>Bookmarks folder:</source>
        <translation>Adresyno aplankas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="291"/>
        <source>New…</source>
        <translation>Naujas…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="331"/>
        <source>Options</source>
        <translation>Parinktys</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="339"/>
        <source>Visibility:</source>
        <translation>Matomumas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="352"/>
        <source>Visibility in full screen mode:</source>
        <translation>Matomumas viso ekrano veiksenoje:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="365"/>
        <source>Button style:</source>
        <translation>Mygtukų stilius:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="378"/>
        <source>Icon size:</source>
        <translation>Piktogramų dydis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="388"/>
        <source>Auto</source>
        <translation>Automatinis</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="391"/>
        <location filename="../../src/ui/ToolBarDialog.ui" line="417"/>
        <source> px</source>
        <translation>tšk</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="404"/>
        <source>Maximum size of item:</source>
        <translation>Didžiausias elemento dydis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="414"/>
        <source>No limit</source>
        <translation>Be ribų</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="429"/>
        <source>Display toggle button</source>
        <translation>Rodyti perjungimo mygtuką</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="46"/>
        <source>Edit Bookmarks Bar</source>
        <translation>Taisyti adresyno juostą</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="50"/>
        <source>Bookmarks Bar</source>
        <translation>Adresyno juosta</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="55"/>
        <source>Edit Sidebar</source>
        <translation>Taisyti šoninę juostą</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="59"/>
        <source>Sidebar</source>
        <translation>Šoninė juosta</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="68"/>
        <source>Toolbar</source>
        <translation>Įrankių juosta</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="78"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="85"/>
        <source>Always visible</source>
        <translation>Visada matoma</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="79"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="86"/>
        <source>Always hidden</source>
        <translation>Visada paslėpta</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="80"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="87"/>
        <source>Visible only when needed</source>
        <translation>Matoma tik kada reikia</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="88"/>
        <source>Visible only when cursor is close to screen edge</source>
        <translation>Matoma tik tuomet, kai žymeklis arti ekrano krašto</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="93"/>
        <source>Follow style</source>
        <translation>Sekti stilių</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="94"/>
        <source>Icon only</source>
        <translation>Tik piktograma</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="95"/>
        <source>Text only</source>
        <translation>Tik tekstas</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="96"/>
        <source>Text beside icon</source>
        <translation>Tekstas šalia piktogramų</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="97"/>
        <source>Text under icon</source>
        <translation>Tekstas po piktogramomis</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="339"/>
        <source>Edit Entry</source>
        <translation>Keisti įrašą</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="356"/>
        <source>All</source>
        <translation>Visi</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="363"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="629"/>
        <source>Unknown</source>
        <translation>Nežinoma</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="373"/>
        <source>Show search engine:</source>
        <translation>Rodyti paieškos sistemą:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="374"/>
        <source>Show search button:</source>
        <translation>Rodyti paieškos mygtuką:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="389"/>
        <source>Global</source>
        <translation>Visuotinai</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="389"/>
        <source>Tab</source>
        <translation>Kortelė</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="393"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="463"/>
        <source>Text:</source>
        <translation>Tekstas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="394"/>
        <source>Option:</source>
        <translation>Parinktis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="395"/>
        <source>Scope:</source>
        <translation>Sritis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="424"/>
        <source>Blocked Elements: {amount}</source>
        <translation>Užblokuoti elementai: {amount}</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="429"/>
        <source>Menu</source>
        <translation>Meniu</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="434"/>
        <source>Downloads</source>
        <translation>Atsiuntimai</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="462"/>
        <source>Icon:</source>
        <translation>Piktograma:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="532"/>
        <source>--- separator ---</source>
        <translation>--- skirtukas ---</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="536"/>
        <source>--- spacer ---</source>
        <translation>--- tarpas ---</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="540"/>
        <source>Arbitrary List of Actions</source>
        <translation>Pasirinktinis veiksmų sąrašas</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="548"/>
        <source>List of Closed Tabs and Windows</source>
        <translation>Užvertų kortelių ir langų sąrašas</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="553"/>
        <source>Address Field</source>
        <translation>Adreso laukas</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="562"/>
        <source>Configuration Widget (%1)</source>
        <translation>Konfigūracijos valdiklis (%1)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="566"/>
        <source>Configuration Widget</source>
        <translation>Konfigūracijos valdiklis</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="572"/>
        <source>Content Blocking Details</source>
        <translation>Išsamesnė turinio blokavimo informacija</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="577"/>
        <source>Error Console</source>
        <translation>Klaidų pultas</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="581"/>
        <source>Menu Bar</source>
        <translation>Meniu juosta</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="586"/>
        <source>Menu Button</source>
        <translation>Meniu mygtukas</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="590"/>
        <source>Sidebar Panel Chooser</source>
        <translation>Šoninės juostos skydelio selektorius</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="594"/>
        <source>Private Window Indicator</source>
        <translation>Privataus lango indikatorius</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="599"/>
        <source>Progress Information (Document Progress)</source>
        <translation>Eigos informacija (Dokumento eiga)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="603"/>
        <source>Progress Information (Total Progress)</source>
        <translation>Eigos informacija (Bendra eiga)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="607"/>
        <source>Progress Information (Loaded Elements)</source>
        <translation>Eigos informacija (Įkelti elementai)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="611"/>
        <source>Progress Information (Loading Speed)</source>
        <translation>Eigos informacija (Įkėlimo sparta)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="615"/>
        <source>Progress Information (Elapsed Time)</source>
        <translation>Eigos informacija (Praėjęs laikas)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="619"/>
        <source>Progress Information (Status Message)</source>
        <translation>Eigos informacija (Būsenos pranešimas)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="629"/>
        <source>Search Field (%1)</source>
        <translation>Paieškos laukas (%1)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="634"/>
        <source>Search Field</source>
        <translation>Paieškos laukas</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="640"/>
        <source>Window Resize Handle</source>
        <translation>Lango dydžio keitimo rankenėlė</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="644"/>
        <source>Status Message Field</source>
        <translation>Būsenos pranešimo laukas</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="648"/>
        <source>Tab Bar</source>
        <translation>Kortelių juosta</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="652"/>
        <source>Downloads Progress Information</source>
        <translation>Atsiuntimų eigos informacija</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="657"/>
        <source>Zoom Slider</source>
        <translation>Mastelio slinkiklis</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="677"/>
        <source>Invalid Bookmark</source>
        <translation>Neteisingas adresyno įrašas</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="686"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="703"/>
        <source>Invalid Entry</source>
        <translation>Neteisingas įrašas</translation>
    </message>
</context>
<context>
    <name>Otter::ToolBarWidget</name>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="133"/>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="849"/>
        <source>Toggle Visibility</source>
        <translation>Perjungti matomumą</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="905"/>
        <source>Customize</source>
        <translation>Tinkinti</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="907"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="908"/>
        <source>Configure…</source>
        <translation>Konfigūruoti…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="911"/>
        <source>Reset to Defaults…</source>
        <translation>Atstatyti numatytuosius…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="928"/>
        <source>Remove…</source>
        <translation>Šalinti…</translation>
    </message>
</context>
<context>
    <name>Otter::ToolBarsManager</name>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="365"/>
        <source>Reset Toolbar</source>
        <translation>Atstatyti įrankių juostą</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="365"/>
        <source>Do you really want to reset this toolbar to default configuration?</source>
        <translation>Ar tikrai norite atstatyti šią įrankių juostą į numatytąją konfigūraciją?</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="373"/>
        <source>Remove Toolbar</source>
        <translation>Šalinti įrankių juostą</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="373"/>
        <source>Do you really want to remove this toolbar?</source>
        <translation>Ar tikrai norite pašalinti šią įrankių juostą?</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="387"/>
        <source>Reset Toolbars</source>
        <translation>Atstatyti įrankių juostas</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="387"/>
        <source>Do you really want to reset all toolbars to default configuration?</source>
        <translation>Ar tikrai norite atstatyti visas įrankių juostas į numatytąją konfigūraciją?</translation>
    </message>
</context>
<context>
    <name>Otter::ToolButtonWidget</name>
    <message>
        <location filename="../../src/ui/ToolButtonWidget.cpp" line="130"/>
        <source>Menu</source>
        <translation>Meniu</translation>
    </message>
</context>
<context>
    <name>Otter::Transfer</name>
    <message>
        <location filename="../../src/core/TransfersManager.cpp" line="670"/>
        <location filename="../../src/core/TransfersManager.cpp" line="703"/>
        <source>file</source>
        <translation>failas</translation>
    </message>
    <message>
        <location filename="../../src/core/TransfersManager.cpp" line="888"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message>
        <location filename="../../src/core/TransfersManager.cpp" line="888"/>
        <source>File with the same name already exists.
Do you want to overwrite it?

%1</source>
        <translation>Failas tokiu pačiu pavadinimu jau yra.
Ar norite jį perrašyti?

%1</translation>
    </message>
</context>
<context>
    <name>Otter::TransferActionWidget</name>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="234"/>
        <source>From:</source>
        <translation>Iš:</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="240"/>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="244"/>
        <source>Size:</source>
        <translation>Dydis:</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="240"/>
        <source>%1 (download completed)</source>
        <translation>%1 (atsiuntimas užbaigtas)</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="244"/>
        <source>%1 (%2% downloaded)</source>
        <translation>%1 (%2% atsiųsta)</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="263"/>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="297"/>
        <source>Unknown</source>
        <translation>Nežinoma</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="270"/>
        <source>Redownload</source>
        <translation>Atsisiųsti iš naujo</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="275"/>
        <source>Open Folder</source>
        <translation>Atverti aplanką</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="280"/>
        <source>Stop</source>
        <translation>Stabdyti</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="297"/>
        <source>&lt;div style=&quot;white-space:pre;&quot;&gt;Source: %1
Target: %2
Size: %3
Downloaded: %4
Progress: %5&lt;/div&gt;</source>
        <translation>&lt;div style=&quot;white-space:pre;&quot;&gt;Šaltinis: %1
Paskirtis: %2
Dydis: %3
Atsiųsta: %4
Eiga: %5&lt;/div&gt;</translation>
    </message>
</context>
<context>
    <name>Otter::TransferDialog</name>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="14"/>
        <source>Opening unknown file</source>
        <translation>Atveriamas nežinomas failas</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="22"/>
        <source>Name:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="29"/>
        <source>Type:</source>
        <translation>Tipas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="36"/>
        <source>Size:</source>
        <translation>Dydis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="43"/>
        <source>From:</source>
        <translation>Iš:</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="50"/>
        <source>Open with:</source>
        <translation>Atverti, naudojant:</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="104"/>
        <source>Remember choice for this file type</source>
        <translation>Įsiminti pasirinkimą šiam failų tipui</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.cpp" line="45"/>
        <source>unknown file</source>
        <translation>nežinomas failas</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.cpp" line="65"/>
        <source>Opening %1</source>
        <translation>Atveriama %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.cpp" line="171"/>
        <source>unknown</source>
        <translation>nežinoma</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.cpp" line="175"/>
        <source>%1 (download completed)</source>
        <translation>%1 (atsiuntimas užbaigtas)</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.cpp" line="179"/>
        <source>%1 (%2% downloaded)</source>
        <translation>%1 (%2% atsiųsta)</translation>
    </message>
</context>
<context>
    <name>Otter::TransfersContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="31"/>
        <source>Quick Download…</source>
        <translation>Spartusis atsiuntimas…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="120"/>
        <source>Source:</source>
        <translation>Iš:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="130"/>
        <source>Target:</source>
        <translation>Į:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="140"/>
        <source>Size:</source>
        <translation>Dydis:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="150"/>
        <source>Downloaded:</source>
        <translation>Parsiųsta:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="157"/>
        <source>Progress:</source>
        <translation>Eiga:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="190"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="405"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="452"/>
        <source>Stop</source>
        <translation>Stabdyti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="200"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="408"/>
        <source>Redownload</source>
        <translation>Paleisti iš naujo</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Status</source>
        <translation>Būsena</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Filename</source>
        <translation>Failo pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Size</source>
        <translation>Dydis</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Progress</source>
        <translation>Eiga</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Time</source>
        <translation>Laikas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Speed</source>
        <translation>Sparta</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Started</source>
        <translation>Pradėta</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Finished</source>
        <translation>Pabaigta</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="145"/>
        <source>Warning</source>
        <translation>Įspėjimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="145"/>
        <source>This file is still being downloaded.
Do you really want to remove it?</source>
        <translation>Šis failas yra vis dar atsiunčiamas.
Ar tikrai norite jį pašalinti?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="277"/>
        <source>&lt;div style=&quot;white-space:pre;&quot;&gt;Source: %1
Target: %2
Size: %3
Downloaded: %4
Progress: %5&lt;/div&gt;</source>
        <translation>&lt;div style=&quot;white-space:pre;&quot;&gt;Šaltinis: %1
Paskirtis: %2
Dydis: %3
Parsiųsta: %4
Eiga: %5&lt;/div&gt;</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="277"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="467"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="469"/>
        <source>Unknown</source>
        <translation>Nežinoma</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="400"/>
        <source>Open Folder</source>
        <translation>Atverti aplanką</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="405"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="447"/>
        <source>Resume</source>
        <translation>Tęsti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="412"/>
        <source>Copy Transfer Information</source>
        <translation>Kopijuoti atsiuntimo informaciją</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="416"/>
        <source>Remove</source>
        <translation>Pašalinti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="433"/>
        <source>Clear Finished Transfers</source>
        <translation>Išvalyti užbaigtus atsiuntimus</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="546"/>
        <source>Downloads</source>
        <translation>Atsiuntimai</translation>
    </message>
</context>
<context>
    <name>Otter::TransfersManager</name>
    <message>
        <location filename="../../src/core/TransfersManager.cpp" line="1126"/>
        <source>Download completed:
%1</source>
        <translation>Atsiuntimas užbaigtas:
%1</translation>
    </message>
</context>
<context>
    <name>Otter::TransfersWidget</name>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="47"/>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="101"/>
        <source>Downloads</source>
        <translation>Atsiuntimai</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="123"/>
        <source>Show all Downloads</source>
        <translation>Rodyti visus atsiuntimus</translation>
    </message>
</context>
<context>
    <name>Otter::TrayIcon</name>
    <message>
        <location filename="../../src/ui/TrayIcon.cpp" line="41"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="148"/>
        <source>Show Windows</source>
        <translation>Rodyti langus</translation>
    </message>
    <message>
        <location filename="../../src/ui/TrayIcon.cpp" line="79"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="176"/>
        <source>Otter Browser</source>
        <translation>Otter naršyklė</translation>
    </message>
    <message>
        <location filename="../../src/ui/TrayIcon.cpp" line="148"/>
        <source>Hide Windows</source>
        <translation>Slėpti langus</translation>
    </message>
</context>
<context>
    <name>Otter::UpdateCheckerDialog</name>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.ui" line="14"/>
        <source>Check for Updates</source>
        <translation>Tikrinti ar yra atnaujinimų</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.ui" line="20"/>
        <source>Checking for update…</source>
        <translation>Tikrinama ar yra atnaujinimų…</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="50"/>
        <source>Checking for updates…</source>
        <translation>Tikrinami atnaujinimai...</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="91"/>
        <source>There are no new updates.</source>
        <translation>Naujų atnaujinimų nėra.</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="97"/>
        <source>Available updates:</source>
        <translation>Prieinami atnaujinimai:</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="101"/>
        <source>Details…</source>
        <translation>Išsamiau...</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="104"/>
        <source>Download</source>
        <translation>Atsisiųsti</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="117"/>
        <source>Version %1 from %2 channel</source>
        <translation>Versija %1 iš %2 kanalo</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="127"/>
        <source>Some of the updates do not contain packages for your platform. Try to check for updates later or visit details page for more info.</source>
        <translation>Kai kuriuose atnaujinimuose nėra jūsų platformai skirtų paketų. Pabandykite patikrinti ar yra atnaujinimų vėliau arba išsamesnei informacijai apsilankykite nurodytoje svetainėje.</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="151"/>
        <source>Downloading:</source>
        <translation>Atsiunčiama:</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="166"/>
        <source>Download finished!</source>
        <translation>Atsiuntimas užbaigtas!</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="167"/>
        <source>Install</source>
        <translation>Įdiegti</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="169"/>
        <source>New version of Otter Browser is ready to install.
Click Install button to restart browser and install the update or close this dialog to install the update during next browser restart.</source>
        <translation>Nauja Naršyklės Otter versija yra paruošta įdiegimui.
Spustelėkite mygtuką Įdiegti, kad iš naujo paleistumėte naršyklę ir įdiegtumėte atnaujinimą arba užverkite šį dialogą, kad įdiegtumėte atnaujinimą kito naršyklės paleidimo metu.</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="191"/>
        <source>Download failed!</source>
        <translation>Atsiuntimas nepavyko!</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="193"/>
        <source>Check Error Console for more information.</source>
        <translation>Išsamesnei informacijai, žiūrėkite klaidų pultą.</translation>
    </message>
</context>
<context>
    <name>Otter::UserAgentPropertiesDialog</name>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.ui" line="19"/>
        <source>Title:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.ui" line="29"/>
        <source>Value:</source>
        <translation>Reikšmė:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.ui" line="47"/>
        <source>Preview</source>
        <translation>Peržiūra</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="52"/>
        <source>Edit User Agent</source>
        <translation>Redaguoti naršyklės identifikavimą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="52"/>
        <source>Add User Agent</source>
        <translation>Pridėti naršyklės identifikavimą</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="105"/>
        <source>Placeholders</source>
        <translation>Vietaženkliai</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="106"/>
        <source>Platform</source>
        <translation>Platforma</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="107"/>
        <source>Engine Version</source>
        <translation>Modulio versija</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="108"/>
        <source>Application Version</source>
        <translation>Programos versija</translation>
    </message>
</context>
<context>
    <name>Otter::WebContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="993"/>
        <source>Question</source>
        <translation>Klausimas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="993"/>
        <source>This tab has crashed.</source>
        <translation>Ši kortelė nulūžo.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="993"/>
        <source>Do you want to try to reload it?</source>
        <translation>Ar norite perkrauti?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="994"/>
        <source>Do not show this message again</source>
        <translation>Daugiau neberodyti šio pranešimo</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="1160"/>
        <source>Failed to load requested web backend: %1</source>
        <translation>Nepavyko įkelti norimo atvaizdavimo varikliuko: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="1242"/>
        <source>Select User Agent</source>
        <translation>Pasirinkite naršyklės identifikavimą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="1242"/>
        <source>Enter User Agent:</source>
        <translation>Įrašykite naršyklės identifikavimą:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="1399"/>
        <source>Start Page</source>
        <translation>Pradžios puslapis</translation>
    </message>
</context>
<context>
    <name>Otter::WebWidget</name>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="267"/>
        <source>Title: %1</source>
        <translation>Pavadinimas: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="267"/>
        <source>Address: %1</source>
        <translation>Adresas: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="313"/>
        <source>JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="313"/>
        <source>Webpage wants to close this tab, do you want to allow to close it?</source>
        <translation>Tinklalapis nori užverti šią kortelę, ar norite leisti tai padaryti?</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="314"/>
        <source>Do not show this message again</source>
        <translation>Daugiau neberodyti šio pranešimo</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="729"/>
        <source>HTML file (*.html *.htm)</source>
        <translation>HTML failas (*.html *.htm)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="729"/>
        <source>HTML file with all resources (*.html *.htm)</source>
        <translation>HTML failas su visais ištekliais (*.html *.htm)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="729"/>
        <source>Web archive (*.mht)</source>
        <translation>Saityno archyvas (*.mht)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="729"/>
        <source>PDF document (*.pdf)</source>
        <translation>PDF dokumentas (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1031"/>
        <source>Open Image in New Background Tab (%1)</source>
        <translation>Atverti paveikslą naujoje foninėje kortelėje (%1)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1035"/>
        <source>Open Image in New Tab (%1)</source>
        <translation>Atverti paveikslą naujoje kortelėje (%1)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1091"/>
        <source>Playback Rate: %1x</source>
        <translation>Atkūrimo greitis: %1x</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1175"/>
        <source>Page Default</source>
        <translation>Puslapio numatytasis</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1183"/>
        <source>Never Reload</source>
        <translation>Niekada neįkelti iš naujo</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/WebWidget.cpp" line="1187"/>
        <source>Reload Every: %n second(s)</source>
        <translation><numerusform>Įkelti iš naujo kas: %n sekundę</numerusform><numerusform>Įkelti iš naujo kas: %n sekundes</numerusform><numerusform>Įkelti iš naujo kas: %n sekundžių</numerusform><numerusform>Įkelti iš naujo kas: %n sekundžių</numerusform></translation>
    </message>
</context>
<context>
    <name>Otter::WebsiteInformationDialog</name>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="57"/>
        <source>General</source>
        <translation>Bendra</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="69"/>
        <source>Information</source>
        <translation>Informacija</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="76"/>
        <source>Address:</source>
        <translation>Adresas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="83"/>
        <source>Encoding:</source>
        <translation>Koduotė:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="90"/>
        <source>Size:</source>
        <translation>Dydis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="97"/>
        <source>Elements:</source>
        <translation>Elementų:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="104"/>
        <source>Download date:</source>
        <translation>Atsiuntimo data:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="126"/>
        <source>Title:</source>
        <translation>Pavadinimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="137"/>
        <source>Permissions</source>
        <translation>Leidimai</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="149"/>
        <source>Preferences</source>
        <translation>Nuostatos</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="171"/>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="307"/>
        <source>Details…</source>
        <translation>Išsamiau...</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="180"/>
        <source>Set cookies:</source>
        <translation>Naudoti slapukus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="187"/>
        <source>Set third-party cookies:</source>
        <translation>Naudoti trečiųjų šalių slapukus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="194"/>
        <source>Show notifications:</source>
        <translation>Rodyti pranešimus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="201"/>
        <source>Access your location:</source>
        <translation>Buvimo vietos nustatymas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="208"/>
        <source>Load plugins:</source>
        <translation>Įkelti papildinius:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="215"/>
        <source>Load images:</source>
        <translation>Įkelti paveikslus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="222"/>
        <source>Use JavaScript:</source>
        <translation>Naudoti JavaScript:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="250"/>
        <source>Show pop-up windows:</source>
        <translation>Iškylančių langų rodymas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="260"/>
        <source>Enter full screen mode:</source>
        <translation>Įjungti viso ekrano veikseną:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="271"/>
        <source>Security</source>
        <translation>Saugumas</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="285"/>
        <source>Certificate</source>
        <translation>Liudijimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="316"/>
        <source>Issued to:</source>
        <translation>Kam išduota:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="323"/>
        <source>Issued by:</source>
        <translation>Kas išdavė:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="330"/>
        <source>Issued on:</source>
        <translation>Kada išdavė:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="337"/>
        <source>Expires on:</source>
        <translation>Galioja iki:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="350"/>
        <source>Cipher</source>
        <translation>Šifravimo protokolas</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="357"/>
        <source>Protocol:</source>
        <translation>Protokolas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="364"/>
        <source>Authentication method:</source>
        <translation>Tapatybės nustatymo metodas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="371"/>
        <source>Encryption method:</source>
        <translation>Šifravimo metodas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="378"/>
        <source>Key exchange method:</source>
        <translation>Apsikeitimo raktais metodas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="417"/>
        <source>SSL Errors</source>
        <translation>SSL klaidos</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="43"/>
        <source>(unknown)</source>
        <translation>(nežinoma)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="48"/>
        <source>This website was marked as fraud.</source>
        <translation>Ši svetainė buvo pažymėta kaip kenkėjišką.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="53"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="63"/>
        <source>Your connection with this website is not private.</source>
        <translation>Jūsų ryšys su šia svetaine nėra privatus.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="58"/>
        <source>Your connection with this website is private.</source>
        <translation>Jūsų ryšys su šia svetaine yra privatus.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="68"/>
        <source>You are viewing content from your local filesystem.</source>
        <translation>Jūs matote savo vietinės failų sistemos turinį.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="73"/>
        <source>You are viewing safe page from Otter Browser.</source>
        <translation>Jūs matote saugų puslapį iš Otter naršyklės</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="78"/>
        <source>No information.</source>
        <translation>Nėra informacijos.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="85"/>
        <source>unknown</source>
        <translation>nežinoma</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="87"/>
        <source>%1 (%n blocked)</source>
        <translation><numerusform>%1 (%n užblokuotas)</numerusform><numerusform>%1 (%n užblokuoti)</numerusform><numerusform>%1 (%n užblokuotų)</numerusform><numerusform>%1 (%n užblokuotų)</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="94"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="113"/>
        <source>Only existing</source>
        <translation>Tik jau egzistuojančius</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="98"/>
        <source>Only read existing</source>
        <translation>Skaityti tik esamus</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="102"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="117"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="132"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="147"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="154"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="164"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="179"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="194"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="213"/>
        <source>Never</source>
        <translation>Niekada</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="106"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="121"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="128"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="151"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="154"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="160"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="175"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="190"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="205"/>
        <source>Always</source>
        <translation>Visada</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="136"/>
        <source>On demand</source>
        <translation>Pareikalavus</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="143"/>
        <source>Only cached</source>
        <translation>Tik iš podėlio</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="168"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="183"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="198"/>
        <source>Always ask</source>
        <translation>Visada klausti</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="209"/>
        <source>Always (open in backgound)</source>
        <translation>Visada (atverti fone)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="217"/>
        <source>Ask</source>
        <translation>Klausti</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="246"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="291"/>
        <source>Error Message</source>
        <translation>Klaidos pranešimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="246"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="291"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="262"/>
        <source>Information for %1</source>
        <translation>%1 informacija</translation>
    </message>
</context>
<context>
    <name>Otter::WebsitePreferencesDialog</name>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="14"/>
        <source>Website Preferences</source>
        <translation>Svetainės nuostatos</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="25"/>
        <source>Website:</source>
        <translation>Svetainė:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="44"/>
        <source>Content</source>
        <translation>Turinys</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="56"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="262"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="646"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="794"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="858"/>
        <source>Override</source>
        <translation>Nustelbimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="73"/>
        <source>Plugins:</source>
        <translation>Papildiniai:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="90"/>
        <source>Encoding:</source>
        <translation>Koduotė:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="110"/>
        <source>User style sheet:</source>
        <translation>Naudotojo stilių aprašas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="153"/>
        <source>Images:</source>
        <translation>Paveikslai:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="170"/>
        <source>Pop-ups:</source>
        <translation>Iškylantieji langai:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="181"/>
        <source>Privacy</source>
        <translation>Privatumas</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="205"/>
        <source>Keep until:</source>
        <translation>Laikyti iki:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="248"/>
        <source>Remember browsing history</source>
        <translation>Įsiminti naršymo žurnalą</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="269"/>
        <source>Enable cookies</source>
        <translation>Įjungti slapukus</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="294"/>
        <source>Accept cookies:</source>
        <translation>Priimti slapukus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="303"/>
        <source>Do Not Track:</source>
        <translation>Sekimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="323"/>
        <source>Cookies:</source>
        <translation>Slapukai:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="350"/>
        <source>Add…</source>
        <translation>Pridėti…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="360"/>
        <source>Properties…</source>
        <translation>Savybės…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="370"/>
        <source>Delete</source>
        <translation>Ištrinti</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="412"/>
        <source>Accept third-party cookies:</source>
        <translation>Priimti trečiųjų šalių slapukus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="448"/>
        <source>Scripting</source>
        <translation>Scenarijai</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="486"/>
        <source>Allow to receive right mouse button clicks</source>
        <translation>Leisti gauti dešiniojo pelės mygtuko spustelėjimus</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="520"/>
        <source>Allow changing of status field</source>
        <translation>Leisti keisti būsenos lauką</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="567"/>
        <source>Allow to close windows:</source>
        <translation>Leisti užverti langus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="600"/>
        <source>Allow script to hide address bar</source>
        <translation>Leisti scenarijui slėpti adreso juostą</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="627"/>
        <source>Allow moving and resizing of windows</source>
        <translation>Leisti langų perkėlimą ir langų dydžio keitimą</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="660"/>
        <source>Enable JavaScript</source>
        <translation>Įjungti JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="698"/>
        <source>Allow access to clipboard</source>
        <translation>Leisti prieigą prie iškarpinės</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="745"/>
        <source>Allow to enter full screen mode:</source>
        <translation>Leisti įjungti viso ekrano veikseną:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="758"/>
        <source>Network</source>
        <translation>Tinklas</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="787"/>
        <source>Send referrer information</source>
        <translation>Siųsti adresą iš kurio kreipiamasi</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="801"/>
        <source>Proxy:</source>
        <translation>Įgaliotasis serveris:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="811"/>
        <source>User Agent:</source>
        <translation>Naršyklės identifikavimas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="852"/>
        <source>Content Blocking</source>
        <translation>Turinio Blokavimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="865"/>
        <source>Profiles:</source>
        <translation>Profiliai:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="895"/>
        <source>Enable custom rules</source>
        <translation>Įjungti tinkintas taisykles</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="66"/>
        <source>Auto Detect</source>
        <translation>Aptikti automatiškai</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="82"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="95"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="99"/>
        <source>Ask</source>
        <translation>Klausti</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="83"/>
        <source>Block all</source>
        <translation>Visus blokuoti</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="84"/>
        <source>Open all</source>
        <translation>Visus atverti</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="85"/>
        <source>Open all in background</source>
        <translation>Visus atverti fone</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="87"/>
        <source>All images</source>
        <translation>Visi paveikslai</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="88"/>
        <source>Cached images</source>
        <translation>Podėlio paveikslai</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="89"/>
        <source>No images</source>
        <translation>Be paveikslų</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="91"/>
        <source>Enabled</source>
        <translation>Įjungta</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="92"/>
        <source>On demand</source>
        <translation>Pareikalavus</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="93"/>
        <source>Disabled</source>
        <translation>Išjungta</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="96"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="100"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="107"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="115"/>
        <source>Always</source>
        <translation>Visada</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="97"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="101"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="117"/>
        <source>Never</source>
        <translation>Niekada</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="103"/>
        <source>Inform websites that I do not want to be tracked</source>
        <translation>Nurodyti svetainėms, kad jos manęs nesektų</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="104"/>
        <source>Inform websites that I allow tracking</source>
        <translation>Nurodyti svetainėms, kad jos mane sektų</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="105"/>
        <source>Do not inform websites about my preference</source>
        <translation>Neinformuoti svetainių apie mano požiūrį į stebėjimą</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="108"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="116"/>
        <source>Only existing</source>
        <translation>Tik jau egzistuojančius</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="109"/>
        <source>Only read existing</source>
        <translation>Skaityti tik esamus</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="111"/>
        <source>Expires</source>
        <translation>Galiojimo pabaigos</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="112"/>
        <source>Current session is closed</source>
        <translation>Seanso pabaigos</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="113"/>
        <source>Always ask</source>
        <translation>Visada klausti</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="120"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="200"/>
        <source>Domain</source>
        <translation>Domenas</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="120"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="200"/>
        <source>Name</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="120"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="200"/>
        <source>Path</source>
        <translation>Kelias</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="120"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="200"/>
        <source>Value</source>
        <translation>Reikšmė</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="120"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="200"/>
        <source>Expiration Date</source>
        <translation>Galioja iki</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="206"/>
        <source>this session only</source>
        <translation>tik šiam seansui</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="453"/>
        <source>Style sheets (*.css)</source>
        <translation>Stilių aprašai (*.css)</translation>
    </message>
</context>
<context>
    <name>Otter::WindowsContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/windows/WindowsContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Ieškoti…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/windows/WindowsContentsWidget.cpp" line="267"/>
        <source>Windows and Tabs</source>
        <translation>Langai ir kortelės</translation>
    </message>
</context>
<context>
    <name>Otter::WindowsPlatformIntegration</name>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="73"/>
        <source>New tab</source>
        <translation>Nauja kortelė</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="74"/>
        <source>New private tab</source>
        <translation>Nauja privati kortelė</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="75"/>
        <source>New window</source>
        <translation>Naujas langas</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="76"/>
        <source>New private window</source>
        <translation>Naujas privatus langas</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="177"/>
        <source>Failed to run command &quot;%1&quot;, file is not executable</source>
        <translation>Nepavyko paleisti komandos &quot;%1&quot;, failas nėra vykdomasis</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="204"/>
        <source>Failed to run command &quot;%1&quot; (arguments: &quot;%2&quot;)</source>
        <translation>Nepavyko paleisti komandos &quot;%1&quot; (argumentai: &quot;%2&quot;)</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="291"/>
        <source>No valid suffix for given MIME type: %1</source>
        <translation>Nėra teisingo povardžio nurodytam MIME tipui: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="358"/>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="408"/>
        <source>Failed to load a valid application path for MIME type %1: %2</source>
        <translation>Nepavyko įkelti teisingo programos kelio MIME tipui %1: %2</translation>
    </message>
</context>
<context>
    <name>Otter::WorkspaceWidget</name>
    <message>
        <location filename="../../src/ui/WorkspaceWidget.cpp" line="550"/>
        <location filename="../../src/ui/WorkspaceWidget.cpp" line="645"/>
        <source>Arrange</source>
        <translation>Sutvarkyti</translation>
    </message>
</context>
<context>
    <name>Otter::ZoomWidget</name>
    <message>
        <location filename="../../src/modules/widgets/zoom/ZoomWidget.cpp" line="132"/>
        <location filename="../../src/modules/widgets/zoom/ZoomWidget.cpp" line="133"/>
        <source>Zoom %1%</source>
        <translation>Mastelis %1%</translation>
    </message>
</context>
<context>
    <name>actions</name>
    <message>
        <source>Reload Every</source>
        <translation>Įkelti iš naujo kas</translation>
    </message>
    <message>
        <source>1 Minute</source>
        <translation>1 minutę</translation>
    </message>
    <message>
        <source>30 Minutes</source>
        <translation>30 minučių</translation>
    </message>
    <message>
        <source>1 Hour</source>
        <translation>1 valandą</translation>
    </message>
    <message>
        <source>2 Hours</source>
        <translation>2 valandas</translation>
    </message>
    <message>
        <source>6 Hours</source>
        <translation>6 valandas</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Niekada</translation>
    </message>
    <message>
        <source>Custom…</source>
        <translation>Tinkintas...</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="286"/>
        <source>Run Macro</source>
        <translation>Paleisti makrokomandą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="286"/>
        <source>Run Arbitrary List of Actions</source>
        <translation>Paleisti pasirinktinį veiksmų sąrašą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="287"/>
        <source>Set Option</source>
        <translation>Nustatyti parinktį</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="287"/>
        <source>Set, Reset or Toggle Option</source>
        <translation>Nustatyti, atstatyti ar perjungti parinktį</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="288"/>
        <source>New Tab</source>
        <translation>Nauja kortelė</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="289"/>
        <source>New Private Tab</source>
        <translation>Nauja privataus naršymo kortelė</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="290"/>
        <source>New Window</source>
        <translation>Naujas langas</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="291"/>
        <source>New Private Window</source>
        <translation>Naujas privataus naršymo langas</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="292"/>
        <source>Open…</source>
        <translation>Atverti…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="293"/>
        <source>Save…</source>
        <translation>Įrašyti…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="294"/>
        <source>Clone Tab</source>
        <translation>Klonuoti kortelę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="295"/>
        <source>Peek Tab</source>
        <translation>Žvilgtelėti į kortelę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="296"/>
        <location filename="../../src/ui/Window.cpp" line="656"/>
        <source>Pin Tab</source>
        <translation>Prisegti kortelę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="297"/>
        <source>Detach Tab</source>
        <translation>Atskirti kortelę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="298"/>
        <source>Maximize</source>
        <translation>Išdidinti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="298"/>
        <source>Maximize Tab</source>
        <translation>Išdidinti kortelę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="299"/>
        <source>Minimize</source>
        <translation>Suskleisti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="299"/>
        <source>Minimize Tab</source>
        <translation>Suskleisti kortelę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="300"/>
        <source>Restore</source>
        <translation>Atkurti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="300"/>
        <source>Restore Tab</source>
        <translation>Atkurti kortelę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="301"/>
        <source>Stay on Top</source>
        <translation>Išlikti viršuje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="302"/>
        <source>Clear Tab History</source>
        <translation>Valyti kortelės žurnalą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="302"/>
        <source>Remove Local Tab History</source>
        <translation>Išvalyti vietinį kortelės žurnalą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="303"/>
        <location filename="../../src/modules/widgets/action/ActionWidget.cpp" line="267"/>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="150"/>
        <location filename="../../src/ui/WebWidget.cpp" line="918"/>
        <source>Purge Tab History</source>
        <translation>Sunaikinti kortelės žurnalą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="303"/>
        <source>Remove Local and Global Tab History</source>
        <translation>Išvalyti vietinį ir globalų kortelės žurnalą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="304"/>
        <location filename="../../src/ui/WebWidget.cpp" line="1103"/>
        <source>Mute Tab Media</source>
        <translation>Nutildyti kortelės mediją</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="305"/>
        <source>Suspend Tab</source>
        <translation>Pristabdyti kortelę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="306"/>
        <source>Close Tab</source>
        <translation>Užverti kortelę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="307"/>
        <source>Close Other Tabs</source>
        <translation>Užverti visas kitas korteles</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="308"/>
        <source>Close All Private Tabs</source>
        <translation>Užverti visas privačias korteles</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="308"/>
        <source>Close All Private Tabs in Current Window</source>
        <translation>Užverti visas privačias korteles esamame lange</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="309"/>
        <source>Close Private Tabs and Windows</source>
        <translation>Užverti privačias korteles ir langus</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="310"/>
        <source>Reopen Previously Closed Tab</source>
        <translation>Iš naujo atverti anksčiau užvertą kortelę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="311"/>
        <source>Maximize All</source>
        <translation>Išdidinti visas</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="312"/>
        <source>Minimize All</source>
        <translation>Sumažinti visas</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="313"/>
        <source>Restore All</source>
        <translation>Atkurti visas</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="314"/>
        <source>Cascade</source>
        <translation>Išdėstyti pakopomis</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="315"/>
        <source>Tile</source>
        <translation>Iškloti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="316"/>
        <source>Close Window</source>
        <translation>Užverti langą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="317"/>
        <source>Reopen Previously Closed Window</source>
        <translation>Iš naujo atverti anksčiau užvertą langą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="318"/>
        <source>Manage Sessions…</source>
        <translation>Tvarkyti seansus…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="319"/>
        <source>Save Current Session…</source>
        <translation>Įrašyti šį seansą…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="320"/>
        <source>Open URL</source>
        <translation>Atverti URL</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="321"/>
        <location filename="../../src/core/ActionsManager.cpp" line="336"/>
        <location filename="../../src/core/ActionsManager.cpp" line="337"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="177"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="350"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="404"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="370"/>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="222"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="389"/>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="843"/>
        <location filename="../../src/ui/Menu.cpp" line="326"/>
        <location filename="../../src/ui/WebWidget.cpp" line="797"/>
        <source>Open</source>
        <translation>Atverti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="322"/>
        <location filename="../../src/ui/WebWidget.cpp" line="754"/>
        <source>Open in This Tab</source>
        <translation>Atverti šioje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="323"/>
        <location filename="../../src/core/ActionsManager.cpp" line="338"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="179"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="352"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="372"/>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="224"/>
        <location filename="../../src/ui/Menu.cpp" line="327"/>
        <location filename="../../src/ui/WebWidget.cpp" line="759"/>
        <source>Open in New Tab</source>
        <translation>Atverti naujoje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="324"/>
        <location filename="../../src/core/ActionsManager.cpp" line="339"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="182"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="355"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="375"/>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="227"/>
        <location filename="../../src/ui/Menu.cpp" line="328"/>
        <location filename="../../src/ui/WebWidget.cpp" line="764"/>
        <source>Open in New Background Tab</source>
        <translation>Atverti foninėje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="325"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="187"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="360"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="380"/>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="232"/>
        <location filename="../../src/ui/Menu.cpp" line="330"/>
        <location filename="../../src/ui/WebWidget.cpp" line="769"/>
        <source>Open in New Window</source>
        <translation>Atverti naujame lange</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="326"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="190"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="363"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="383"/>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="235"/>
        <location filename="../../src/ui/Menu.cpp" line="331"/>
        <location filename="../../src/ui/WebWidget.cpp" line="774"/>
        <source>Open in New Background Window</source>
        <translation>Atverti naujame foniniame lange</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="327"/>
        <location filename="../../src/ui/WebWidget.cpp" line="779"/>
        <source>Open in New Private Tab</source>
        <translation>Atverti naujoje privačioje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="328"/>
        <location filename="../../src/ui/WebWidget.cpp" line="784"/>
        <source>Open in New Private Background Tab</source>
        <translation>Atverti naujoje privačioje foninėje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="329"/>
        <location filename="../../src/ui/WebWidget.cpp" line="789"/>
        <source>Open in New Private Window</source>
        <translation>Atverti naujame privačiame lange</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="330"/>
        <location filename="../../src/ui/WebWidget.cpp" line="794"/>
        <source>Open in New Private Background Window</source>
        <translation>Atverti naujame privačiame foniniame lange</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="331"/>
        <source>Copy Link to Clipboard</source>
        <translation>Kopijuoti saito adresą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="332"/>
        <location filename="../../src/ui/WebWidget.cpp" line="955"/>
        <source>Bookmark Link…</source>
        <translation>Įtraukti į adresyną…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="333"/>
        <source>Save Link Target As…</source>
        <translation>Įrašyti susietą turinį kaip…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="334"/>
        <source>Save to Downloads</source>
        <translation>Įrašyti į atsiuntimus</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="335"/>
        <source>Go to This Address</source>
        <translation>Eiti šiuo adresu</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="336"/>
        <source>Open Frame</source>
        <translation>Atverti rėmelį</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="337"/>
        <source>Open Frame in This Tab</source>
        <translation>Atverti rėmelį šioje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="338"/>
        <source>Open Frame in New Tab</source>
        <translation>Atverti rėmelį naujoje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="339"/>
        <source>Open Frame in New Background Tab</source>
        <translation>Atverti rėmelį naujoje foninėje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="340"/>
        <source>Copy Frame Link to Clipboard</source>
        <translation>Kopijuoti rėmelio nuorodą į iškarpinę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="341"/>
        <location filename="../../src/core/ActionsManager.cpp" line="372"/>
        <location filename="../../src/core/ActionsManager.cpp" line="373"/>
        <source>Reload</source>
        <translation>Įkelti iš naujo</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="341"/>
        <source>Reload Frame</source>
        <translation>Iš naujo įkelti rėmelį</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="342"/>
        <source>View Frame Source</source>
        <translation>Rodyti rėmelio šaltinį</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="343"/>
        <source>Open Image</source>
        <translation>Atverti paveikslą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="344"/>
        <source>Open Image In New Tab</source>
        <translation>Atverti paveikslą naujoje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="345"/>
        <location filename="../../src/ui/WebWidget.cpp" line="995"/>
        <source>Open Image in New Background Tab</source>
        <translation>Atverti paveikslą naujoje foninėje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="346"/>
        <source>Save Image…</source>
        <translation>Įrašyti paveikslą…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="347"/>
        <source>Copy Image to Clipboard</source>
        <translation>Kopijuoti paveikslą į iškarpinę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="348"/>
        <source>Copy Image Link to Clipboard</source>
        <translation>Kopijuoti paveikslo nuorodą į iškarpinę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="349"/>
        <source>Reload Image</source>
        <translation>Įkelti paveikslą iš naujo</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="350"/>
        <source>Image Properties…</source>
        <translation>Paveikslo savybės…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="351"/>
        <source>Save Media…</source>
        <translation>Įrašyti mediją…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="352"/>
        <source>Copy Media Link to Clipboard</source>
        <translation>Kopijuoti turinio adresą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="353"/>
        <source>Show Controls</source>
        <translation>Rodyti valdiklius</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="353"/>
        <source>Show Media Controls</source>
        <translation>Rodyti medijos valdiklius</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="354"/>
        <source>Looping</source>
        <translation>Kartoti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="354"/>
        <source>Playback Looping</source>
        <translation>Atkūrimo kartojimas</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="355"/>
        <location filename="../../src/ui/WebWidget.cpp" line="1076"/>
        <source>Play</source>
        <translation>Groti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="355"/>
        <source>Play Media</source>
        <translation>Groti mediją</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="356"/>
        <location filename="../../src/ui/WebWidget.cpp" line="1082"/>
        <source>Mute</source>
        <translation>Nutildyti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="356"/>
        <source>Mute Media</source>
        <translation>Nutildyti mediją</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="357"/>
        <source>Playback Rate</source>
        <translation>Atkūrimo greitis</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="358"/>
        <source>Log In</source>
        <translation>Prisijungti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="359"/>
        <source>Go</source>
        <translation>Eiti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="359"/>
        <source>Go to URL</source>
        <translation>Pereiti į URL</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="360"/>
        <source>Back</source>
        <translation>Grįžti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="360"/>
        <source>Go Back</source>
        <translation>Grįžti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="361"/>
        <source>Forward</source>
        <translation>Pirmyn</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="361"/>
        <source>Go Forward</source>
        <translation>Pereiti pirmyn</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="362"/>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="142"/>
        <source>Go to History Entry</source>
        <translation>Pereiti į žurnalo įrašą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="363"/>
        <source>Go to Page or Search</source>
        <translation>Eiti į puslapį arba ieškoti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="364"/>
        <source>Go to Home Page</source>
        <translation>Eiti į pradinį puslapį</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="365"/>
        <source>Go to Parent Directory</source>
        <translation>Eiti katalogu aukštyn</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="366"/>
        <source>Rewind</source>
        <translation>Grįžti į pradžią</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="366"/>
        <source>Rewind History</source>
        <translation>Atsukti žurnalą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="367"/>
        <source>Fast Forward</source>
        <translation>Pirmyn į kitą puslapį</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="368"/>
        <source>Remove History Entry</source>
        <translation>Šalinti žurnalo įrašą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="369"/>
        <source>Stop</source>
        <translation>Stabdyti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="370"/>
        <source>Stop Scheduled Page Reload</source>
        <translation>Stabdyti suplanuotą puslapio įkėlimą iš naujo</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="371"/>
        <source>Stop All Pages</source>
        <translation>Sustabdyti visus puslapius</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="373"/>
        <source>Reload or Stop</source>
        <translation>Įkelti iš naujo arba stabdyti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="374"/>
        <source>Reload and Bypass Cache</source>
        <translation>Įkelti iš naujo ir apeiti podėlį</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="375"/>
        <source>Reload All Tabs</source>
        <translation>Iš naujo įkelti visas korteles</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="376"/>
        <source>Schedule Page Reload</source>
        <translation>Suplanuoti puslapio įkėlimą iš naujo</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="377"/>
        <source>Show Context Menu</source>
        <translation>Rodyti kontekstinį meniu</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="378"/>
        <source>Undo</source>
        <translation>Atšaukti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="379"/>
        <source>Redo</source>
        <translation>Atstatyti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="380"/>
        <source>Cut</source>
        <translation>Iškirpti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="381"/>
        <source>Copy</source>
        <translation>Kopijuoti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="382"/>
        <source>Copy as Plain Text</source>
        <translation>Kopijuoti kaip gryną tekstą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="383"/>
        <source>Copy Address</source>
        <translation>Kopijuoti adresą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="384"/>
        <source>Copy to Note</source>
        <translation>Kopijuoti į pastabas</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="385"/>
        <source>Paste</source>
        <translation>Įdėti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="386"/>
        <source>Paste and Go</source>
        <translation>Įdėti ir atverti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="387"/>
        <source>Delete</source>
        <translation>Ištrinti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="388"/>
        <source>Select All</source>
        <translation>Pažymėti viską</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="389"/>
        <source>Deselect</source>
        <translation>Nuimti žymėjimą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="390"/>
        <source>Clear All</source>
        <translation>Išvalyti viską</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="391"/>
        <source>Check Spelling</source>
        <translation>Tikrinti rašybą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="392"/>
        <source>Find…</source>
        <translation>Rasti…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="393"/>
        <source>Find Next</source>
        <translation>Rasti kitą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="394"/>
        <source>Find Previous</source>
        <translation>Rasti ankstesnį</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="395"/>
        <source>Quick Find</source>
        <translation>Greita paieška</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="396"/>
        <location filename="../../src/ui/WebWidget.cpp" line="1266"/>
        <source>Search</source>
        <translation>Ieškoti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="397"/>
        <source>Create Search…</source>
        <translation>Kurti paiešką…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="398"/>
        <source>Zoom In</source>
        <translation>Artinti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="399"/>
        <source>Zoom Out</source>
        <translation>Patolinti</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="400"/>
        <source>Zoom Original</source>
        <translation>Normalus mastelis</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="401"/>
        <source>Go to Start of the Page</source>
        <translation>Eiti į puslapio pradžią</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="402"/>
        <source>Go to the End of the Page</source>
        <translation>Eiti į puslapio galą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="403"/>
        <source>Page Up</source>
        <translation>Puslapiu aukštyn</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="404"/>
        <source>Page Down</source>
        <translation>Puslapiu žemyn</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="405"/>
        <source>Page Left</source>
        <translation>Puslapiu kairėn</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="406"/>
        <source>Page Right</source>
        <translation>Puslapiu dešinėn</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="407"/>
        <source>Enter Drag Scroll Mode</source>
        <translation>Pradėti tampomos slinkties veikseną</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="408"/>
        <source>Enter Move Scroll Mode</source>
        <translation>Pradėti judančios slinkties veikseną</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="409"/>
        <source>Exit Scroll Mode</source>
        <translation>Išjungti slinkties veikseną</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="410"/>
        <source>Print…</source>
        <translation>Spausdinti…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="411"/>
        <source>Print Preview</source>
        <translation>Spaudinio peržiūra</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="412"/>
        <source>Take Screenshot</source>
        <translation>Padaryti ekrano kopiją</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="413"/>
        <source>Activate Address Field</source>
        <translation>Aktyvinti adreso lauką</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="414"/>
        <source>Activate Search Field</source>
        <translation>Aktyvinti paieškos lauką</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="415"/>
        <source>Activate Content</source>
        <translation>Aktyvinti turinį</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="416"/>
        <source>Go to Previously Used Tab</source>
        <translation>Aktyvinti prieš tai naudotą kortelę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="417"/>
        <source>Go to Least Recently Used Tab</source>
        <translation>Aktyvinti seniausiai naudotą kortelę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="418"/>
        <source>Activate Tab</source>
        <translation>Aktyvinti kortelę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="419"/>
        <source>Go to Tab on Left</source>
        <translation>Pereiti į kortelę kairėje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="420"/>
        <source>Go to Tab on Right</source>
        <translation>Pereiti į kortelę dešinėje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="421"/>
        <source>Activate Window</source>
        <translation>Aktyvuoti langą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="422"/>
        <source>Manage Bookmarks</source>
        <translation>Tvarkyti adresyną</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="423"/>
        <source>Bookmark Page…</source>
        <translation>Įtraukti puslapį į adresyną…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="424"/>
        <source>Bookmark All Open Pages</source>
        <translation>Įtraukti į adresyną visus atvertus puslapius</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="425"/>
        <source>Open Bookmark</source>
        <translation>Atverti adresyno įrašą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="426"/>
        <source>Quick Bookmark Access</source>
        <translation>Greitoji adresyno prieiga</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="427"/>
        <source>Cookies</source>
        <translation>Slapukai</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="428"/>
        <source>Load All Plugins on the Page</source>
        <translation>Įkelti visus puslapyje esančius papildinius</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="429"/>
        <source>Enable JavaScript</source>
        <translation>Įjungti JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="430"/>
        <source>Enable Referrer</source>
        <translation>Siųsti duomenis apie nukreipiantį puslapį</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="431"/>
        <source>View Source</source>
        <translation>Pirminis tekstas</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="432"/>
        <source>Inspect Page</source>
        <translation>Tirti puslapį</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="433"/>
        <source>Inspect Element…</source>
        <translation>Tirti elementą…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="434"/>
        <source>Work Offline</source>
        <translation>Atsijungti nuo tinklo</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="435"/>
        <location filename="../../src/ui/Menu.cpp" line="416"/>
        <source>Full Screen</source>
        <translation>Visas ekranas</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="436"/>
        <source>Show Tab Switcher</source>
        <translation>Rodyti kortelių perjungiklį</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="437"/>
        <source>Show Toolbar</source>
        <translation>Rodyti įrankių juostą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="438"/>
        <source>Show Menubar</source>
        <translation>Rodyti meniu juostą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="439"/>
        <source>Show Tabbar</source>
        <translation>Rodyti kortelių juostą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="440"/>
        <source>Show Sidebar</source>
        <translation>Rodyti šoninę juostą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="441"/>
        <source>Show Error Console</source>
        <translation>Rodyti klaidų pultą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="442"/>
        <source>Lock Toolbars</source>
        <translation>Užrakinti įrankių juostas</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="443"/>
        <source>Reset to Defaults…</source>
        <translation>Atstatyti į numatytuosius...</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="443"/>
        <source>Reset Toolbars to Defaults…</source>
        <translation>Atstatyti įrankių juostas į numatytąsias...</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="444"/>
        <source>Show Panel</source>
        <translation>Rodyti skydelį</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="444"/>
        <source>Show Specified Panel in Sidebar</source>
        <translation>Rodyti nurodytą skydelį šoninėje juostoje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="445"/>
        <source>Open Panel as Tab</source>
        <translation>Atverti skydelį kaip kortelę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="445"/>
        <source>Open Curent Sidebar Panel as Tab</source>
        <translation>Atverti esamą šoninės juostos skydelį kaip kortelę</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="446"/>
        <source>Content Blocking…</source>
        <translation>Turinio blokavimas…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="447"/>
        <source>View History</source>
        <translation>Žiūrėti žurnalą</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="448"/>
        <source>Clear History…</source>
        <translation>Valyti naršymo duomenis…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="449"/>
        <source>Addons</source>
        <translation>Priedai</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="450"/>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="210"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="66"/>
        <source>Notes</source>
        <translation>Pastabos</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="451"/>
        <source>Passwords</source>
        <translation>Slaptažodžiai</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="452"/>
        <source>Downloads</source>
        <translation>Atsiuntimai</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="453"/>
        <source>Preferences…</source>
        <translation>Nuostatos…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="454"/>
        <source>Website Preferences…</source>
        <translation>Svetainės nuostatos…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="455"/>
        <source>Quick Preferences</source>
        <translation>Greitosios nuostatos</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="456"/>
        <source>Reset Options</source>
        <translation>Atstatyti parinktis</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="457"/>
        <source>Website Information…</source>
        <translation>Svetainės informacija…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="458"/>
        <source>Website Certificate Information…</source>
        <translation>Svetainės liudijimo informacija…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="459"/>
        <source>Switch Application Language…</source>
        <translation>Perjungti programos kalbą…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="460"/>
        <source>Check for Updates…</source>
        <translation>Tikrinti ar yra atnaujinimų…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="461"/>
        <source>Diagnostic Report…</source>
        <translation>Diagnostinė ataskaita…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="462"/>
        <source>About Otter…</source>
        <translation>Apie Otter…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="463"/>
        <source>About Qt…</source>
        <translation>Apie Qt…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="464"/>
        <source>Exit</source>
        <translation>Išeiti</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1532"/>
        <source>Set %1</source>
        <translation>Nustatyti %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1536"/>
        <source>Set %1 for %2</source>
        <translation>Nustatyti %1, skirtą %2</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1543"/>
        <source>Reset %1</source>
        <translation>Atstatyti %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1547"/>
        <source>Reset %1 for %2</source>
        <translation>Atstatyti %1, skirtą %2</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1556"/>
        <source>Toggle %1</source>
        <translation>Perjungti %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1560"/>
        <source>Toggle %1 for %2</source>
        <translation>Perjungti %1, skirtą %2</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="46"/>
        <source>Menu Bar</source>
        <translation>Meniu juosta</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="47"/>
        <source>Bookmarks Bar</source>
        <translation>Adresyno juosta</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="48"/>
        <source>Tab Bar</source>
        <translation>Kortelių juosta</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="49"/>
        <source>Address Bar</source>
        <translation>Adreso juosta</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="50"/>
        <source>Navigation Bar</source>
        <translation>Naršymo juosta</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="51"/>
        <source>Progress Bar</source>
        <translation>Eigos juosta</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="52"/>
        <source>Sidebar</source>
        <translation>Šoninė juosta</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="53"/>
        <source>Status Bar</source>
        <translation>Būsenos juosta</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="54"/>
        <source>Error Console</source>
        <translation>Klaidų pultas</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="198"/>
        <location filename="../../src/ui/Menu.cpp" line="73"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="54"/>
        <source>Bookmarks</source>
        <translation>Adresynas</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="202"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="58"/>
        <source>Transfers</source>
        <translation>Atsiuntimai</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="206"/>
        <location filename="../../src/ui/Menu.cpp" line="60"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="62"/>
        <source>History</source>
        <translation>Žurnalas</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="366"/>
        <source>Remove Bookmark</source>
        <translation>Pašalinti adresyno įrašą</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="479"/>
        <source>Remove Cookie</source>
        <translation>Šalinti slapuką</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="400"/>
        <source>Update</source>
        <translation>Atnaujinti</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="365"/>
        <source>Copy address of source page</source>
        <translation>Kopijuoti šaltinio puslapio adresą</translation>
    </message>
    <message>
        <location filename="../../src/ui/MainWindow.cpp" line="2338"/>
        <source>Close Panel</source>
        <translation>Užverti skydelį</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="57"/>
        <source>File</source>
        <translation>Failas</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="58"/>
        <source>Edit</source>
        <translation>Taisa</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="59"/>
        <source>View</source>
        <translation>Rodinys</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="61"/>
        <source>Tools</source>
        <translation>Įrankiai</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="62"/>
        <source>Help</source>
        <translation>Pagalba</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="63"/>
        <source>Page</source>
        <translation>Puslapis</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="64"/>
        <source>Print</source>
        <translation>Spausdinti</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="65"/>
        <source>Settings</source>
        <translation>Nustatymai</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="66"/>
        <source>Frame</source>
        <translation>Polangis</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="95"/>
        <source>Character Encoding</source>
        <translation>Simbolių koduotė</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="105"/>
        <source>Closed Tabs and Windows</source>
        <translation>Užvertos kortelės ir langai</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="123"/>
        <source>Dictionaries</source>
        <translation>Žodynai</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="129"/>
        <source>Import and Export</source>
        <translation>Importavimas ir eksportavimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="130"/>
        <source>Import Opera Bookmarks…</source>
        <translation>Importuoti Opera adresyną…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="131"/>
        <source>Import HTML Bookmarks…</source>
        <translation>Importuoti HTML adresyną…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="133"/>
        <source>Import OPML Feeds…</source>
        <translation>Importuoti OPML kanalus…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="135"/>
        <source>Import Opera Notes…</source>
        <translation>Importuoti Opera pastabas...</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="137"/>
        <source>Import Opera Search Engines…</source>
        <translation>Importuoti Opera paieškos sistemas...</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="139"/>
        <source>Import Opera Session…</source>
        <translation>Importuoti Opera seansą…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="152"/>
        <source>Insert Note</source>
        <translation>Įterpti pastabą</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="166"/>
        <source>Open with</source>
        <translation>Atverti naudojant</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="172"/>
        <source>Proxy</source>
        <translation>Įgaliotasis serveris</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="181"/>
        <source>Search Using</source>
        <translation>Ieškoti naudojant</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="187"/>
        <source>Sessions</source>
        <translation>Seansai</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="200"/>
        <source>Style</source>
        <translation>Stilius</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="220"/>
        <source>Toolbars</source>
        <translation>Įrankių juostos</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="226"/>
        <source>User Agent</source>
        <translation>Naršyklės identifikavimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="235"/>
        <source>Validate Using</source>
        <translation>Patikrinti naudojant</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="241"/>
        <source>Tabs and Windows</source>
        <translation>Kortelės ir langai</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="404"/>
        <source>Keep Cookie Until</source>
        <translation>Laikyti slapuką iki</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="408"/>
        <source>Accept Cookies</source>
        <translation>Priimti slapukus</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="412"/>
        <source>Accept Third-party Cookies</source>
        <translation>Priimti trečiųjų šalių slapukus</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="420"/>
        <source>Geolocation</source>
        <translation>Buvimo vietos nustatymas</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="424"/>
        <source>Images</source>
        <translation>Paveikslai</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="428"/>
        <source>Capture Audio</source>
        <translation>Paimti garsą</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="432"/>
        <source>Capture Video</source>
        <translation>Paimti vaizdą</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="436"/>
        <source>Playback Audio</source>
        <translation>Groti garsą</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="440"/>
        <source>Notifications</source>
        <translation>Pranešimai</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="444"/>
        <source>Plugins</source>
        <translation>Papildiniai</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="448"/>
        <source>Pointer Lock</source>
        <translation>Rodyklės užrakinimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="452"/>
        <source>Closing Windows by JavaScript</source>
        <translation>JavaScript langų užvėrimas</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="456"/>
        <source>Pop-Ups</source>
        <translation>Iškylantieji langai</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="624"/>
        <location filename="../../src/ui/Menu.cpp" line="791"/>
        <source>Open All</source>
        <translation>Atverti visus</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="677"/>
        <source>This Folder</source>
        <translation>Šis aplankas</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="755"/>
        <source>Ask What to Do</source>
        <translation>Klausti ką daryti</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="759"/>
        <source>Always Allow</source>
        <translation>Visada leisti</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="763"/>
        <source>Always Deny</source>
        <translation>Visada drausti</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="767"/>
        <source>Expires</source>
        <translation>Galiojimo pabaigos</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="771"/>
        <source>Current Session is Closed</source>
        <translation>Dabartinis seansas yra užvertas</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="775"/>
        <source>Always</source>
        <translation>Visada</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="779"/>
        <source>Only Existing</source>
        <translation>Tik esamus</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="783"/>
        <source>Only Read Existing</source>
        <translation>Skaityti tik esamus</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="787"/>
        <source>Ignore</source>
        <translation>Nepaisyti</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="795"/>
        <source>Open in Background</source>
        <translation>Atverti fone</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="799"/>
        <source>Block All</source>
        <translation>Blokuoti visus</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="803"/>
        <source>Only Cached</source>
        <translation>Tik iš podėlio</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="807"/>
        <source>Enabled</source>
        <translation>Įjungta</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="811"/>
        <source>On Demand</source>
        <translation>Pareikalavus</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="815"/>
        <source>Disabled</source>
        <translation>Išjungta</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="842"/>
        <source>Auto Detect</source>
        <translation>Automatiškai aptikti</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="895"/>
        <source>Clear</source>
        <translation>Išvalyti</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1053"/>
        <source>Default Application</source>
        <translation>Numatytoji programa</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1061"/>
        <source>Unknown</source>
        <translation>Nežinoma</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1202"/>
        <source>Default Style</source>
        <translation>Numatytasis stilius</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1256"/>
        <source>Add New</source>
        <translation>Pridėti naują</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1259"/>
        <source>Add Toolbar…</source>
        <translation>Pridėti įrankių juostą...</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1260"/>
        <source>Add Bookmarks Bar…</source>
        <translation>Pridėti adresyno juostą...</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1261"/>
        <source>Add Sidebar…</source>
        <translation>Pridėti šoninę juostą…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1343"/>
        <source>Custom User Agent…</source>
        <translation>Tinkintas naršyklės identifikavimas...</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1387"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="955"/>
        <source>Edit Link Bookmark…</source>
        <translation>Redaguoti adresyno įrašo nuorodą…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="987"/>
        <source>Open Image in This Tab</source>
        <translation>Atverti paveikslą šioje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="991"/>
        <source>Open Image in New Tab</source>
        <translation>Atverti paveikslą naujoje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="999"/>
        <source>Open Image in New Window</source>
        <translation>Atverti paveikslą naujame lange</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1003"/>
        <source>Open Image in New Background Window</source>
        <translation>Atverti paveikslą naujame foniniame lange</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1007"/>
        <source>Open Image in New Private Tab</source>
        <translation>Atverti paveikslą naujoje privačioje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1011"/>
        <source>Open Image in New Private Background Tab</source>
        <translation>Atverti paveikslą naujoje privačioje foninėje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1015"/>
        <source>Open Image in New Private Window</source>
        <translation>Atverti paveikslą naujame privačiame lange</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1019"/>
        <source>Open Image in New Private Background Window</source>
        <translation>Atverti paveikslą naujame privačiame foniniame lange</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1056"/>
        <source>Save Video…</source>
        <translation>Įrašyti video…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1056"/>
        <source>Save Audio…</source>
        <translation>Įrašyti audio…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1061"/>
        <source>Copy Video Link to Clipboard</source>
        <translation>Kopijuoti vaizdo įrašo nuorodą į iškarpinę</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1061"/>
        <source>Copy Audio Link to Clipboard</source>
        <translation>Kopijuoti garso įrašo nuorodą į iškarpinę</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1076"/>
        <source>Pause</source>
        <translation>Pristabdyti</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1082"/>
        <source>Unmute</source>
        <translation>Įjungti garsą</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1103"/>
        <source>Unmute Tab Media</source>
        <translation>Įjungti kortelės medijos garsą</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1137"/>
        <source>Purge History Entry</source>
        <translation>Išvalyti žurnalo įrašą</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1281"/>
        <source>Edit Bookmark…</source>
        <translation>Redaguoti adresyno įrašą…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1281"/>
        <source>Add Bookmark…</source>
        <translation>Pridėti į adresyną…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Window.cpp" line="656"/>
        <source>Unpin Tab</source>
        <translation>Atsegti kortelę</translation>
    </message>
    <message>
        <location filename="../../src/ui/WorkspaceWidget.cpp" line="543"/>
        <source>Close</source>
        <translation>Užverti</translation>
    </message>
</context>
<context>
    <name>addons</name>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="123"/>
        <source>Addons</source>
        <translation>Priedai</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="124"/>
        <source>Bookmarks</source>
        <translation>Adresynas</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="125"/>
        <source>Cache</source>
        <translation>Podėlis</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="126"/>
        <source>Advanced Configuration</source>
        <translation>Išplėstinė konfigūracija</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="127"/>
        <source>Cookies</source>
        <translation>Slapukai</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="128"/>
        <source>Feeds</source>
        <translation>Kanalai</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="129"/>
        <source>History</source>
        <translation>Žurnalas</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="130"/>
        <source>Links</source>
        <translation>Nuorodos</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="131"/>
        <source>Notes</source>
        <translation>Pastabos</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="132"/>
        <source>Page Information</source>
        <translation>Puslapio informacija</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="133"/>
        <source>Passwords</source>
        <translation>Slaptažodžiai</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="134"/>
        <source>Tab History</source>
        <translation>Kortelių žurnalas</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="135"/>
        <source>Downloads</source>
        <translation>Atsiuntimai</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="136"/>
        <source>Windows and Tabs</source>
        <translation>Langai ir kortelės</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="105"/>
        <source>Failed to open content blocking profile file: %1</source>
        <translation>Nepavyko atverti turinio blokavimo profilio failo: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="604"/>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="632"/>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="645"/>
        <source>Failed to update content blocking profile: %1</source>
        <translation>Nepavyko atnaujinti turinio blokavimo profilio: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="618"/>
        <source>Failed to update content blocking profile: checksum mismatch</source>
        <translation>Nepavyko atnaujinti turinio blokavimo profilio: kontrolinės sumos neatitikimas</translation>
    </message>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="885"/>
        <source>Failed to update content blocking profile, update URL is empty</source>
        <translation>Nepavyko atnaujinti turinio blokavimo profilio, atnaujinimo URL yra tuščias</translation>
    </message>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="889"/>
        <source>Failed to update content blocking profile, update URL (%1) is invalid</source>
        <translation>Nepavyko atnaujinti turinio blokavimo profilio, atnaujinimo URL (%1) yra neteisingas</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="200"/>
        <source>Failed to find User Script file: %1</source>
        <translation>Nepavyko rasti naudotojo scenarijaus failo: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="125"/>
        <source>URL to open</source>
        <translation>atverti URL</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="126"/>
        <source>Uses &lt;path&gt; as cache directory</source>
        <translation>Podėliui naudoti &lt;path&gt; aplanką</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="127"/>
        <source>Uses &lt;path&gt; as profile directory</source>
        <translation>Profiliui naudoti &lt;path&gt; aplanką</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="128"/>
        <source>Restores session &lt;session&gt; if it exists</source>
        <translation>Atkuria seansą &lt;session&gt; (jei toks yra)</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="129"/>
        <source>Starts private session</source>
        <translation>Pradėti privatų seansą</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="130"/>
        <source>Forces session chooser dialog</source>
        <translation>Priverstinai rodo seanso selektoriaus dialogą</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="131"/>
        <source>Sets profile and cache paths to directories inside the same directory as that of application binary</source>
        <translation>Nustato profilio ir podėlio kelius į tą patį katalogą, kuriame yra pati programa</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="132"/>
        <source>Loads URL in new tab</source>
        <translation>Įkelia URL naujoje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="133"/>
        <source>Loads URL in new private tab</source>
        <translation>Įkelia URL naujoje privačioje kortelėje</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="134"/>
        <source>Loads URL in new window</source>
        <translation>Įkelia URL naujame lange</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="135"/>
        <source>Loads URL in new private window</source>
        <translation>Įkelia URL naujame privačiame lange</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="136"/>
        <source>Tells application to avoid writing data to disk</source>
        <translation>Vengti rašyti duomenis į diską</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="137"/>
        <source>Prints out diagnostic report and exits application</source>
        <translation>Parodyti diagnostinius duomenis ir išjungti programą</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkAutomaticProxy.cpp" line="414"/>
        <source>Failed to parse entry of proxy auto-config (PAC): %1</source>
        <translation>Nepavyko išanalizuoti įgaliotojo serverio automatinės konfigūracijos (PAC) įrašo: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/PlatformIntegration.cpp" line="135"/>
        <source>Failed to install update
Updater: %1
Script: %2</source>
        <translation>Nepavyko įdiegti atnaujinimo
Atnaujinimas: %1
Skriptas: %2</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionsManager.h" line="161"/>
        <source>Start Page</source>
        <translation>Pradžios puslapis</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionsManager.h" line="165"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
    <message>
        <location filename="../../src/core/UpdateChecker.cpp" line="44"/>
        <source>Unable to check for updates. Invalid URL: %1</source>
        <translation>Nepavyko patikrinti atnaujinimų. Neteisingas URL: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/UpdateChecker.cpp" line="62"/>
        <source>Unable to check for updates: %1</source>
        <translation>Nepavyko patikrinti atnaujinimų: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/UpdateChecker.cpp" line="95"/>
        <source>Unable to parse version number: %1</source>
        <translation>Nepavyko išanalizuoti versijos numerio: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Updater.cpp" line="84"/>
        <source>Downloaded update script is not valid: %1</source>
        <translation>Atsisiųstas atnaujinimo scenarijus nėra teisingas: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Updater.cpp" line="104"/>
        <source>Unable to download update: %1</source>
        <translation>Nepavyko atsisiųsti atnaujinimo: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/UserScript.cpp" line="65"/>
        <source>Failed to open User Script file: %1</source>
        <translation>Nepavyko atverti naudotojo scenarijaus failo: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/UserScript.cpp" line="151"/>
        <source>Invalid match rule for User Script: %1</source>
        <translation>Neteisinga naudotojo scenarijaus atitikimo taisyklė: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/UserScript.cpp" line="228"/>
        <source>Failed to locate header of User Script file</source>
        <translation>Nepavyko nustatyti naudotojo scenarijaus failo antraštės vietos</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="163"/>
        <source>Default</source>
        <translation>Įprastas</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="80"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineUrlRequestInterceptor.cpp" line="157"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="691"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="249"/>
        <source>Request blocked by rule from profile %1:
%2</source>
        <translation>Užklausa užblokuota pagal taisyklę iš profilio %1:
%2</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineUrlRequestInterceptor.cpp" line="157"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="691"/>
        <source>(Unknown)</source>
        <translation>(Nežinoma)</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="503"/>
        <source>Failed to run File Associations Manager, error code: %1
Application ID: %2</source>
        <translation>Nepavyko paleisti failų susiejimo tvarkytuvės, klaidos kodas: %1
Programos ID: %2</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="522"/>
        <source>Failed to run File Associations Manager, error code: %1</source>
        <translation>Nepavyko paleisti failų susiejimo tvarkytuvės, klaidos kodas: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="577"/>
        <source>Failed to register application to system registry: %1, %2</source>
        <translation>Nepavyko užregistruoti programos į sistemos registrą: %1, %2</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="211"/>
        <source>Failed to load custom rules: invalid adblock header</source>
        <translation>Nepavyko įkelti tinkintų taisyklių: neteisinga reklamos blokavimo antraštė</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="519"/>
        <source>Failed to create a file with custom rules: %1</source>
        <translation>Nepavyko sukurti failo su tinkintomis taisyklėmis: %1</translation>
    </message>
</context>
<context>
    <name>migrations</name>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="193"/>
        <source>Keyboard and Mouse Configuration Profiles</source>
        <translation>Klaviatūros ir pelės konfigūracijos profiliai</translation>
    </message>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="327"/>
        <source>Options</source>
        <translation>Parinktys</translation>
    </message>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="363"/>
        <source>Search Engines</source>
        <translation>Paieškos sistemos</translation>
    </message>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="486"/>
        <source>Sessions</source>
        <translation>Seansai</translation>
    </message>
</context>
<context>
    <name>notifications</name>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="87"/>
        <source>Feed Updated</source>
        <translation>Kanalas atnaujintas</translation>
    </message>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="87"/>
        <source>Feed update was completed</source>
        <translation>Kanalo atnaujinimas buvo užbaigtas</translation>
    </message>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="88"/>
        <source>Download Completed</source>
        <translation>Atsiuntimas užbaigtas</translation>
    </message>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="88"/>
        <source>File download was completed</source>
        <translation>Failo atsiuntimas buvo užbaigtas</translation>
    </message>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="89"/>
        <source>Update Available</source>
        <translation>Galimas atnaujinimas</translation>
    </message>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="89"/>
        <source>Update is available to be downloaded</source>
        <translation>Galima atsiųsti atnaujinimą</translation>
    </message>
</context>
<context>
    <name>proxies</name>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.cpp" line="693"/>
        <location filename="../../src/core/NetworkManagerFactory.h" line="90"/>
        <source>System Configuration</source>
        <translation>Sistemos konfigūracija</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.h" line="85"/>
        <source>No Proxy</source>
        <translation>Jokio įgaliotojo serverio</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.h" line="94"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
</context>
<context>
    <name>userAgents</name>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.cpp" line="582"/>
        <location filename="../../src/core/NetworkManagerFactory.cpp" line="723"/>
        <location filename="../../src/core/NetworkManagerFactory.h" line="118"/>
        <source>Default User Agent</source>
        <translation>Numatytasis naršyklės identifikavimas</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.h" line="123"/>
        <source>Mask as {name}</source>
        <translation>Maskuoti kaip {name}</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.h" line="127"/>
        <source>(Untitled)</source>
        <translation>(Be pavadinimo)</translation>
    </message>
</context>
<context>
    <name>utils</name>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="52"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="61"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="922"/>
        <source>Try Again</source>
        <translation>Bandyti dar kartą</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="185"/>
        <source>You tried to access the address &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;, which was blocked by content blocker.</source>
        <translation>Jūs bandėte pasiekti adresą &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;, kuris buvo užblokuotas turinio blokavimo.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="189"/>
        <source>The owner of &lt;strong&gt;%1&lt;/strong&gt; has configured their page improperly. To protect your information from being stolen, connection to this website was aborted.</source>
        <translation>&lt;strong&gt;%1&lt;/strong&gt; savininkas netinkamai sukonfigūravo savo puslapį. Tam, kad jūsų duomenys būtų apsaugoti nuo vagystės, ryšys su šia svetaine buvo nutrauktas.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="193"/>
        <source>This web page at &lt;strong&gt;%1&lt;/strong&gt; has been reported as a web forgery. To protect your information from being stolen, connection to this website was aborted.</source>
        <translation>Apie šį interneto puslapį, adresu &lt;strong&gt;%1&lt;/strong&gt;, buvo pranešta kaip apie internetinę klastotę. Tam, kad jūsų duomenys būtų apsaugoti nuo vagystės, ryšys su šia svetaine buvo nutrauktas.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="197"/>
        <source>You tried to access the address &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;, which is currently unavailable. Please make sure that the web address (URL) is correctly spelled and punctuated, then try reloading the page.</source>
        <translation>Jūs bandėte gauti prieigą prie adreso &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;, kuris šiuo metu yra neprieinamas. Prašome įsitikinti, kad saityno adresas (URL) yra teisingai parašytas ir teisingai uždėti skyrybos ženklai, o tuomet pabandyti iš naujo įkelti puslapį.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="201"/>
        <source>Check the file name for capitalization or other typing errors.</source>
        <translation>Patikrinkite failo pavadinimo didžiąsias ir mažąsias raides bei kitas rašybos klaidas.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="201"/>
        <source>Check to see if the file was moved, renamed or deleted.</source>
        <translation>Patikrinkite ar failas nebuvo perkeltas, pervadintas ar ištrintas.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="205"/>
        <source>Check the address for typing errors.</source>
        <translation>Patikrinkite ar adrese nėra rašybos klaidų.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="205"/>
        <source>Make sure your internet connection is active and check whether other applications that rely on the same connection are working.</source>
        <translation>Įsitikinkite, kad interneto ryšys yra aktyvus ir patikrinkite ar kitos, tą patį ryšį naudojančios, programos veikia.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="205"/>
        <source>Check that the setup of any internet security software is correct and does not interfere with ordinary web browsing.</source>
        <translation>Patikrinkite ar bet kokios internetinio saugumo programinės įrangos sąranka yra teisinga ir ar ji nekliudo įprastam naršymui.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="205"/>
        <source>Try pressing the F12 key on your keyboard and disabling proxy servers, unless you know that you are required to use a proxy to connect to the internet, and then reload the page.</source>
        <translation>Pabandykite savo klaviatūroje paspausti klavišą F12 ir išjungti įgaliotuosius serverius, nebent žinote, kad prisijungimui prie interneto turite naudoti įgaliotąjį serverį, o tuomet pabandykite iš naujo įkelti puslapį.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="216"/>
        <source>Address blocked</source>
        <translation>Adresas užblokuotas</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="220"/>
        <source>Connection is insecure</source>
        <translation>Ryšys yra nesaugus</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="224"/>
        <source>Connection refused</source>
        <translation>Ryšys atmestas</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="228"/>
        <source>File not found</source>
        <translation>Failas nerastas</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="232"/>
        <source>Fraud attempt</source>
        <translation>Bandymas apgauti</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="236"/>
        <source>Server not found</source>
        <translation>Serveris nerastas</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="240"/>
        <source>Unsupported address type</source>
        <translation>Nepalaikomas adreso tipas</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="244"/>
        <source>Network error</source>
        <translation>Tinklo klaida</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="279"/>
        <source>Advanced</source>
        <translation>Išplėstinės</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="322"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="423"/>
        <source>Today at %1</source>
        <translation>Šiandien ties %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="428"/>
        <source>Yesterday at %1</source>
        <translation>Vakar ties %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="434"/>
        <source>%1 at %2</source>
        <translation>%1 ties %2</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="474"/>
        <location filename="../../src/core/Utils.cpp" line="481"/>
        <location filename="../../src/core/Utils.cpp" line="551"/>
        <location filename="../../src/core/Utils.cpp" line="617"/>
        <source>All files (*)</source>
        <translation>Visi failai (*)</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="555"/>
        <source>Open Files</source>
        <translation>Atverti failus</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="559"/>
        <source>Open File</source>
        <translation>Atverti failą</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="613"/>
        <source>%1 files (*.%2)</source>
        <translation>%1 failai (*.%2)</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="623"/>
        <source>Save File</source>
        <translation>Įrašyti failą</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="645"/>
        <location filename="../../src/core/Utils.cpp" line="654"/>
        <source>Warning</source>
        <translation>Įspėjimas</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="645"/>
        <source>This path is already used by different download, pick another one.</source>
        <translation>Šis kelias jau yra naudojamas kito atsiuntimo, pasirinkite kitą kelią.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="654"/>
        <source>Target path is not writable.
Select another one.</source>
        <translation>Paskirties kelias nėra įrašomas.
Pasirinkite kitą.</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="890"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="906"/>
        <source>Go Back</source>
        <translation>Grįžti</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="895"/>
        <source>Load Blocked Page</source>
        <translation>Įkelti užblokuotą puslapį</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="911"/>
        <source>Load Insecure Page</source>
        <translation>Įkelti nesaugų puslapį</translation>
    </message>
</context>
</TS>