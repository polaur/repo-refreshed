<?xml version="1.0" ?><!DOCTYPE TS><TS language="sv" version="2.1">
<context>
    <name>Otter::AcceptCookieDialog</name>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="14"/>
        <source>Accept Cookie</source>
        <translation>Ta emot Kaka</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="35"/>
        <source>Name:</source>
        <translation>Namn:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="45"/>
        <source>Value:</source>
        <translation>Värde:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="55"/>
        <source>Expiration date:</source>
        <translation>Utgångsdatum:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="69"/>
        <source>Send for:</source>
        <translation>Sänd för:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="83"/>
        <source>Accessible using JavaScript:</source>
        <translation>Åtkomlig med JavaScript:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="100"/>
        <source>Domain:</source>
        <translation>Domän:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="47"/>
        <source>Website %1 requested to add new cookie.</source>
        <translation>Webbplatsen %1 begärde att få lägga till en ny kaka.</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="51"/>
        <source>Website %1 requested to update existing cookie.</source>
        <translation>Webbplatsen %1 gjorde en förfrågning om att uppdatera existerande kaka.</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="55"/>
        <source>Website %1 requested to remove existing cookie.</source>
        <translation>Webbplatsen %1 begärde att få ta bort existerande kaka.</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="61"/>
        <source>This session only</source>
        <translation>Enbart denna sessionen</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="62"/>
        <source>Secure connections only</source>
        <translation>Enbart säkra anslutningar</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="62"/>
        <source>Any type of connection</source>
        <translation>Alla typer anslutuningar</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="63"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="63"/>
        <source>No</source>
        <translation>Nej</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="64"/>
        <source>Accept</source>
        <translation>Ta emot</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="68"/>
        <source>Accept For This Session Only</source>
        <translation>Ta emot enbart för den här sessionen</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="71"/>
        <source>Discard</source>
        <translation>Kasta bort</translation>
    </message>
</context>
<context>
    <name>Otter::AcceptLanguageDialog</name>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="14"/>
        <source>Preferred Webpage Language</source>
        <translation>Föredraget språk för webbplatser</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="20"/>
        <source>To add language, please choose one from list or type its code.</source>
        <translation>Välj ett språk från listan eller skriv dess kod.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="39"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="82"/>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="107"/>
        <source>Move Up</source>
        <translation>Flytta Upp</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="133"/>
        <source>Move Down</source>
        <translation>Flytta Ned</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="38"/>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="113"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="38"/>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="113"/>
        <source>Code</source>
        <translation>Kod</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="61"/>
        <source>Unknown [%1]</source>
        <translation>Okänt [%1]</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="78"/>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="142"/>
        <source>Any other</source>
        <translation>Något annat</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="79"/>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="146"/>
        <source>System language (%1 - %2)</source>
        <translation>Sytemspråk (%1 - %2)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="154"/>
        <source>Custom</source>
        <translation>Anpassat</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="158"/>
        <source>Unknown</source>
        <translation>Okänt</translation>
    </message>
</context>
<context>
    <name>Otter::Action</name>
    <message>
        <location filename="../../src/ui/Action.cpp" line="119"/>
        <source>Creating instance of deprecated action: %1</source>
        <translation>Skapar instans av föråldrad aktion: %1</translation>
    </message>
</context>
<context>
    <name>Otter::ActionComboBoxWidget</name>
    <message>
        <location filename="../../src/ui/ActionComboBoxWidget.cpp" line="84"/>
        <source>Select Action</source>
        <translation>Välj handling</translation>
    </message>
    <message>
        <location filename="../../src/ui/ActionComboBoxWidget.cpp" line="155"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
</context>
<context>
    <name>Otter::AdblockContentFiltersProfile</name>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="708"/>
        <source>(Unknown)</source>
        <translation>(Okänd)</translation>
    </message>
</context>
<context>
    <name>Otter::AddonsContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="119"/>
        <source>User Scripts</source>
        <translation>Användarsskript</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="147"/>
        <source>Select Files</source>
        <translation>Välj filer</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="147"/>
        <source>User Script files (*.js)</source>
        <translation>Användars-skriptfiler (*.js)</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="183"/>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="365"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="184"/>
        <source>User Script with this name already exists:
%1</source>
        <translation>Det finns redan ett användarsskript med detta namnet:
%1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="185"/>
        <source>Do you want to replace it?</source>
        <translation>Vill du ersätta det?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="192"/>
        <source>Apply to all</source>
        <translation>Verkställ för alla</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="237"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="237"/>
        <source>Failed to import following User Script file(s):
%1</source>
        <translation><numerusform>Misslyckades med att importera det följande användarsskriptet:
%1</numerusform><numerusform>Misslyckades med att importera de följande användarskriptena:
%1</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="366"/>
        <source>You are about to irreversibly remove %n addon(s).</source>
        <translation><numerusform>Du är på väg att ta bort %n tillägg för alltid.</numerusform><numerusform>Du är på väg att ta bort %n tillägg för alltid.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="367"/>
        <source>Do you want to continue?</source>
        <translation>Vill du fortsätta?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="433"/>
        <source>Add Addon…</source>
        <translation>Lägg till tillägg…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="439"/>
        <source>Open Addon File</source>
        <translation>Öppna tilläggsfil</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="440"/>
        <source>Reload Addon</source>
        <translation>Hämta om tillägg</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="444"/>
        <source>Remove Addon…</source>
        <translation>Ta bort tillägg…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="485"/>
        <source>Addons</source>
        <translation>Tillägg</translation>
    </message>
</context>
<context>
    <name>Otter::AddressCompletionModel</name>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="93"/>
        <source>Search with %1</source>
        <translation>Sök med %1</translation>
    </message>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="111"/>
        <source>Bookmarks</source>
        <translation>Bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="145"/>
        <source>Local files</source>
        <translation>Lokala filer</translation>
    </message>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="161"/>
        <source>History</source>
        <translation>Historik</translation>
    </message>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="176"/>
        <source>Typed history</source>
        <translation>Inmatad historik</translation>
    </message>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="198"/>
        <source>Special pages</source>
        <translation>Speciella sidor</translation>
    </message>
</context>
<context>
    <name>Otter::AddressWidget</name>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="341"/>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="372"/>
        <source>Enter address or search…</source>
        <translation>Fyll i adress eller sök…</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="540"/>
        <source>Remove this Icon</source>
        <translation>Ta bort denna ikonen</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="631"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="662"/>
        <source>Add to Bookmarks</source>
        <translation>Lägg till hos bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="674"/>
        <source>Add to Start Page</source>
        <translation>Lägg till hos startsida</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1045"/>
        <source>Show website information</source>
        <translation>Visa information om webbplatsen</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1059"/>
        <source>Show feed list</source>
        <translation>Visa flödeslista</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1071"/>
        <source>Remove bookmark</source>
        <translation>Ta bort bokmärket</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1076"/>
        <source>Add bookmark</source>
        <translation>Lägg till bokmärke</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1085"/>
        <source>Load all plugins on the page</source>
        <translation>Hämta alla insticksprogram på webbplatsen</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1093"/>
        <source>Log in</source>
        <translation>Logga in</translation>
    </message>
</context>
<context>
    <name>Otter::Application</name>
    <message>
        <location filename="../../src/core/Application.cpp" line="322"/>
        <location filename="../../src/core/Application.cpp" line="353"/>
        <location filename="../../src/core/Application.cpp" line="442"/>
        <location filename="../../src/core/Application.cpp" line="1017"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="322"/>
        <source>Profile directory (%1) is not writable, application will be running in read-only mode.</source>
        <translation>Profilkatalogen (%1) är inte skrivbar, applikationen körs i enbart läsande läge.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="345"/>
        <source>Your profile directory (%1) ran out of free disk space.
This may lead to malfunctions or even data loss.</source>
        <translation>Din profilkatalog (%1) har bilivit fullare än lediga diskutrymmet.
Det kan leda till felfunktioner eller även dataförlust.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="349"/>
        <source>Your profile directory (%1) is running low on free disk space (%2 remaining).
This may lead to malfunctions or even data loss.</source>
        <translation>Din profilkatalog (%1) har lite ledigt diskutrymme kvar (%2 återstår).
Det kan leda till felfunktioner eller även dataförlust.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="355"/>
        <location filename="../../src/core/Application.cpp" line="1643"/>
        <location filename="../../src/core/Application.cpp" line="1692"/>
        <source>Do you want to continue?</source>
        <translation>Vill du fortsätta?</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="357"/>
        <location filename="../../src/core/Application.cpp" line="1647"/>
        <location filename="../../src/core/Application.cpp" line="1696"/>
        <source>Do not show this message again</source>
        <translation>Visa inte detta meddelande igen</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="358"/>
        <source>Continue in Read-only Mode</source>
        <translation>Fortsätt i enbart läsande läge</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="360"/>
        <source>Ignore</source>
        <translation>Ignorera</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="361"/>
        <source>Quit</source>
        <translation>Avsluta</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="442"/>
        <source>SSL support is not available or incomplete.
Some websites may work incorrectly or do not work at all.</source>
        <translation>Understödet för SSL är inte tillgängligt eller ofullständigt.
Några hemsidor kan arbeta felaktigt eller inte alls.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="741"/>
        <source>&lt;b&gt;Otter %1&lt;/b&gt;&lt;br&gt;Web browser controlled by the user, not vice-versa.&lt;br&gt;&lt;a href=&quot;https://www.otter-browser.org/&quot;&gt;https://www.otter-browser.org/&lt;/a&gt;</source>
        <translation>&lt;b&gt;Otter %1&lt;/b&gt;&lt;br&gt;Webbläsare styrd av användaren, inte tvärtom.&lt;br&gt;&lt;a href=&quot;https://www.otter-browser.org/&quot;&gt;https://www.otter-browser.org/&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="747"/>
        <source>Web backend: %1 %2.</source>
        <translation>Webbakände: %1 %2.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="751"/>
        <source>SSL library not available.</source>
        <translation>SSL-biblioteket är inte tillgängligt.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="755"/>
        <source>SSL library version: %1.</source>
        <translation>Version av SSL-biblioteket: %1.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1017"/>
        <source>This session was not saved correctly.
Are you sure that you want to restore this session anyway?</source>
        <translation>Den här sessionen sparades inte korrekt.
Är du säker på att du ändå vill återställa den här sessionen?</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1171"/>
        <source>New update %1 from %2 channel is available!</source>
        <translation>Ny uppdatering %1 från %2-kanalen är tillgänglig!</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1641"/>
        <location filename="../../src/core/Application.cpp" line="1690"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/core/Application.cpp" line="1642"/>
        <source>You are about to quit while %n files are still being downloaded.</source>
        <translation><numerusform>Du är på väg att avsluta medans %n filer fortfarande håller på att laddas ned.</numerusform><numerusform>Du är på väg att avsluta medans %n filer fortfarande håller på att laddas ned.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1649"/>
        <location filename="../../src/core/Application.cpp" line="1698"/>
        <source>Hide</source>
        <translation>Göm</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1691"/>
        <source>You are about to quit the current Otter Browser session.</source>
        <translation>Du är på väg att avsluta den aktuella Otter Browser-sessionen.</translation>
    </message>
</context>
<context>
    <name>Otter::ApplicationComboBoxWidget</name>
    <message>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="34"/>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="47"/>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="122"/>
        <source>Default Application</source>
        <translation>Förvald applikation</translation>
    </message>
    <message>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="36"/>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="48"/>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="144"/>
        <source>Other…</source>
        <translation>Andra…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="60"/>
        <source>Select Application</source>
        <translation>Välj applikation</translation>
    </message>
    <message>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="130"/>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
</context>
<context>
    <name>Otter::AtomFeedParser</name>
    <message>
        <location filename="../../src/core/FeedParser.cpp" line="215"/>
        <source>Failed to parse feed file: %1</source>
        <translation>Misslyckades med att tolka flödesfilen: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedParser.cpp" line="226"/>
        <source>Failed to parse feed: no valid entries found</source>
        <translation>Misslyckades med att tolka flödet: Inga giltiga element hittades</translation>
    </message>
</context>
<context>
    <name>Otter::AuthenticationDialog</name>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="14"/>
        <source>Authentication Required</source>
        <translation>Autentisering krävs</translation>
    </message>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="22"/>
        <source>Server:</source>
        <translation>Server:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="42"/>
        <source>Message:</source>
        <translation>Meddelande:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="62"/>
        <source>User:</source>
        <translation>Användare:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="72"/>
        <source>Password:</source>
        <translation>Lösenord:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="101"/>
        <source>Remember password</source>
        <translation>Kom ihåg lösenord</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarkPropertiesDialog</name>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="19"/>
        <source>Title:</source>
        <translation>Titel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="29"/>
        <source>Description:</source>
        <translation>Beskrivning:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="39"/>
        <source>Address:</source>
        <translation>Adress:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="49"/>
        <source>Folder:</source>
        <translation>Mapp:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="71"/>
        <source>New…</source>
        <translation>Ny…</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="96"/>
        <source>Visits:</source>
        <translation>Besök:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="103"/>
        <source>Last visit:</source>
        <translation>Besöktest senast:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="110"/>
        <source>Created:</source>
        <translation>Skapad:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="138"/>
        <source>Modified:</source>
        <translation>Modifierad:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="152"/>
        <source>Keyword:</source>
        <translation>Nyckelord:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="50"/>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="51"/>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="62"/>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="75"/>
        <source>View Bookmark</source>
        <translation>Visa Bokmärke</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="87"/>
        <source>Edit Bookmark</source>
        <translation>Redigera Bokmärke</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="116"/>
        <source>Add Bookmark</source>
        <translation>Lägg till Bokmärke</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="159"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="159"/>
        <source>Bookmark with this keyword already exists.</source>
        <translation>Det finns redan ett bokmärke med det här nyckelordet.</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarkWidget</name>
    <message>
        <location filename="../../src/modules/widgets/bookmark/BookmarkWidget.cpp" line="97"/>
        <source>Title: %1</source>
        <translation>Titel: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/bookmark/BookmarkWidget.cpp" line="101"/>
        <source>Address: %1</source>
        <translation>Adress: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/bookmark/BookmarkWidget.cpp" line="106"/>
        <source>Description: %1</source>
        <translation>Beskrivning: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/bookmark/BookmarkWidget.cpp" line="111"/>
        <source>Created: %1</source>
        <translation>Skapades: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/bookmark/BookmarkWidget.cpp" line="116"/>
        <source>Visited: %1</source>
        <translation>Besöktes: %1</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarksComboBoxWidget</name>
    <message>
        <location filename="../../src/ui/BookmarksComboBoxWidget.cpp" line="43"/>
        <source>Folder Name</source>
        <translation>Mappens namn</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksComboBoxWidget.cpp" line="43"/>
        <source>Select name of new folder:</source>
        <translation>Välj namnet på den nya mappen:</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarksContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="85"/>
        <source>Address:</source>
        <translation>Adress:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="92"/>
        <source>Title:</source>
        <translation>Titel:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="99"/>
        <source>Description:</source>
        <translation>Beskrivning:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="115"/>
        <source>Keyword:</source>
        <translation>Nyckelord:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="130"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="140"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="246"/>
        <source>Properties…</source>
        <translation>Egenskaper…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="150"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="50"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="168"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="221"/>
        <source>Add Folder…</source>
        <translation>Lägg till mapp…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="51"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="169"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="222"/>
        <source>Add Bookmark…</source>
        <translation>Lägg till bokmärke…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="52"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="170"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="223"/>
        <source>Add Separator</source>
        <translation>Lägg till separerare</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Address</source>
        <translation>Adress</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Description</source>
        <translation>Beskrivning</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Keyword</source>
        <translation>Nyckelord</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Added</source>
        <translation>Lade till</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Modified</source>
        <translation>Modifierad</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Visited</source>
        <translation>Besökt</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Visits</source>
        <translation>Besök</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="160"/>
        <source>Empty Trash</source>
        <translation>Töm papperskorgen</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="219"/>
        <source>Add Bookmark</source>
        <translation>Lägg till bokmärke</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="232"/>
        <source>Restore Bookmark</source>
        <translation>Återställ bokmärke</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="337"/>
        <source>Bookmarks</source>
        <translation>Bokmärken</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarksImporterWidget</name>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="17"/>
        <source>Remove existing bookmarks</source>
        <translation>Ta bort existerande bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="51"/>
        <source>Import into folder:</source>
        <translation>Importera till mappen:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="70"/>
        <source>New…</source>
        <translation>Ny…</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="81"/>
        <source>Allow to duplicate already existing bookmarks</source>
        <translation>Tillåt att fördubbla redan existerande bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="107"/>
        <source>Import into subfolder</source>
        <translation>Importera till underkatalog</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="120"/>
        <source>Leave empty to import into main folder</source>
        <translation>Lämna tom för att importera till huvudmappen</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="127"/>
        <source>Subfolder name:</source>
        <translation>Namn på underkatalog:</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarksModel</name>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="155"/>
        <source>Notes</source>
        <translation>Anteckningar</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="159"/>
        <source>Bookmarks</source>
        <translation>Bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="161"/>
        <source>Trash</source>
        <translation>Papperskorg</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="185"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="362"/>
        <source>Failed to open notes file: %1</source>
        <translation>Misslyckades med att öppna anteckningsfilen: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="362"/>
        <source>Failed to open bookmarks file: %1</source>
        <translation>Misslyckades med att öppna bokmärkesfilen: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="386"/>
        <source>Failed to load notes file: %1</source>
        <translation>Misslyckades med att ladda anteckningsfilen: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="386"/>
        <source>Failed to load bookmarks file: %1</source>
        <translation>Misslyckades med att ladda bokmärkesfilen: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="388"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="388"/>
        <source>Failed to load notes file.</source>
        <translation>Misslyckades med att ladda anteckningsfilen.</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="388"/>
        <source>Failed to load bookmarks file.</source>
        <translation>Misslyckades med att ladda bokmärkesfilen.</translation>
    </message>
</context>
<context>
    <name>Otter::CacheContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="97"/>
        <source>Address:</source>
        <translation>Adress:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="107"/>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="117"/>
        <source>Size:</source>
        <translation>Storlek:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="127"/>
        <source>Last Modified:</source>
        <translation>Modifierades senast:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="137"/>
        <source>Expires:</source>
        <translation>Utgår:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="147"/>
        <source>Location:</source>
        <translation>Plats:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="168"/>
        <source>Preview</source>
        <translation>Förhandsgranska</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="207"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="115"/>
        <source>Address</source>
        <translation>Adress</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="115"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="115"/>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="115"/>
        <source>Last Modified</source>
        <translation>Modifierades senast</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="115"/>
        <source>Expires</source>
        <translation>Upphör att gälla</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="368"/>
        <source>Copy Link to Clipboard</source>
        <translation>Kopiera länken till klippbordet</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="372"/>
        <source>Remove Entry</source>
        <translation>Ta bort inlägg</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="381"/>
        <source>Remove All Entries from This Domain</source>
        <translation>Ta bort alla inlägg från den här domänen</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="449"/>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="535"/>
        <source>Cache</source>
        <translation>Cache</translation>
    </message>
</context>
<context>
    <name>Otter::CertificateDialog</name>
    <message>
        <location filename="../../src/ui/CertificateDialog.ui" line="17"/>
        <source>Certificate chain:</source>
        <translation>Certifikatkedja:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.ui" line="34"/>
        <source>Certificate fields:</source>
        <translation>Certifikatfält:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.ui" line="51"/>
        <source>Field value:</source>
        <translation>Fält-värde:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="44"/>
        <source>Export…</source>
        <translation>Exportera…</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="48"/>
        <source>Invalid Certificate</source>
        <translation>Ogiltigt certifikat</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="53"/>
        <source>View Certificate for %1</source>
        <translation>Visa certifikatet för %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="62"/>
        <location filename="../../src/ui/CertificateDialog.cpp" line="456"/>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="116"/>
        <source>Select File</source>
        <translation>Välj fil</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="116"/>
        <source>DER encoded X.509 certificates (*.der)</source>
        <translation>DER-kodade X.509 certifikat (*.der)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="116"/>
        <source>PEM encoded X.509 certificates (*.pem)</source>
        <translation>PEM-kodade X.509 certifikat (*.pem)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="116"/>
        <source>Text files (*.txt)</source>
        <translation>Textfiler (*.txt)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="124"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="124"/>
        <source>Failed to open file for writing.</source>
        <translation>Misslyckades med att öppna fil för skrivning.</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="183"/>
        <source>Authority Key Identifier</source>
        <translation>Identifierare av auktoritetsnyckel</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="187"/>
        <source>Subject Key Identifier</source>
        <translation>Identifierare av subjektsnyckel</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="191"/>
        <source>Key Usage</source>
        <translation>Användning av nyckel</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="195"/>
        <source>Certificate Policies</source>
        <translation>Riktlinjer för certfikat</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="199"/>
        <source>Policy Mappings</source>
        <translation>Avbildning av riktlinjer</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="203"/>
        <source>Subject Alternative Name</source>
        <translation>Alternativt namn för subjekt</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="207"/>
        <source>Issuer Alternative Name</source>
        <translation>Alternativt namn för utfärdare</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="211"/>
        <source>Subject Directory Attributes</source>
        <translation>Attributer av subjektskatalog</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="215"/>
        <source>Basic Constraints</source>
        <translation>Grundläggande inskränkningar</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="219"/>
        <source>Name Constraints</source>
        <translation>Namnsinskränkningar</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="223"/>
        <source>Policy Constraints</source>
        <translation>Riktlinjeinskränkningar</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="227"/>
        <source>Extended Key Usage</source>
        <translation>Utökad användning för nyckel</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="231"/>
        <source>CRL Distribution Points</source>
        <translation>CRL-distributionsställen</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="235"/>
        <source>Inhibit Any Policy</source>
        <translation>Förhindra alla riktlinjer</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="239"/>
        <source>Delta CRL Distribution Point</source>
        <translation>Delta-CRL-distributionsställe</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="243"/>
        <source>Authority Information Access</source>
        <translation>Åtkomst till auktoritetsinformation</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="247"/>
        <source>Subject Information Access</source>
        <translation>Åtkomst till subjektsinformation</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="336"/>
        <source>Modulus:
%1

Exponent: %2</source>
        <translation>Modulo:
%1

Exponent: %2</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="349"/>
        <source>Critical</source>
        <translation>Kritisk</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="349"/>
        <source>Not Critical</source>
        <translation>Inte kritisk</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="350"/>
        <source>OID: %1</source>
        <translation>OID: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="354"/>
        <source>Value:</source>
        <translation>Värde:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="408"/>
        <source>Version</source>
        <translation>Versio</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="412"/>
        <source>Serial Number</source>
        <translation>Seriellnummer</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="416"/>
        <source>Certificate Signature Algorithm</source>
        <translation>Certifikatets signaturalgoritm</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="420"/>
        <source>Issuer</source>
        <translation>Utfärdare</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="424"/>
        <source>Validity</source>
        <translation>Giltighet</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="428"/>
        <source>Not Before</source>
        <translation>Inte före</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="432"/>
        <source>Not After</source>
        <translation>Inte efter</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="436"/>
        <source>Subject</source>
        <translation>Subjekt</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="440"/>
        <source>Subject Public Key</source>
        <translation>Subjektets publika nyckel</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="444"/>
        <source>Algorithm</source>
        <translation>Algoritm</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="448"/>
        <source>Public Key</source>
        <translation>Publik nyckel</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="452"/>
        <source>Extensions</source>
        <translation>Filnamnstillägg</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="460"/>
        <source>Fingerprint</source>
        <translation>Fingeravtryck</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="464"/>
        <source>SHA-1 Fingerprint</source>
        <translation>SHA-1-fingeravtryck</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="468"/>
        <source>SHA-256 Fingerprint</source>
        <translation>SHA-256-fingeravtryck</translation>
    </message>
</context>
<context>
    <name>Otter::ClearHistoryDialog</name>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="14"/>
        <source>Clear History</source>
        <translation>Töm historiken</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="35"/>
        <source>Period to clear:</source>
        <translation>Period att tömmas:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="42"/>
        <source>All</source>
        <translation>Allt</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="45"/>
        <source> h</source>
        <translation>h</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="61"/>
        <source>Clear browsing history</source>
        <translation>Töm surfningsshistorik</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="68"/>
        <source>Clear cookies</source>
        <translation>Ta bort kakor</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="78"/>
        <source>Clear forms history</source>
        <translation>Töm formulärhistorik</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="85"/>
        <source>Clear downloads history</source>
        <translation>Töm nedladdningshistoriken</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="95"/>
        <source>Clear search history</source>
        <translation>Töm sökhistoriken</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="102"/>
        <source>Clear caches</source>
        <translation>Töm cache</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="112"/>
        <source>Clear websites storage data</source>
        <translation>Ta bort hemsidornas lagringsdata</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="119"/>
        <source>Clear passwords</source>
        <translation>Ta bort lösenord</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.cpp" line="54"/>
        <location filename="../../src/ui/ClearHistoryDialog.cpp" line="85"/>
        <source>Clear Now</source>
        <translation>Töm nu</translation>
    </message>
</context>
<context>
    <name>Otter::ColorWidget</name>
    <message>
        <location filename="../../src/ui/ColorWidget.cpp" line="56"/>
        <location filename="../../src/ui/ColorWidget.cpp" line="177"/>
        <source>Invalid</source>
        <translation>Ogiltig</translation>
    </message>
    <message>
        <location filename="../../src/ui/ColorWidget.cpp" line="105"/>
        <source>Select Color…</source>
        <translation>Välj färg…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ColorWidget.cpp" line="106"/>
        <source>Copy Color</source>
        <translation>Kopiera färg</translation>
    </message>
    <message>
        <location filename="../../src/ui/ColorWidget.cpp" line="113"/>
        <source>Clear</source>
        <translation>Töm</translation>
    </message>
</context>
<context>
    <name>Otter::ConfigurationContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="69"/>
        <source>Option Name:</source>
        <translation>Alternativsnamn:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="76"/>
        <source>Current Value:</source>
        <translation>Aktuella värdet:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="83"/>
        <source>Default Value:</source>
        <translation>Förvalt värde:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="106"/>
        <source>Save All</source>
        <translation>Spara alla</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="116"/>
        <source>Restore Defaults</source>
        <translation>Återställ förval</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="212"/>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="262"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="212"/>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="262"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="212"/>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="262"/>
        <source>Value</source>
        <translation>Värde</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="290"/>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="363"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="290"/>
        <source>The settings have been changed.
Do you want to save them?</source>
        <translation>Inställningarna har ändrats.
Vill du spara dem?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="363"/>
        <source>Do you really want to restore default values of all options?</source>
        <translation>Vill du verkligen återstalla de förvalda värdena för alla alternativ?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="500"/>
        <source>Copy Option Name</source>
        <translation>Kopiera optionsnamn</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="501"/>
        <source>Copy Option Value</source>
        <translation>Kopiera optionsvärde</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="505"/>
        <source>Save Value</source>
        <translation>Spara värde</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="508"/>
        <source>Restore Default Value</source>
        <translation>Återställ till förvalda värden</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="517"/>
        <source>Expand All</source>
        <translation>Öppna alla</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="518"/>
        <source>Collapse All</source>
        <translation>Fäll ihop alla</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="544"/>
        <source>Advanced Configuration</source>
        <translation>Avancerad konfiguration</translation>
    </message>
</context>
<context>
    <name>Otter::ConfigurationOptionWidget</name>
    <message>
        <location filename="../../src/modules/widgets/configurationOption/ConfigurationOptionWidget.cpp" line="46"/>
        <source>Choose option</source>
        <translation>Välj alternativ</translation>
    </message>
</context>
<context>
    <name>Otter::ContentBlockingDialog</name>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="14"/>
        <source>Content Blocking</source>
        <translation>Blockering av innehåll</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="24"/>
        <source>General</source>
        <translation>Allmänt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="36"/>
        <source>Profiles</source>
        <translation>Profiler</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="43"/>
        <source>Select lists which you want to use for content blocking (AdBlock Plus compatible):</source>
        <translation>Välj listor som du vill använda för innehållblockering (AdBlock Plus-kompatibla):</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="76"/>
        <source>Settings</source>
        <translation>Inställningar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="85"/>
        <source>Cosmetic filters:</source>
        <translation>Kosmetiska filter:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="95"/>
        <source>Enable wildcard expressions</source>
        <translation>Aktivera Jokeruttryck</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="102"/>
        <source>Enable custom rules</source>
        <translation>Aktivera anpassade regler</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="115"/>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="190"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="125"/>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="197"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="135"/>
        <source>Update</source>
        <translation>Uppdatera</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="145"/>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="204"/>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="170"/>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="510"/>
        <source>Custom Rules</source>
        <translation>Anpassade regler</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="183"/>
        <source>All</source>
        <translation>Alla</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="184"/>
        <source>Domain specific only</source>
        <translation>Enbart domänbundna</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="185"/>
        <source>None</source>
        <translation>Inga</translation>
    </message>
</context>
<context>
    <name>Otter::ContentBlockingInformationWidget</name>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="45"/>
        <source>Active Profiles</source>
        <translation>Aktiva profiler</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="46"/>
        <source>Blocked Elements</source>
        <translation>Blockerade element</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="150"/>
        <source>main frame</source>
        <translation>huvudram</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="154"/>
        <source>subframe</source>
        <translation>underram</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="158"/>
        <source>pop-up</source>
        <translation>extrafönster</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="162"/>
        <source>stylesheet</source>
        <translation>stilmall</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="166"/>
        <source>script</source>
        <translation>skript</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="170"/>
        <source>image</source>
        <translation>bild</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="174"/>
        <source>object</source>
        <translation>objekt</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="178"/>
        <source>object subrequest</source>
        <translation>objekt-underbegäran</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="182"/>
        <source>XHR</source>
        <translation>XHR</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="186"/>
        <source>WebSocket</source>
        <translation>WebSocket</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="190"/>
        <source>other</source>
        <translation>andra</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="209"/>
        <source>Enable Content Blocking</source>
        <translation>Aktivera innehållsblockering</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="339"/>
        <source>Blocked Elements: {amount}</source>
        <translation>Blockerade element: {antal}</translation>
    </message>
</context>
<context>
    <name>Otter::ContentBlockingIntervalDelegate</name>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="145"/>
        <source> day(s)</source>
        <translation>dag(ar)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="146"/>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="166"/>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="166"/>
        <source>%n day(s)</source>
        <translation><numerusform>%n dag(ar)</numerusform><numerusform>%n dag(ar)</numerusform></translation>
    </message>
</context>
<context>
    <name>Otter::ContentBlockingProfileDialog</name>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="14"/>
        <source>Profile Settings</source>
        <translation>Profilinställningar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="22"/>
        <source>Title:</source>
        <translation>Titel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="35"/>
        <source>Category:</source>
        <translation>Kategori:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="55"/>
        <source>Address:</source>
        <translation>Adress:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="68"/>
        <source>Update interval:</source>
        <translation>Mellanrum för uppdateringar:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="78"/>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="81"/>
        <source> days</source>
        <translation> dagar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="91"/>
        <source>Last update:</source>
        <translation>Senaste uppdateringen:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="40"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="77"/>
        <source>Advertisements</source>
        <translation>Reklam</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="41"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="78"/>
        <source>Annoyance</source>
        <translation>Inkräktande</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="42"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="79"/>
        <source>Privacy</source>
        <translation>Integritet</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="43"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="80"/>
        <source>Social</source>
        <translation>Socialt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="44"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="81"/>
        <source>Regional</source>
        <translation>Regionalt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="45"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="82"/>
        <source>Other</source>
        <translation>Andra</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="93"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="114"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="121"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="93"/>
        <source>Valid update URL is required.</source>
        <translation>En giltig webbadress för uppdateringar erfodras.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="114"/>
        <source>Profile with name %1.txt already exists.</source>
        <translation>Profilen med namnet %1.txt finns redan.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="121"/>
        <source>Failed to create profile file: %1.</source>
        <translation>Misslyckades med att skapa profilfilen: %1.</translation>
    </message>
</context>
<context>
    <name>Otter::ContentBlockingTitleDelegate</name>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="90"/>
        <source>Failed to read profile file</source>
        <translation>Misslyckades med att läsa profilfilen</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="94"/>
        <source>Failed to download profile rules</source>
        <translation>Misslyckades met att hämta profilregler</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="98"/>
        <source>Failed to verify profile rules using checksum</source>
        <translation>Misslyckades med att bekräfta profilreglerna över kontrollsumman</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="107"/>
        <source>Profile was never updated</source>
        <translation>Profilen uppdaterades aldrig</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="111"/>
        <source>Profile was last updated more than one week ago</source>
        <translation>Profilen blev sist uppdaterad för mer än en väcka sedan</translation>
    </message>
</context>
<context>
    <name>Otter::ContentFiltersManager</name>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="197"/>
        <source>Custom Rules</source>
        <translation>Anpassade regler</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="318"/>
        <source>Failed to remove content blocking profile file: %1</source>
        <translation>Misslyckades med at ta bort profilfilen för innehållsblockering: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="318"/>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="353"/>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="353"/>
        <source>Update Interval</source>
        <translation>Mellanrum för uppdateringar:</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="353"/>
        <source>Last Update</source>
        <translation>Senaste uppdateringen</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Advertisements</source>
        <translation>Reklam</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Annoyance</source>
        <translation>Inkräktande</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Privacy</source>
        <translation>Integritet</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Social</source>
        <translation>Socialt</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Regional</source>
        <translation>Regionalt</translation>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Other</source>
        <translation>Andra</translation>
    </message>
</context>
<context>
    <name>Otter::ContentsDialog</name>
    <message>
        <location filename="../../src/ui/ContentsDialog.cpp" line="75"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
</context>
<context>
    <name>Otter::ContentsWidget</name>
    <message>
        <location filename="../../src/ui/ContentsWidget.cpp" line="149"/>
        <source>Print Page</source>
        <translation>Skriv ut sida</translation>
    </message>
    <message>
        <location filename="../../src/ui/ContentsWidget.cpp" line="166"/>
        <source>Print Preview</source>
        <translation>Förhandsgranskning för utskrift</translation>
    </message>
</context>
<context>
    <name>Otter::CookiePropertiesDialog</name>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="22"/>
        <source>Name:</source>
        <translation>Namn:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="38"/>
        <source>Value:</source>
        <translation>Värde:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="51"/>
        <source>Expires:</source>
        <translation>Slutar gälla:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="64"/>
        <source>this session only</source>
        <translation>enbart denna sessionen</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="71"/>
        <source>MM.dd.yyyy HH:mm</source>
        <comment>Date and time format</comment>
        <translation>yyyy-MM-dd HH::mm</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="81"/>
        <source>Domain:</source>
        <translation>Domän:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="97"/>
        <source>Path:</source>
        <translation>Sökväg:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="112"/>
        <source>Send only for secure connections</source>
        <translation>Sänd endast för säkra anslutningar</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="119"/>
        <source>Allow accessing using JavaScript</source>
        <translation>Tillåt åtkomst med JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.cpp" line="35"/>
        <source>Add Cookie</source>
        <translation>Lägg till kaka</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.cpp" line="39"/>
        <source>Edit Cookie</source>
        <translation>Redigera kaka</translation>
    </message>
</context>
<context>
    <name>Otter::CookiesContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="99"/>
        <source>Name:</source>
        <translation>Namn:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="109"/>
        <source>Value:</source>
        <translation>Värde:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="116"/>
        <source>Expires:</source>
        <translation>Utgår:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="126"/>
        <source>Domain:</source>
        <translation>Domän:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="151"/>
        <source>Path:</source>
        <translation>Sökväg:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="165"/>
        <source>Add…</source>
        <translation>Lägg till…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="175"/>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="359"/>
        <source>Properties…</source>
        <translation>Egenskaper…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="185"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="201"/>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="222"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="202"/>
        <source>You are about to delete %n cookie(s).</source>
        <translation><numerusform>Du är på väg att ta bort %n kaka.</numerusform><numerusform>Du är på väg att ta bort %n kakor.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="203"/>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="224"/>
        <source>Do you want to continue?</source>
        <translation>Vill du fortsätta?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="223"/>
        <source>You are about to delete all cookies.</source>
        <translation>Du är på väg att ta bort alla kakor.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="335"/>
        <source>Add Cookie…</source>
        <translation>Lägg till kaka…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="346"/>
        <source>Remove All Cookies from This Domain…</source>
        <translation>Ta bort alla kakor från den här domänen…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="349"/>
        <source>Remove All Cookies…</source>
        <translation>Ta bort alla kakor…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="423"/>
        <source>this session only</source>
        <translation>enbart denna sessionen</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="447"/>
        <source>Cookies</source>
        <translation>Kakor</translation>
    </message>
</context>
<context>
    <name>Otter::CookiesExceptionsDialog</name>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="14"/>
        <source>Third-party Cookies Exceptions</source>
        <translation>Undantag för kakor från tredjepart</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="26"/>
        <source>Always ACCEPT third-party cookies from:</source>
        <translation>TA EMOT alltid tredjepartskakor från:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="44"/>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="106"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="51"/>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="113"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="58"/>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="120"/>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="88"/>
        <source>Always REJECT third-party cookies from:</source>
        <translation>NEKA alltid tredjepartskakor från:</translation>
    </message>
</context>
<context>
    <name>Otter::ErrorConsoleWidget</name>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="31"/>
        <source>Scope</source>
        <translation>Räckvidd</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="60"/>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="163"/>
        <source>Network</source>
        <translation>Nätverk</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="76"/>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="167"/>
        <source>Security</source>
        <translation>Säkerhet</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="92"/>
        <source>CSS</source>
        <translation>CSS</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="108"/>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="171"/>
        <source>JS</source>
        <translation>JS</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="124"/>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="175"/>
        <source>Other</source>
        <translation>Andra</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="156"/>
        <source>Clear</source>
        <translation>Töm</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="185"/>
        <source>Filter…</source>
        <translation>Filter…</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="195"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="60"/>
        <source>All Tabs</source>
        <translation>Alla flikar</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="65"/>
        <source>Current Tab Only</source>
        <translation>Endast aktuella fliken</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="71"/>
        <source>Other Sources</source>
        <translation>Andra källor</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="181"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;empty&gt;</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="272"/>
        <source>Copy</source>
        <translation>Kopiera</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="279"/>
        <source>Expand All</source>
        <translation>Öppna alla</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="280"/>
        <source>Collapse All</source>
        <translation>Fäll ihop alla</translation>
    </message>
</context>
<context>
    <name>Otter::Feed</name>
    <message>
        <location filename="../../src/core/FeedsManager.cpp" line="289"/>
        <source>Feed updated:
%1</source>
        <translation>Flödet uppdaterades:
%1</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsManager.cpp" line="322"/>
        <source>Failed to parse feed: invalid feed type</source>
        <translation>Misslyckades med att tolka flöde: ogiltig flödestyp</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsManager.cpp" line="332"/>
        <source>Failed to download feed</source>
        <translation>Misslyckades med att hämta flöde</translation>
    </message>
</context>
<context>
    <name>Otter::FeedPropertiesDialog</name>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="14"/>
        <source>Edit Feed</source>
        <translation>Redigera flöde</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="22"/>
        <source>Folder:</source>
        <translation>Mapp:</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="44"/>
        <source>New…</source>
        <translation>Ny…</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="53"/>
        <source>Title:</source>
        <translation>Titel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="80"/>
        <source>Change Icon…</source>
        <translation>Ändra ikon…</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="89"/>
        <source>Address:</source>
        <translation>Adress:</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="102"/>
        <source>Update interval:</source>
        <translation>Mellanrum för uppdateringar:</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="112"/>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="115"/>
        <source> minutes</source>
        <translation> minuter</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.cpp" line="50"/>
        <source>Add Feed</source>
        <translation>Lägg till flöde</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.cpp" line="80"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.cpp" line="80"/>
        <source>Valid address is required.</source>
        <translation>En giltig adress erfodras.</translation>
    </message>
</context>
<context>
    <name>Otter::FeedsComboBoxWidget</name>
    <message>
        <location filename="../../src/ui/FeedsComboBoxWidget.cpp" line="41"/>
        <source>Folder Name</source>
        <translation>Mappens namn</translation>
    </message>
    <message>
        <location filename="../../src/ui/FeedsComboBoxWidget.cpp" line="41"/>
        <source>Select name of new folder:</source>
        <translation>Välj namnet på den nya mappen:</translation>
    </message>
</context>
<context>
    <name>Otter::FeedsContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.ui" line="67"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.ui" line="74"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.ui" line="107"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.ui" line="151"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.ui" line="161"/>
        <source>Categories</source>
        <translation>Kategorier</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="148"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="535"/>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="148"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="535"/>
        <source>From</source>
        <translation>Från</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="148"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="535"/>
        <source>Published</source>
        <translation>Publicerat</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="194"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="195"/>
        <source>You already subscribed this feed.</source>
        <translation>Du har redan prenumererat detta flödet.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="196"/>
        <source>Do you want to continue?</source>
        <translation>Vill du fortsätta?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="214"/>
        <source>Select Folder Name</source>
        <translation>Välj mappens namn</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="214"/>
        <source>Enter folder name:</source>
        <translation>Ange namn på mappen:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="359"/>
        <source>Open</source>
        <translation>Öppna</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="378"/>
        <source>Empty Trash</source>
        <translation>Töm papperskorgen</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="386"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="411"/>
        <source>Add Folder…</source>
        <translation>Lägg till mapp…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="387"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="412"/>
        <source>Add Feed…</source>
        <translation>Lägg till flöde…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="409"/>
        <source>Add New</source>
        <translation>Lägg till ny</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="421"/>
        <source>Restore Feed</source>
        <translation>Återställ flöde</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="435"/>
        <source>Properties…</source>
        <translation>Egenskaper…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="477"/>
        <source>Send email to %1</source>
        <translation>Sänd epost till %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="479"/>
        <source>Go to %1</source>
        <translation>Gå till %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="615"/>
        <source>All (%1)</source>
        <translation>Allt (%1)</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="665"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="802"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="733"/>
        <source>Subscribe to this feed using:</source>
        <translation>Prenumerera detta flödet med:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="802"/>
        <source>Feed: %1</source>
        <translation>Flöde: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="805"/>
        <source>Feeds</source>
        <translation>Flöden</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="912"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="921"/>
        <source>Title: %1</source>
        <translation>Titel: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="912"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="925"/>
        <source>Address: %1</source>
        <translation>Adress: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="916"/>
        <source>Last update: %1</source>
        <translation>Senaste uppdateringen: %1</translation>
    </message>
</context>
<context>
    <name>Otter::FeedsModel</name>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="57"/>
        <source>Feeds</source>
        <translation>Flöden</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="59"/>
        <source>Trash</source>
        <translation>Papperskorg</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="63"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="230"/>
        <source>Failed to open feeds file: %1</source>
        <translation>Misslyckades med att öppna flödesfilen: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="253"/>
        <source>Failed to load feeds file: %1</source>
        <translation>Misslyckades med att ladda flödesfilen: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="255"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="255"/>
        <source>Failed to load feeds file.</source>
        <translation>Misslyckades med att ladda flödesfilen.</translation>
    </message>
</context>
<context>
    <name>Otter::FilePasswordsStorageBackend</name>
    <message>
        <location filename="../../src/modules/backends/passwords/file/FilePasswordsStorageBackend.cpp" line="53"/>
        <source>Failed to open passwords file: %1</source>
        <translation>Misslyckades med att öppna lösenordsfilen: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/passwords/file/FilePasswordsStorageBackend.cpp" line="109"/>
        <source>Failed to save passwords file: %1</source>
        <translation>Misslyckades med att spara lösenordsfilen: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/passwords/file/FilePasswordsStorageBackend.cpp" line="196"/>
        <source>Failed to remove passwords file</source>
        <translation>Misslyckades med att ta bort lösenordsfilen</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/passwords/file/FilePasswordsStorageBackend.cpp" line="325"/>
        <source>Encrypted File</source>
        <translation>Krypterad fil</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/passwords/file/FilePasswordsStorageBackend.cpp" line="330"/>
        <source>Stores passwords in AES encrypted file.</source>
        <translation>Lagrar lösenord i AES-krypterad fil.</translation>
    </message>
</context>
<context>
    <name>Otter::FilePathWidget</name>
    <message>
        <location filename="../../src/ui/FilePathWidget.cpp" line="49"/>
        <location filename="../../src/ui/FilePathWidget.cpp" line="74"/>
        <source>Browse…</source>
        <translation>Bläddra…</translation>
    </message>
    <message>
        <location filename="../../src/ui/FilePathWidget.cpp" line="88"/>
        <source>Select File</source>
        <translation>Välj fil</translation>
    </message>
    <message>
        <location filename="../../src/ui/FilePathWidget.cpp" line="88"/>
        <source>Select Directory</source>
        <translation>Välj mapp</translation>
    </message>
</context>
<context>
    <name>Otter::FreeDesktopOrgPlatformIntegration</name>
    <message>
        <location filename="../../src/modules/platforms/freedesktoporg/FreeDesktopOrgPlatformIntegration.cpp" line="212"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/freedesktoporg/FreeDesktopOrgPlatformIntegration.cpp" line="216"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/freedesktoporg/FreeDesktopOrgPlatformIntegration.cpp" line="220"/>
        <source>Information</source>
        <translation>Inmformation</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/freedesktoporg/FreeDesktopOrgPlatformIntegration.cpp" line="230"/>
        <source>Notification</source>
        <translation>Avisering</translation>
    </message>
</context>
<context>
    <name>Otter::HandlersManager</name>
    <message>
        <location filename="../../src/core/HandlersManager.cpp" line="172"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/core/HandlersManager.cpp" line="172"/>
        <source>Profile with this address already exists.</source>
        <translation>Profilen med denna adressen finns redan.</translation>
    </message>
    <message>
        <location filename="../../src/core/HandlersManager.cpp" line="174"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/core/HandlersManager.cpp" line="174"/>
        <source>Do you want to add this content blocking profile?</source>
        <translation>Vill du lägga till denna profilen för innehållsblockering?</translation>
    </message>
</context>
<context>
    <name>Otter::HeaderViewWidget</name>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="65"/>
        <source>Sorting</source>
        <translation>Sortering</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="66"/>
        <source>Sort Ascending</source>
        <translation>Sortera uppstigande</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="71"/>
        <source>Sort Descending</source>
        <translation>Sortera nedstigande</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="78"/>
        <source>No Sorting</source>
        <translation>Ingen sortering</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="91"/>
        <source>Visible Columns</source>
        <translation>Synliga kolumner</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="99"/>
        <source>Show All</source>
        <translation>Visa alla</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="111"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
</context>
<context>
    <name>Otter::HistoryContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Today</source>
        <translation>Idag</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Yesterday</source>
        <translation>Igår</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Earlier This Week</source>
        <translation>Tidigare i den här veckan</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Previous Week</source>
        <translation>Föregående vecka</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Earlier This Month</source>
        <translation>Tidigare den här månaden</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Earlier This Year</source>
        <translation>Tidigare i det här året</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Older</source>
        <translation>Äldre</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="52"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="93"/>
        <source>Address</source>
        <translation>Adress</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="52"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="93"/>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="52"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="93"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="388"/>
        <source>Add to Bookmarks…</source>
        <translation>Lägg till i Bokmärken…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="389"/>
        <source>Copy Link to Clipboard</source>
        <translation>Kopiera länken till klippbordet</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="393"/>
        <source>Remove Entry</source>
        <translation>Ta bort inlägg</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="394"/>
        <source>Remove All Entries from This Domain</source>
        <translation>Ta bort alla inlägg från den här domänen</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="431"/>
        <source>History</source>
        <translation>Historik</translation>
    </message>
</context>
<context>
    <name>Otter::HistoryEntryItem</name>
    <message>
        <location filename="../../src/core/HistoryModel.cpp" line="58"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
</context>
<context>
    <name>Otter::HistoryModel</name>
    <message>
        <location filename="../../src/core/HistoryModel.cpp" line="90"/>
        <source>Failed to open history file: %1</source>
        <translation>Misslyckades med att öppna historikfilen: %1</translation>
    </message>
</context>
<context>
    <name>Otter::HtmlBookmarksImporter</name>
    <message>
        <location filename="../../src/modules/importers/html/HtmlBookmarksImporter.cpp" line="178"/>
        <source>HTML Bookmarks</source>
        <translation>HTML-bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/html/HtmlBookmarksImporter.cpp" line="183"/>
        <source>Imports bookmarks from HTML file (Netscape format).</source>
        <translation>Importera bokmärken från HTML-fil (Netscape-format).</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/html/HtmlBookmarksImporter.cpp" line="228"/>
        <source>HTML files (*.htm *.html)</source>
        <translation>HTML-filer (*.htm *.html)</translation>
    </message>
</context>
<context>
    <name>Otter::IconWidget</name>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="37"/>
        <location filename="../../src/ui/IconWidget.cpp" line="51"/>
        <location filename="../../src/ui/IconWidget.cpp" line="76"/>
        <location filename="../../src/ui/IconWidget.cpp" line="86"/>
        <source>Select Icon</source>
        <translation>Välj ikon</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="76"/>
        <source>Images (*.png *.jpg *.bmp *.gif *.svg *.svgz *.ico)</source>
        <translation>Bilder (*.png *.jpg *.bmp *.gif *.svg *.svgz *.ico)</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="86"/>
        <source>Icon Name:</source>
        <translation>Namn på ikonen:</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="98"/>
        <source>Select From File…</source>
        <translation>Välj från fil…</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="99"/>
        <source>Select From Theme…</source>
        <translation>Välj från tema…</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="105"/>
        <source>Reset</source>
        <translation>Återställ</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="113"/>
        <source>Clear</source>
        <translation>Töm</translation>
    </message>
</context>
<context>
    <name>Otter::ImagePropertiesDialog</name>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="14"/>
        <source>Image Properties</source>
        <translation>Bildegenskaper</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="22"/>
        <source>Size:</source>
        <translation>Storlek:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="29"/>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="36"/>
        <source>File size:</source>
        <translation>Filens storlek:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="43"/>
        <source>Address:</source>
        <translation>Adress:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="50"/>
        <source>Alternative text:</source>
        <translation>Alternativ text:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="57"/>
        <source>Long description:</source>
        <translation>Lång beskrivning:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="38"/>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="39"/>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="40"/>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="70"/>
        <source>%1 x %2 pixels @ %3 bits per pixel in %n frame(s)</source>
        <translation><numerusform>%1 x %2 bildpunkter vid %3 bitar per bildpunkt i %n ram</numerusform><numerusform>%1 x %2 bildpunkter vid %3 bitar per bildpunkt i %n ramar</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="74"/>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="81"/>
        <source>%1 x %2 pixels @ %3 bits per pixel</source>
        <translation>%1 x %2 bildpunkter vid %3 bitar per bildpunkt</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="85"/>
        <source>%1 x %2 pixels</source>
        <translation>%1 x %2 pixlar</translation>
    </message>
</context>
<context>
    <name>Otter::ImportDialog</name>
    <message>
        <location filename="../../src/ui/ImportDialog.ui" line="42"/>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.ui" line="54"/>
        <source>Source:</source>
        <translation>Källa:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.ui" line="98"/>
        <source>Results</source>
        <translation>Resultat</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.ui" line="123"/>
        <source>Initializing…</source>
        <translation>Inleder…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.ui" line="135"/>
        <source>%p% (%v/%m)</source>
        <translation>%p% (%v/%m)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="125"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="125"/>
        <source>Unable to import selected type.</source>
        <translation>Kunde inte importera den valda typen.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="158"/>
        <source>Processing…</source>
        <translation>Behandlas…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="186"/>
        <source>Failed to import data.</source>
        <translation>Misslyckades med att importera data.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="190"/>
        <source>Import cancelled by the user.</source>
        <translation>Importen avbryttes av användaren.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="194"/>
        <source>Import finished successfully.</source>
        <translation>Importen lyckades.</translation>
    </message>
</context>
<context>
    <name>Otter::JavaScriptPreferencesDialog</name>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="14"/>
        <source>JavaScript Options</source>
        <translation>Alternativ för JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="26"/>
        <source>Allow moving and resizing of windows</source>
        <translation>Tillåt flyttning och storleksförändring av fönster</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="39"/>
        <source>Allow changing of status field</source>
        <translation>Tillåt ändring av statusraden</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="49"/>
        <source>Allow script to hide address bar</source>
        <translation>Tillåt skriptet att gömma adressraden</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="56"/>
        <source>Allow access to clipboard</source>
        <translation>Tillåt åtkomst till klippbordet</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="63"/>
        <source>Allow to receive right mouse button clicks</source>
        <translation>Tillåt att ta emot högra musknappens klickar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="72"/>
        <source>Allow to close windows:</source>
        <translation>Tillåt att stänga fönster:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="88"/>
        <source>Allow to enter full screen mode:</source>
        <translation>Tillåt at byta till helskärmsläge:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="37"/>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="40"/>
        <source>Ask</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="38"/>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="41"/>
        <source>Always</source>
        <translation>Alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="39"/>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="42"/>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
</context>
<context>
    <name>Otter::KeyboardProfile</name>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="190"/>
        <location filename="../../src/core/ActionsManager.cpp" line="224"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
</context>
<context>
    <name>Otter::KeyboardProfileDialog</name>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="14"/>
        <source>Profile Configuration</source>
        <translation>Inställlning av profil</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="24"/>
        <source>Actions</source>
        <translation>Handlingar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="32"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="71"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="81"/>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="107"/>
        <source>Information</source>
        <translation>Inmformation</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="113"/>
        <source>Title:</source>
        <translation>Titel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="123"/>
        <source>Description:</source>
        <translation>Beskrivning:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="133"/>
        <source>Version:</source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="143"/>
        <source>Author:</source>
        <translation>Skapare:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="233"/>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="270"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="233"/>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="270"/>
        <source>Action</source>
        <translation>Handling</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="233"/>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="270"/>
        <source>Parameters</source>
        <translation>Parametrar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="233"/>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="270"/>
        <source>Shortcut</source>
        <translation>Genväg</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="390"/>
        <source>This shortcut already used by %1</source>
        <translation>Denna genvägen används redan av %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="390"/>
        <source>unknown action</source>
        <translation>okännd aktion</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="401"/>
        <source>This shortcut cannot be used because it would be overriden by a native hotkey used by an editing action</source>
        <translation>Denna genvägen kan inte användas för att den bleve överskridd av en inbyggd snabbtangent för en redigeringsaktion</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="409"/>
        <source>Single key shortcuts are currently disabled</source>
        <translation>Entangents-genvägar är för närvarande avaktiverade</translation>
    </message>
</context>
<context>
    <name>Otter::LinksContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="252"/>
        <source>Lock Panel</source>
        <translation>Lås panel</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="266"/>
        <source>Links</source>
        <translation>Länkar</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="318"/>
        <source>Title: %1</source>
        <translation>Titel: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="321"/>
        <source>Address: %1</source>
        <translation>Adress: %1</translation>
    </message>
</context>
<context>
    <name>Otter::LocalListingNetworkReply</name>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="61"/>
        <source>Directory does not exist</source>
        <translation>Katalogen finns inte</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="66"/>
        <source>Directory is not readable</source>
        <translation>Katalogen är inte läsbar</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="67"/>
        <source>Cannot read directory listing</source>
        <translation>Katalogupplistningen kan inte läsas</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="109"/>
        <source>Directory Contents</source>
        <translation>Mappens innehåll</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="112"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="113"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="114"/>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="115"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
</context>
<context>
    <name>Otter::LocaleDialog</name>
    <message>
        <location filename="../../src/ui/LocaleDialog.ui" line="14"/>
        <source>Switch Application Language</source>
        <translation>Byt språk på applikationen</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.ui" line="22"/>
        <source>Language:</source>
        <translation>Språk:</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.ui" line="32"/>
        <source>Custom path:</source>
        <translation>Anpassad sökväg:</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.ui" line="43"/>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.ui" line="48"/>
        <source>Custom</source>
        <translation>Anpassat</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.cpp" line="47"/>
        <source>Unknown [%1]</source>
        <translation>Okänt [%1]</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.cpp" line="72"/>
        <source>Translation files (*.qm)</source>
        <translation>Översättningsfiler (*.qm)</translation>
    </message>
</context>
<context>
    <name>Otter::MacPlatformIntegration</name>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="370"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="374"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="378"/>
        <source>Information</source>
        <translation>Inmformation</translation>
    </message>
</context>
<context>
    <name>Otter::MainWindow</name>
    <message>
        <location filename="../../src/ui/MainWindow.cpp" line="832"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/MainWindow.cpp" line="833"/>
        <source>You are about to open %n bookmark(s).</source>
        <translation><numerusform>Du är på väg att öppna %n bokmäre.</numerusform><numerusform>Du är på väg att öppna %n bokmären.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/ui/MainWindow.cpp" line="834"/>
        <source>Do you want to continue?</source>
        <translation>Vill du fortsätta?</translation>
    </message>
    <message>
        <location filename="../../src/ui/MainWindow.cpp" line="838"/>
        <source>Do not show this message again</source>
        <translation>Visa inte detta meddelande igen</translation>
    </message>
    <message>
        <location filename="../../src/ui/MainWindow.cpp" line="2177"/>
        <source>Empty</source>
        <translation>Tom</translation>
    </message>
</context>
<context>
    <name>Otter::MasterPasswordDialog</name>
    <message>
        <location filename="../../src/ui/MasterPasswordDialog.ui" line="14"/>
        <source>Set Master Password</source>
        <translation>Ställ in huvudlösenordet</translation>
    </message>
    <message>
        <location filename="../../src/ui/MasterPasswordDialog.ui" line="22"/>
        <source>Current password:</source>
        <translation>Aktuella lösenordet:</translation>
    </message>
    <message>
        <location filename="../../src/ui/MasterPasswordDialog.ui" line="32"/>
        <source>New password:</source>
        <translation>Nytt lösenord:</translation>
    </message>
    <message>
        <location filename="../../src/ui/MasterPasswordDialog.ui" line="42"/>
        <source>Confirm new password:</source>
        <translation>Bekräfta nytt lösenord:</translation>
    </message>
</context>
<context>
    <name>Otter::Menu</name>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="491"/>
        <location filename="../../src/ui/Menu.cpp" line="580"/>
        <source>Failed to create menu action: %1</source>
        <translation>Misslyckades med skapandet av meny-aktion: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="917"/>
        <source>Window - %1</source>
        <translation>Fönster - %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1173"/>
        <location filename="../../src/ui/Menu.cpp" line="1188"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/Menu.cpp" line="1188"/>
        <source>%1 (%n tab(s))</source>
        <translation><numerusform>%1 (%n flik(ar))</numerusform><numerusform>%1 (%n flik(ar))</numerusform></translation>
    </message>
</context>
<context>
    <name>Otter::MenuButtonWidget</name>
    <message>
        <location filename="../../src/modules/widgets/menuButton/MenuButtonWidget.cpp" line="35"/>
        <source>Menu</source>
        <translation>Meny</translation>
    </message>
</context>
<context>
    <name>Otter::Migrator</name>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="586"/>
        <source>Settings Migration</source>
        <translation>Flytte av inställningar</translation>
    </message>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="589"/>
        <source>Configuration of the components listed below needs to be updated to new version.
Do you want to migrate it?</source>
        <translation>Konfigurationen av nedanstående komponenterna bör uppdateras till en ny version.
Vill du flytta den?</translation>
    </message>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="612"/>
        <source>Create backup</source>
        <translation>Skapa säkerhetskopia</translation>
    </message>
</context>
<context>
    <name>Otter::MouseProfile</name>
    <message>
        <location filename="../../src/core/GesturesManager.cpp" line="493"/>
        <location filename="../../src/core/GesturesManager.cpp" line="532"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
</context>
<context>
    <name>Otter::MouseProfileDialog</name>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="14"/>
        <source>Profile Configuration</source>
        <translation>Inställlning av profil</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="24"/>
        <source>Actions</source>
        <translation>Handlingar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="30"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="78"/>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="144"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="88"/>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="154"/>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="169"/>
        <source>Move Up</source>
        <translation>Flytta Upp</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="186"/>
        <source>Move Down</source>
        <translation>Flytta Ned</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="200"/>
        <source>Information</source>
        <translation>Inmformation</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="206"/>
        <source>Title:</source>
        <translation>Titel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="216"/>
        <source>Description:</source>
        <translation>Beskrivning:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="226"/>
        <source>Version:</source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="236"/>
        <source>Author:</source>
        <translation>Skapare:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Generic</source>
        <translation>Vanlig</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Link</source>
        <translation>Länk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Editable Content</source>
        <translation>Redigerbart innehåll</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Tab Handle</source>
        <translation>Flikhantering</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Tab Handle of Active Tab</source>
        <translation>Flikhantering av aktiv flik</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Empty Area of Tab Bar</source>
        <translation>Tom yta av flikraden</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Any Toolbar</source>
        <translation>Någon verktygsrad</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="139"/>
        <source>Context and Action</source>
        <translation>Sammanhang och aktion</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="139"/>
        <source>Parameters</source>
        <translation>Parametrar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="139"/>
        <source>Steps</source>
        <translation>Steg</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="143"/>
        <source>Step</source>
        <translation>Steg</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="201"/>
        <source>Select Action</source>
        <translation>Välj handling</translation>
    </message>
</context>
<context>
    <name>Otter::NavigationActionWidget</name>
    <message>
        <location filename="../../src/modules/widgets/action/ActionWidget.cpp" line="340"/>
        <source>Remove Entry</source>
        <translation>Ta bort element</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/action/ActionWidget.cpp" line="343"/>
        <source>Purge Entry</source>
        <translation>Rensa element</translation>
    </message>
</context>
<context>
    <name>Otter::NetworkAutomaticProxy</name>
    <message>
        <location filename="../../src/core/NetworkAutomaticProxy.cpp" line="322"/>
        <location filename="../../src/core/NetworkAutomaticProxy.cpp" line="342"/>
        <source>Failed to load proxy auto-config (PAC): %1</source>
        <translation>Misslyckades med att ladda automatiska proxykonfigurationen (PAC): %1</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkAutomaticProxy.cpp" line="357"/>
        <source>Failed to load proxy auto-config (PAC). Invalid URL: %1</source>
        <translation>Misslyckades med att ladda automatiska proxykonfigurationen (PAC). Ogiltig webbadress: %1</translation>
    </message>
</context>
<context>
    <name>Otter::NetworkManager</name>
    <message>
        <location filename="../../src/core/NetworkManager.cpp" line="125"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkManager.cpp" line="125"/>
        <source>SSL errors occurred:

%1

Do you want to continue?</source>
        <translation>Det uppträdde SSL-fel:

%1

Vill du fortsätta?</translation>
    </message>
</context>
<context>
    <name>Otter::NetworkManagerFactory</name>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.cpp" line="708"/>
        <source>Custom</source>
        <translation>Anpassat</translation>
    </message>
</context>
<context>
    <name>Otter::NotesContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.ui" line="98"/>
        <source>Address:</source>
        <translation>Adress:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.ui" line="105"/>
        <source>Date:</source>
        <translation>Datum:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.ui" line="136"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.ui" line="146"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="48"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="164"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="195"/>
        <source>Add Folder…</source>
        <translation>Lägg till mapp…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="49"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="165"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="193"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="196"/>
        <source>Add Note</source>
        <translation>Lägg till anteckning</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="50"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="166"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="197"/>
        <source>Add Separator</source>
        <translation>Lägg till separerare</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="60"/>
        <source>Add note…</source>
        <translation>Lägg till anteckning…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="106"/>
        <source>Select Folder Name</source>
        <translation>Välj mappens namn</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="106"/>
        <source>Enter folder name:</source>
        <translation>Ange namn på mappen:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="156"/>
        <source>Empty Trash</source>
        <translation>Töm papperskorgen</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="181"/>
        <source>Open source page</source>
        <translation>Öppna käll-sida</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="206"/>
        <source>Restore Note</source>
        <translation>Återställ anteckning</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="340"/>
        <source>Notes</source>
        <translation>Anteckningar</translation>
    </message>
</context>
<context>
    <name>Otter::NotificationDialog</name>
    <message>
        <location filename="../../src/ui/NotificationDialog.cpp" line="74"/>
        <location filename="../../src/ui/NotificationDialog.cpp" line="122"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
</context>
<context>
    <name>Otter::OpenAddressDialog</name>
    <message>
        <location filename="../../src/ui/OpenAddressDialog.ui" line="14"/>
        <source>Go to Page</source>
        <translation>Gå till sida</translation>
    </message>
    <message>
        <location filename="../../src/ui/OpenAddressDialog.ui" line="20"/>
        <source>Enter a web address or choose one from the list:</source>
        <translation>Ange en webbadress eller välj en från listan:</translation>
    </message>
</context>
<context>
    <name>Otter::OpenBookmarkDialog</name>
    <message>
        <location filename="../../src/ui/OpenBookmarkDialog.ui" line="14"/>
        <source>Go to Bookmark</source>
        <translation>Gå till Bokmärke</translation>
    </message>
    <message>
        <location filename="../../src/ui/OpenBookmarkDialog.ui" line="20"/>
        <source>Enter the keyword of bookmark:</source>
        <translation>Ange nyckelordet för bokmärke:</translation>
    </message>
</context>
<context>
    <name>Otter::OperaBookmarksImporter</name>
    <message>
        <location filename="../../src/modules/importers/opera/OperaBookmarksImporter.cpp" line="51"/>
        <source>Opera Bookmarks</source>
        <translation>Bokmärke för Opera</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaBookmarksImporter.cpp" line="56"/>
        <source>Imports bookmarks from Opera Browser version 12 or earlier</source>
        <translation>Importerar bokmärken från webbläsaren Opera version 12 eller tidigare</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaBookmarksImporter.cpp" line="101"/>
        <source>Opera bookmarks files (bookmarks.adr)</source>
        <translation>Bokmärkes-filer för Opera (bookmarks.adr)</translation>
    </message>
</context>
<context>
    <name>Otter::OperaNotesImporter</name>
    <message>
        <location filename="../../src/modules/importers/opera/OperaNotesImporter.cpp" line="57"/>
        <source>Import into folder:</source>
        <translation>Importera till mappen:</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaNotesImporter.cpp" line="65"/>
        <source>Opera Notes</source>
        <translation>Anteckningar för Opera</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaNotesImporter.cpp" line="70"/>
        <source>Imports notes from Opera Browser version 12 or earlier</source>
        <translation>Importerar anteckningar från webbläsaren Opera version 12 eller tidigare</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaNotesImporter.cpp" line="115"/>
        <source>Opera notes files (notes.adr)</source>
        <translation>Anteckningsfiler för Opera (notes.adr)</translation>
    </message>
</context>
<context>
    <name>Otter::OperaSearchEnginesImporter</name>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSearchEnginesImporter.cpp" line="45"/>
        <source>Remove existing search engines</source>
        <translation>Ta bort existerande sökmotorer</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSearchEnginesImporter.cpp" line="54"/>
        <source>Opera search engines</source>
        <translation>Opera sökmotorer</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSearchEnginesImporter.cpp" line="59"/>
        <source>Imports search engines from Opera Browser version 12 or earlier</source>
        <translation>Importerar sökmotorer från webbläsaren Opera version 12 eller tidigare</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSearchEnginesImporter.cpp" line="105"/>
        <source>Opera search engines files (search.ini)</source>
        <translation>Sökmotorsfiler för Opera (search.ini)</translation>
    </message>
</context>
<context>
    <name>Otter::OperaSessionImporter</name>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSessionImporter.cpp" line="44"/>
        <source>Opera Session</source>
        <translation>Session för Opera</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSessionImporter.cpp" line="49"/>
        <source>Imports session from Opera Browser version 12 or earlier</source>
        <translation>Importerar sessioner från webbläsaren Opera version 12 eller tidigare</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSessionImporter.cpp" line="94"/>
        <source>Opera session files (*.win)</source>
        <translation>Sessions-filer för Opera (*.win)</translation>
    </message>
</context>
<context>
    <name>Otter::OpmlImporter</name>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporter.cpp" line="84"/>
        <source>OPML Feeds</source>
        <translation>OPML-flöden</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporter.cpp" line="89"/>
        <source>Imports feeds from OPML file</source>
        <translation>Importera flöden från OPML-fil</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporter.cpp" line="119"/>
        <source>OPML files (*.opml)</source>
        <translation>OPML-filer (*.opml)</translation>
    </message>
</context>
<context>
    <name>Otter::OpmlImporterWidget</name>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporterWidget.ui" line="22"/>
        <source>Import into folder:</source>
        <translation>Importera till mappen:</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporterWidget.ui" line="41"/>
        <source>New…</source>
        <translation>Ny…</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporterWidget.ui" line="52"/>
        <source>Allow to duplicate already existing feeds</source>
        <translation>Tillåt att fördubbla redan existerande flöden</translation>
    </message>
</context>
<context>
    <name>Otter::OptionWidget</name>
    <message>
        <location filename="../../src/ui/OptionWidget.cpp" line="50"/>
        <source>No</source>
        <translation>Nej</translation>
    </message>
    <message>
        <location filename="../../src/ui/OptionWidget.cpp" line="51"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../../src/ui/OptionWidget.cpp" line="194"/>
        <source>Defaults</source>
        <translation>Förval</translation>
    </message>
</context>
<context>
    <name>Otter::PageInformationContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="42"/>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="110"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="42"/>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="110"/>
        <source>Value</source>
        <translation>Värde</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="136"/>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="137"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;empty&gt;</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="158"/>
        <source>General</source>
        <translation>Allmänt</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="164"/>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="168"/>
        <source>MIME type</source>
        <translation>MIME-typ</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="169"/>
        <source>Document size</source>
        <translation>Dokumentstorlek</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="170"/>
        <source>Total size</source>
        <translation>Total storlek</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="174"/>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="178"/>
        <source>Number of requests</source>
        <translation>Antal förfrågningar</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="174"/>
        <source>%1 (%n blocked)</source>
        <translation><numerusform>%1 (%n blockerad)</numerusform><numerusform>%1 (%n blockerade)</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="181"/>
        <source>Downloaded</source>
        <translation>Nedladdade</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="187"/>
        <source>Headers</source>
        <translation>Huvuden</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="202"/>
        <source>Meta</source>
        <translation>Meta</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="220"/>
        <source>Permissions</source>
        <translation>Rättigheter</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="224"/>
        <source>Security</source>
        <translation>Säkerhet</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="232"/>
        <source>Cipher protocol</source>
        <translation>Kodningsförfarandets protokoll</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="233"/>
        <source>Cipher authentication method</source>
        <translation>Kodningsförfarandets autentiseringsmetod</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="234"/>
        <source>Cipher encryption method</source>
        <translation>Kodningsförfarandets kodningsmetod</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="235"/>
        <source>Cipher key exchange method</source>
        <translation>Kodningsförfarandets metod för nyckelutbyte</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="262"/>
        <source>Page Information</source>
        <translation>Sidoinformation</translation>
    </message>
</context>
<context>
    <name>Otter::PasswordBarWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.ui" line="61"/>
        <source>Save</source>
        <translation>Spara</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.ui" line="68"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.cpp" line="37"/>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.cpp" line="55"/>
        <source>Do you want to update login data for %1?</source>
        <translation>Vill du uppdatera inloggningsdatan för %1?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.cpp" line="37"/>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.cpp" line="55"/>
        <source>Do you want to save login data for %1?</source>
        <translation>Vill du spara inloggningsdatan för %1?</translation>
    </message>
</context>
<context>
    <name>Otter::PasswordsContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="70"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="77"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="70"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="77"/>
        <source>Value</source>
        <translation>Värde</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="91"/>
        <source>Set #%1</source>
        <translation>Ställ in #%1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="179"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="235"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="254"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="180"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="236"/>
        <source>You are about to delete %n password(s).</source>
        <translation><numerusform>Du är på väg att ta bort %n lösenord.</numerusform><numerusform>Du är på väg att ta bort %n lösenord.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="181"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="237"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="256"/>
        <source>Do you want to continue?</source>
        <translation>Vill du fortsätta?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="255"/>
        <source>You are about to delete all passwords.</source>
        <translation>Du är på väg att ta bort alla lösenord.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="277"/>
        <source>Remove Password</source>
        <translation>Ta bort lösenord</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="280"/>
        <source>Remove All Passwords from This Domain…</source>
        <translation>Ta bort alla lösenord från denna domänen…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="283"/>
        <source>Remove All Passwords…</source>
        <translation>Ta bort alla lösenord…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="369"/>
        <source>Passwords</source>
        <translation>Lösenord</translation>
    </message>
</context>
<context>
    <name>Otter::PermissionBarWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.ui" line="62"/>
        <source>Allow this time</source>
        <translation>Tillåt den här tiden</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.ui" line="67"/>
        <source>Always allow</source>
        <translation>Tillåt alltid</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.ui" line="72"/>
        <source>Always deny</source>
        <translation>Neka alltid</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.ui" line="80"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.ui" line="87"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="66"/>
        <source>%1 wants to enter full screen mode.</source>
        <translation>%1 vill byta till helskärmsläge.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="71"/>
        <source>%1 wants access to your location.</source>
        <translation>%1 vill ha tillgång till din position.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="76"/>
        <source>%1 wants to show notifications.</source>
        <translation>%1 vill visa aviseringar.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="81"/>
        <source>%1 wants to lock mouse pointer.</source>
        <translation>%1 vill låsa muspekaren.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="86"/>
        <source>%1 wants to access your microphone.</source>
        <translation>%1 vill ha tillgång till din mikrofon.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="91"/>
        <source>%1 wants to access your camera.</source>
        <translation>%1 vill ha tillgång till din kamera.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="96"/>
        <source>%1 wants to access your microphone and camera.</source>
        <translation>%1 vill ha tillgång till din mikrofon och kamera.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="101"/>
        <source>%1 wants to play audio.</source>
        <translation>%1 vill spela upp ljud.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="106"/>
        <source>Invalid permission request from %1.</source>
        <translation>Ogiltig tillgångsförfrågning från %1.</translation>
    </message>
</context>
<context>
    <name>Otter::PlatformIntegration</name>
    <message>
        <location filename="../../src/core/PlatformIntegration.cpp" line="137"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/core/PlatformIntegration.cpp" line="137"/>
        <source>Failed to install update.</source>
        <translation>Misslyckades med att installera uppdateringen.</translation>
    </message>
</context>
<context>
    <name>Otter::PopupsBarWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.ui" line="61"/>
        <source>Details</source>
        <translation>Detaljer</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.ui" line="71"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="62"/>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="70"/>
        <source>%1 wants to open %n pop-up window(s).</source>
        <translation><numerusform>%1 vill öppna %n extrafönster.</numerusform><numerusform>%1 vill öppna %n extrafönster.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="104"/>
        <source>Open All Pop-Ups from This Website</source>
        <translation>Öppna alla extrafönster från den här webbplatsen</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="104"/>
        <source>Open Pop-Ups from This Website in Background</source>
        <translation>Öppna extrafönster från denna webbplatsen i bakgrunden</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="104"/>
        <source>Block All Pop-Ups from This Website</source>
        <translation>Blockera alla extrafönster från den här webbplatsen</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="104"/>
        <source>Always Ask What to Do for This Website</source>
        <translation>Fråga alltid vad som ska göras med den här webbplatsen</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="118"/>
        <source>Blocked Pop-ups</source>
        <translation>Blockerade extrafönster</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="119"/>
        <source>Open All</source>
        <translation>Öppna alla</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesAdvancedPageWidget</name>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="55"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="374"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="768"/>
        <source>General</source>
        <translation>Generella</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="62"/>
        <source>Smooth scrolling</source>
        <translation>Mjuk rullning</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="69"/>
        <source>Check spelling</source>
        <translation>Kontrollera rättstavning</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="82"/>
        <source>Address Field Suggestions</source>
        <translation>Förslag för adressfältet</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="91"/>
        <source>Suggest bookmarks</source>
        <translation>Föreslå bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="98"/>
        <source>Suggest history</source>
        <translation>Föreslå historik</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="108"/>
        <source>Suggest search results</source>
        <translation>Föreslå sökresultat</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="115"/>
        <source>Local paths</source>
        <translation>Lokala sökvägar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="130"/>
        <source>Address Completion</source>
        <translation>Adresskomplettering</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="139"/>
        <source>Show category headers</source>
        <translation>Visa Kategoriöverskrifter</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="148"/>
        <source>Display mode:</source>
        <translation>Visningsläge:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="185"/>
        <source>Events</source>
        <translation>Händelser</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="225"/>
        <source>Play sound:</source>
        <translation>Spela upp ljud:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="240"/>
        <source>Show notification</source>
        <translation>Visa avisering</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="247"/>
        <source>Mark taskbar entry</source>
        <translation>Markera elementet i aktivitetshanteraren</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="263"/>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="270"/>
        <source>Prefer native notifications</source>
        <translation>Föredra nativa aviseringar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="300"/>
        <source>Style</source>
        <translation>Stil</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="309"/>
        <source>Widget style:</source>
        <translation>Stil för komponenter:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="319"/>
        <source>Interface style sheet:</source>
        <translation>Stilmall för gränssnitt:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="343"/>
        <source>Other</source>
        <translation>Andra</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="350"/>
        <source>Show tray icon</source>
        <translation>Visa ikon i aktivitetsfältet</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="383"/>
        <source>Images:</source>
        <translation>Bilder:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="397"/>
        <source>Enable JavaScript</source>
        <translation>Aktivera JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="404"/>
        <source>JavaScript Options…</source>
        <translation>Alternativ för JavaScript…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="415"/>
        <source>Plugins:</source>
        <translation>Insticksprogram:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="425"/>
        <source>User style sheet:</source>
        <translation>Användars-stilmall:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="443"/>
        <source>Website Preferences</source>
        <translation>Egenskaper för webbplats</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="454"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="481"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="559"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="821"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="904"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1016"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1239"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1392"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="491"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="831"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="914"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1249"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1402"/>
        <source>Edit…</source>
        <translation>Redigera…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="501"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="569"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="841"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="924"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1026"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1269"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1422"/>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="535"/>
        <source>MIME Types</source>
        <translation>MIME-typer</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="611"/>
        <source>Show download dialog</source>
        <translation>Visa dialogrutan för nedladdning</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="621"/>
        <source>Save to disk</source>
        <translation>Spara till disk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="664"/>
        <source>Do not ask for folder, save directly to</source>
        <translation>Fråga inte efter mapp, spara direkt till</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="679"/>
        <source>Open with application</source>
        <translation>Öppna med applikationen</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="725"/>
        <source>Pass web address directly to application</source>
        <translation>Skicka vidare webbadressen direkt till applikationen</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="775"/>
        <source>Send referrer information</source>
        <translation>Sänd referensinformation</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="788"/>
        <source>User Agent</source>
        <translation>Användaragent</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="871"/>
        <source>Proxy</source>
        <translation>Proxy</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="971"/>
        <source>SSL Ciphers</source>
        <translation>SSL-kodningsförfaranden</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1051"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1294"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1447"/>
        <source>Move Up</source>
        <translation>Flytta upp</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1077"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1320"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1473"/>
        <source>Move Down</source>
        <translation>Flytta ned</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1100"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Updates</source>
        <translation>Uppdateringar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1107"/>
        <source>Select channels from which you want to receive updates:</source>
        <translation>Välj de kanaler som du vill ta emot uppdateringar ifrån:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1149"/>
        <source>Check for updates every</source>
        <translation>Sök efter uppdateringar varje</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1159"/>
        <source>day(s)</source>
        <translation>dag(ar)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1168"/>
        <source>Install updates automatically</source>
        <translation>Installera uppdateringar automatiskt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1200"/>
        <source>Keyboard Shortcuts</source>
        <translation>Tangentbordsgenvägar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1259"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1412"/>
        <source>Clone</source>
        <translation>Klona</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1333"/>
        <source>Enable single key shortcuts</source>
        <translation>Aktivera entangents-genvägar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1353"/>
        <source>Mouse Actions and Gestures</source>
        <translation>Mus-aktioner och -gester</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1486"/>
        <source>Enable mouse gestures</source>
        <translation>Aktivera mus-gester</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Browsing</source>
        <translation>Surfning</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Notifications</source>
        <translation>Aviseringar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Appearance</source>
        <translation>Utseende</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Content</source>
        <translation>Innehåll</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Downloads</source>
        <translation>Nedladdningar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Programs</source>
        <translation>Program</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>History</source>
        <translation>Historik</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Network</source>
        <translation>Nätverk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Security</source>
        <translation>Säkerhet</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Keyboard</source>
        <translation>Tangentbord</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Mouse</source>
        <translation>Mus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="107"/>
        <source>Compact</source>
        <translation>Kompakt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="108"/>
        <source>Columns</source>
        <translation>Spalter</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="115"/>
        <source>WAV files (*.wav)</source>
        <translation>WAV-filer (*.wav)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="118"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="186"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="118"/>
        <source>Description</source>
        <translation>Beskrivning</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="140"/>
        <source>System Style</source>
        <translation>Systemstil</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="149"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="169"/>
        <source>Style sheets (*.css)</source>
        <translation>Stilmallar (*.css)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="152"/>
        <source>All images</source>
        <translation>Alla bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="153"/>
        <source>Cached images</source>
        <translation>Cachade bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="154"/>
        <source>No images</source>
        <translation>Inga bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="161"/>
        <source>Enabled</source>
        <translation>Aktiverad</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="162"/>
        <source>On demand</source>
        <translation>Vid begäran</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="163"/>
        <source>Disabled</source>
        <translation>Inaktiverad</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="209"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="224"/>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="209"/>
        <source>Value</source>
        <translation>Värde</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="217"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="232"/>
        <source>Add Folder…</source>
        <translation>Lägg till mapp…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="218"/>
        <source>Add User Agent…</source>
        <translation>Lägg till användaragent…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="219"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="234"/>
        <source>Add Separator</source>
        <translation>Lägg till separerare</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="233"/>
        <source>Add Proxy…</source>
        <translation>Lägg till proxy…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="291"/>
        <source>Stable version</source>
        <translation>Stabil version</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="291"/>
        <source>Beta version</source>
        <translation>Beta-version</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="291"/>
        <source>Weekly development version</source>
        <translation>Vecko-baserad utvecklingsversion</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="339"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="375"/>
        <source>New…</source>
        <translation>Ny…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="340"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="376"/>
        <source>Readd</source>
        <translation>Lägg till igen</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="576"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1265"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1460"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="576"/>
        <source>Do you really want to remove preferences for this website?</source>
        <translation>Vill du verkligen ta bort inställningarna för den här hemsidan?</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="594"/>
        <source>MIME Type Name</source>
        <translation>Namn för MIME-typ</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="594"/>
        <source>Select name of MIME Type:</source>
        <translation>Välj MIME-typens namn:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="614"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="614"/>
        <source>Invalid MIME Type name.</source>
        <translation>Ogiltigt namn på MIME-typ.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="739"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="801"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="905"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="967"/>
        <source>Folder Name</source>
        <translation>Mappens namn</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="739"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="801"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="905"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="967"/>
        <source>Select folder name:</source>
        <translation>Välj mappens namn:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="743"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="767"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="805"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="822"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="909"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="934"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="971"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="987"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1156"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1351"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="757"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="923"/>
        <source>Custom</source>
        <translation>Anpassad</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1266"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1461"/>
        <source>Do you really want to remove this profile?</source>
        <translation>Vill du verkligen ta bort den här profilen?</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1275"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1470"/>
        <source>Delete profile permanently</source>
        <translation>Ta bort den här profilen permanent</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesContentPageWidget</name>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="23"/>
        <source>Blocking</source>
        <translation>Blockerar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="35"/>
        <source>Pop-ups:</source>
        <translation>Extrafönster:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="56"/>
        <source>Zoom</source>
        <translation>Zooma in</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="68"/>
        <source>Default zoom:</source>
        <translation>Förvald zoom:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="78"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="96"/>
        <source>Zoom text only</source>
        <translation>Zooma endast in text</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="109"/>
        <source>Fonts</source>
        <translation>Typsnitt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="143"/>
        <source>Default proportional font size:</source>
        <translation>Standardstorlek av proportionella typsnitt:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="153"/>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="179"/>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="208"/>
        <source> px</source>
        <translation>px</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="169"/>
        <source>Default fixed-width font size:</source>
        <translation>Standardstorlek av typsnitt med fast bredd:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="195"/>
        <source>Minimum font size:</source>
        <translation>Minsta storlek på typsnitt:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="205"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="229"/>
        <source>Colors</source>
        <translation>Färger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="119"/>
        <source>Ask</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="120"/>
        <source>Block all</source>
        <translation>Blockera alla</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="121"/>
        <source>Open all</source>
        <translation>Öppna alla</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="122"/>
        <source>Open all in background</source>
        <translation>Öppna alla i bakgrunden</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="134"/>
        <source>Style</source>
        <translation>Stil</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="134"/>
        <source>Font</source>
        <translation>Typsnitt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="134"/>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="157"/>
        <source>Preview</source>
        <translation>Förhandsgranska</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Standard font</source>
        <translation>Standard-typsnitt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Fixed-width font</source>
        <translation>Typsnitt med fast bredd</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Serif font</source>
        <translation>Serif-typsnitt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Sans-serif font</source>
        <translation>Sans-serif-typsnitt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Cursive font</source>
        <translation>Kursivt typsnitt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Fantasy font</source>
        <translation>Fantasi-typsnitt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="143"/>
        <source>The quick brown fox jumps over the lazy dog</source>
        <translation>Flygande bäckasiner söka hwila på mjuka tuvor</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="157"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="161"/>
        <source>Background Color</source>
        <translation>Bakgrundsfärg</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="161"/>
        <source>Text Color</source>
        <translation>Textfärg</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="161"/>
        <source>Link Color</source>
        <translation>Länkfärg</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="161"/>
        <source>Visited Link Color</source>
        <translation>Färg för besökt länk</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesDialog</name>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="17"/>
        <source>Preferences</source>
        <translation>Egenskaper</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="27"/>
        <source>General</source>
        <translation>Generella</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="33"/>
        <source>Content</source>
        <translation>Innehåll</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="39"/>
        <source>Privacy</source>
        <translation>Integritet</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="45"/>
        <source>Search</source>
        <translation>Sök efter</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="51"/>
        <source>Advanced</source>
        <translation>Avancerat</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="62"/>
        <source>All Settings</source>
        <translation>Alla inställningar</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesGeneralPageWidget</name>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="23"/>
        <source>Startup</source>
        <translation>Uppstart</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="35"/>
        <source>Startup behavior:</source>
        <translation>Beteende vid uppstart:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="48"/>
        <source>Home page:</source>
        <translation>Startsida:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="76"/>
        <source>Use Current Page</source>
        <translation>Använd aktuella sidan</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="83"/>
        <source>Use Bookmark</source>
        <translation>Använd bokmärke</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="90"/>
        <source>Restore to Default</source>
        <translation>Återställ till förval</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="99"/>
        <source>Do not load the tab contents until selected</source>
        <translation>Ladda inte flikens innehåll till dess att den väljs</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="114"/>
        <source>Downloads</source>
        <translation>Nedladdningar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="126"/>
        <source>Save files to:</source>
        <translation>Spara filer till:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="141"/>
        <source>Always ask me where to save files</source>
        <translation>Fråga mig alltid var filerna ska sparas</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="154"/>
        <source>Tabs</source>
        <translation>Flikar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="161"/>
        <source>Open new windows in new tabs instead</source>
        <translation>Öppna nya fönster istället i nya flikar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="168"/>
        <source>Reuse current tab</source>
        <translation>Återanvänd aktuella fliken</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="175"/>
        <source>Open new tab next to active</source>
        <translation>Öppna ny flik intill den aktiva</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="184"/>
        <source>When closing tab:</source>
        <translation>När fliken stängs:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="198"/>
        <source>Activate the last active tab</source>
        <translation>Aktivera den senaste aktiva fliken</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="203"/>
        <source>Activate the next tab</source>
        <translation>Aktivera nästa flik</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="208"/>
        <source>Activate the first tab opened from current tab</source>
        <translation>Aktivera den fösta fliken som blev öppnad av aktuella fliken</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="224"/>
        <source>Language</source>
        <translation>Språk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="233"/>
        <source>Preferred webpage language:</source>
        <translation>Föredraget språk för hemsidor:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="258"/>
        <source>Edit…</source>
        <translation>Redigera…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="275"/>
        <source>System Defaults</source>
        <translation>Systemförval</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="287"/>
        <source>Set as a default browser</source>
        <translation>Ställ in som standardwebbläsare</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.cpp" line="45"/>
        <source>Show windows and tabs from the last time</source>
        <translation>Visa fönster och flikar från förra gången</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.cpp" line="46"/>
        <source>Show startup dialog</source>
        <translation>Visa uppstartsruta</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.cpp" line="47"/>
        <source>Show home page</source>
        <translation>Visa hemsida</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.cpp" line="48"/>
        <source>Show start page</source>
        <translation>Visa startsida</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.cpp" line="49"/>
        <source>Show empty page</source>
        <translation>Visa tom sida</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesPrivacyPageWidget</name>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="23"/>
        <source>Tracking</source>
        <translation>Spårning</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="32"/>
        <source>Do Not Track:</source>
        <translation>Spåra inte:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="57"/>
        <source>History</source>
        <translation>Historik</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="64"/>
        <source>Private mode</source>
        <translation>Privat läge</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="107"/>
        <source>Remember browsing history</source>
        <translation>Kom ihåg surfningshistoriken</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="114"/>
        <source>Remember downloads history</source>
        <translation>Kom ihåg nedladdningshistoriken</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="124"/>
        <source>Remember search history</source>
        <translation>Kom ihåg sök-historiken</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="136"/>
        <source>Remember form history</source>
        <translation>Kom ihåg formulär-historik</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="159"/>
        <source>Template…</source>
        <translation>Mall…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="170"/>
        <source>Enable cookies</source>
        <translation>Aktivera kakor</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="215"/>
        <source>Accept cookies:</source>
        <translation>Ta emot kakor:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="228"/>
        <source>Keep until:</source>
        <translation>Behåll tills:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="241"/>
        <source>Accept third-party cookies:</source>
        <translation>Ta emot kakor från tredjepart:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="263"/>
        <source>Exceptions…</source>
        <translation>Undantag…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="279"/>
        <source>Clear history when application closes</source>
        <translation>Töm historiken när applikationen stängs</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="299"/>
        <source>Settings…</source>
        <translation>Inställningar…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="319"/>
        <source>Passwords</source>
        <translation>Lösenord</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="328"/>
        <source>Remember passwords</source>
        <translation>Kom ihåg lösenord</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="348"/>
        <source>Manage…</source>
        <translation>Hantera…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="362"/>
        <source>Use a master password</source>
        <translation>Använd ett huvudlösenord</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="385"/>
        <source>Change…</source>
        <translation>Ändra…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="40"/>
        <source>Inform websites that I do not want to be tracked</source>
        <translation>Informera hemsidor att jag inte vill bli spårad</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="41"/>
        <source>Inform websites that I allow tracking</source>
        <translation>Informera hemsidor att jag vill tillåta spårning</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="42"/>
        <source>Do not inform websites about my preference</source>
        <translation>Informera hemsidor inte om vad jag föredrar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="53"/>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="67"/>
        <source>Always</source>
        <translation>Alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="54"/>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="68"/>
        <source>Only existing</source>
        <translation>Endast existerande</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="55"/>
        <source>Only read existing</source>
        <translation>Läs endast existerande</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="60"/>
        <source>Expires</source>
        <translation>Slutar gälla</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="61"/>
        <source>Current session is closed</source>
        <translation>Den aktuella sessionen är stängd</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="62"/>
        <source>Always ask</source>
        <translation>Fråga alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="69"/>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesSearchPageWidget</name>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="21"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="60"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="70"/>
        <source>Edit…</source>
        <translation>Redigera…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="80"/>
        <source>Update</source>
        <translation>Uppdatering</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="90"/>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="115"/>
        <source>Move Up</source>
        <translation>Flytta upp</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="141"/>
        <source>Move Down</source>
        <translation>Flytta ned</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="154"/>
        <source>Enable search suggestions</source>
        <translation>Aktivera sökförslag</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="98"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="163"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="98"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="163"/>
        <source>Keyword</source>
        <translation>Nyckelord</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="127"/>
        <source>New…</source>
        <translation>Ny…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="128"/>
        <source>File…</source>
        <translation>Fil…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="130"/>
        <source>Readd</source>
        <translation>Lägg till igen</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="178"/>
        <source>New Search Engine</source>
        <translation>Ny sökmotor</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="199"/>
        <source>Select File</source>
        <translation>Välj fil</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="199"/>
        <source>Open Search files (*.xml)</source>
        <translation>Öppna sök-filer (*.xml)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="307"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="370"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="308"/>
        <source>Do you really want to remove this search engine?</source>
        <translation>Vill du verkligen ta bort den här sökmotorn?</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="317"/>
        <source>Delete search engine permanently</source>
        <translation>Ta bort sökmotorn permanent</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="349"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="360"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="448"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="349"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="360"/>
        <source>Failed to open Open Search file.</source>
        <translation>Misslyckades med att öppna Opera-sökfil.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="371"/>
        <source>Keyword is already in use. Do you want to continue anyway?</source>
        <translation>Nyckelordet används redan. Vill du ändå fortsätta?</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="448"/>
        <source>Failed to update search engine.</source>
        <translation>Misslyckades med att uppdatera sökmotorn.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="511"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
</context>
<context>
    <name>Otter::PrivateWindowIndicatorWidget</name>
    <message>
        <location filename="../../src/modules/widgets/privateWindowIndicator/PrivateWindowIndicatorWidget.cpp" line="33"/>
        <location filename="../../src/modules/widgets/privateWindowIndicator/PrivateWindowIndicatorWidget.cpp" line="49"/>
        <source>Private Window</source>
        <translation>Privat fönster</translation>
    </message>
</context>
<context>
    <name>Otter::ProgressBarDelegate</name>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="57"/>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
</context>
<context>
    <name>Otter::ProgressInformationWidget</name>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="111"/>
        <source>Document: %p%</source>
        <translation>Dokument: %p%</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="111"/>
        <source>Document: ?</source>
        <translation>Dokument: ?</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="119"/>
        <source>Total: ?</source>
        <translation>Totalt: ?</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="119"/>
        <source>Total: %p%</source>
        <translation>Totalt: %p%</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="127"/>
        <source>Total: %1</source>
        <translation>Totalt: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="134"/>
        <source>Elements: %1/%2</source>
        <translation>Element: %1/%2</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="141"/>
        <source>Speed: %1</source>
        <translation>Hastighet: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="150"/>
        <source>Time: %1</source>
        <translation>Tid: %1</translation>
    </message>
</context>
<context>
    <name>Otter::ProxyPropertiesDialog</name>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="19"/>
        <source>Title:</source>
        <translation>Titel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="38"/>
        <source>General</source>
        <translation>Allmänt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="44"/>
        <source>Manual</source>
        <translation>Manuellt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="144"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="151"/>
        <source>Protocol</source>
        <translation>Protokoll</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="158"/>
        <source>Servers</source>
        <translation>Servrar</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="165"/>
        <source>FTP</source>
        <translation>FTP</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="172"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="179"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="193"/>
        <source>HTTPS</source>
        <translation>HTTPS</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="207"/>
        <source>All</source>
        <translation>Alla</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="229"/>
        <source>Automatic</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="273"/>
        <source>Path to PAC file:</source>
        <translation>Sökväg till PAC-filen:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="286"/>
        <source>Use system authentication</source>
        <translation>Använd system-autentisering</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="301"/>
        <source>Exceptions</source>
        <translation>Undantag</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="307"/>
        <source>Do not use this proxy for:</source>
        <translation>Använd denna proxyn int för:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="328"/>
        <source>Add</source>
        <translation>Lägg till</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="338"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="348"/>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="372"/>
        <source>Example: domain.com, localhost, 127.0.0.1, 192.168.1.0/24</source>
        <translation>Exempel: domain.com, localhost, 127.0.0.1, 192.168.1.0/24</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.cpp" line="93"/>
        <source>Edit Proxy</source>
        <translation>Redigera proxy</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.cpp" line="93"/>
        <source>Add Proxy</source>
        <translation>Lägg till proxy</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebEnginePage</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="120"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="582"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="622"/>
        <source>JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="121"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="583"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="623"/>
        <source>Disable JavaScript popups</source>
        <translation>Inaktivera JavaScript-extrafönster</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="476"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="489"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="476"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="490"/>
        <source>Are you sure that you want to send form data again?</source>
        <translation>Är du säker på att du vill skicka om formulär-datan?</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="476"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="491"/>
        <source>Do you want to resend data?</source>
        <translation>Vill du skicka om datan?</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="477"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="495"/>
        <source>Do not show this message again</source>
        <translation>Visa inte detta meddelande igen</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebEngineWebBackend</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebBackend.cpp" line="225"/>
        <source>Blink Backend (experimental)</source>
        <translation>Bakände för Blink (experimentellt)</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebBackend.cpp" line="230"/>
        <source>Backend utilizing QtWebEngine module</source>
        <translation>Bakände som använder QtWebEngine-modulen</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebEngineWebWidget</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebWidget.cpp" line="518"/>
        <source>file</source>
        <translation>fil</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebWidget.cpp" line="529"/>
        <source>Failed to save image: %1</source>
        <translation>Misslyckades med att spara bilden: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebWidget.cpp" line="1420"/>
        <source>Blank Page</source>
        <translation>Tom sida</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebWidget.cpp" line="1433"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitFtpListingNetworkReply</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="79"/>
        <source>Network error %1</source>
        <translation>Nätverksfel %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="96"/>
        <source>Unknown command</source>
        <translation>Okänt kommando</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="160"/>
        <source>Directory Contents</source>
        <translation>Mappens innehåll</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="163"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="164"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="165"/>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="166"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitInspector</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitInspector.cpp" line="42"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitNetworkManager</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="201"/>
        <source>Receiving data from %1…</source>
        <translation>Tar emot data från %1…</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="273"/>
        <source>Completed request to %1</source>
        <translation>Slutförde förfrågningen till %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="310"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="339"/>
        <source>Waiting for authentication…</source>
        <translation>Inväntar autentisering…</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="421"/>
        <source>Loading finished</source>
        <translation>Laddning slutförd</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="742"/>
        <source>Sending request to %1…</source>
        <translation>Skickar förfrågning till %1…</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitPage</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="423"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="674"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="714"/>
        <source>JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="424"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="675"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="715"/>
        <source>Disable JavaScript popups</source>
        <translation>Inaktivera JavaScript-extrafönster</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="614"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="627"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="948"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="614"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="628"/>
        <source>Are you sure that you want to send form data again?</source>
        <translation>Är du säker på att du vill skicka om formulär-datan?</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="614"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="629"/>
        <source>Do you want to resend data?</source>
        <translation>Vill du skicka om datan?</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="615"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="633"/>
        <source>Do not show this message again</source>
        <translation>Visa inte det här meddelandet igen</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="787"/>
        <source>%1 error #%2: %3</source>
        <translation>%1 fel #%2: %3</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="859"/>
        <source>Request blocked by rule from profile %1:&lt;br&gt;
%2</source>
        <translation>Förfågan blockerades av regeln från profilen %1:&lt;br&gt;
%2</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="859"/>
        <source>(Unknown)</source>
        <translation>(Okänd)</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="877"/>
        <source>WebKit error %1</source>
        <translation>WebKit fel %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="881"/>
        <source>Network error %1</source>
        <translation>Nätverksfel %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="948"/>
        <source>The script on this page appears to have a problem.</source>
        <translation>Skriptet på den här webbplatsen verkar ha ett problem.</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="948"/>
        <source>Do you want to stop the script?</source>
        <translation>Vill du stoppa skriptet?</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitPluginWidget</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPluginWidget.cpp" line="34"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPluginWidget.cpp" line="43"/>
        <source>Click to load content (%1) handled by plugin from: %2</source>
        <translation>Klicka för att ladda innehållet (%1) som hanteras av insticksmodulen från: %2</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitWebBackend</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebBackend.cpp" line="196"/>
        <source>WebKit Backend (legacy)</source>
        <translation>Bakände för WebKit (föråldrad)</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebBackend.cpp" line="198"/>
        <source>WebKit Backend</source>
        <translation>Bakände för WebKit</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebBackend.cpp" line="204"/>
        <source>Backend utilizing QtWebKit module</source>
        <translation>Bakände som använder QtWebKit-modulen</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitWebWidget</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="421"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="421"/>
        <source>Failed to open file for writing.</source>
        <translation>Misslyckades med att öppna fil för skrivning.</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="441"/>
        <source>file</source>
        <translation>fil</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="449"/>
        <source>Failed to save image: %1</source>
        <translation>Misslyckades med att spara bilden: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="583"/>
        <source>Print Preview</source>
        <translation>Förhandsgranskning för utskrift</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="1696"/>
        <source>PNG image (*.png)</source>
        <translation>PNG-bild (*.png)</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="1696"/>
        <source>JPEG image (*.jpg *.jpeg)</source>
        <translation>JPEG-bild (*.jpg *.jpeg)</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="2127"/>
        <source>Blank Page</source>
        <translation>Tom sida</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="2140"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
</context>
<context>
    <name>Otter::ReloadTimeDialog</name>
    <message>
        <location filename="../../src/ui/ReloadTimeDialog.ui" line="14"/>
        <source>Automatic Page Reload</source>
        <translation>Automatisk omhämtning för sidor</translation>
    </message>
    <message>
        <location filename="../../src/ui/ReloadTimeDialog.ui" line="29"/>
        <source>minutes</source>
        <translation>minuter</translation>
    </message>
    <message>
        <location filename="../../src/ui/ReloadTimeDialog.ui" line="46"/>
        <source>seconds</source>
        <translation>sekunder</translation>
    </message>
</context>
<context>
    <name>Otter::ReportDialog</name>
    <message>
        <location filename="../../src/ui/ReportDialog.ui" line="14"/>
        <source>Diagnostic Report</source>
        <translation>Diagnostisk rapport</translation>
    </message>
    <message>
        <location filename="../../src/ui/ReportDialog.cpp" line="41"/>
        <source>Copy</source>
        <translation>Kopiera</translation>
    </message>
</context>
<context>
    <name>Otter::RssFeedParser</name>
    <message>
        <location filename="../../src/core/FeedParser.cpp" line="376"/>
        <source>Failed to parse feed file: %1</source>
        <translation>Misslyckades med att tolka flödesfilen: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/FeedParser.cpp" line="387"/>
        <source>Failed to parse feed: no valid entries found</source>
        <translation>Misslyckades med att tolka flödet: Inga giltiga element hittades</translation>
    </message>
</context>
<context>
    <name>Otter::SaveSessionDialog</name>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.ui" line="14"/>
        <source>Save Session</source>
        <translation>Spara session</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.ui" line="22"/>
        <source>Session title:</source>
        <translation>Sessionens titel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.ui" line="32"/>
        <source>Session identifier:</source>
        <translation>Sessionens identifierare:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.ui" line="50"/>
        <source>Store only current window</source>
        <translation>Lagra enbart det aktuella fönstret</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.cpp" line="68"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.cpp" line="68"/>
        <source>Session with specified indentifier already exists.
Do you want to overwrite it?</source>
        <translation>Det finns redan en session med den angivna identifieraren.
Vill du överskriva den?</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.cpp" line="81"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.cpp" line="81"/>
        <source>Failed to save session.</source>
        <translation>Misslyckades med att spara sessionen.</translation>
    </message>
</context>
<context>
    <name>Otter::SearchBarWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="35"/>
        <source>Find…</source>
        <translation>Hitta…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="45"/>
        <source>Find Next</source>
        <translation>Hitta sedan</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="55"/>
        <source>Find Previous</source>
        <translation>Hitta före</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="78"/>
        <source>Highlight</source>
        <translation>Markera</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="94"/>
        <source>Case Sensitive</source>
        <translation>Skifteslägeskänslig</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="107"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
</context>
<context>
    <name>Otter::SearchEnginePropertiesDialog</name>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="14"/>
        <source>Edit Search Engine</source>
        <translation>Redigera sökmotor</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="22"/>
        <source>Title:</source>
        <translation>Titel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="49"/>
        <source>Change Icon…</source>
        <translation>Ändra ikon…</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="58"/>
        <source>Description:</source>
        <translation>Beskrivning:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="71"/>
        <source>Keyword:</source>
        <translation>Nyckelord:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="84"/>
        <source>Encoding:</source>
        <translation>Kodning:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="101"/>
        <source>Form address:</source>
        <translation>Formulär-adress:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="117"/>
        <source>Update address:</source>
        <translation>Uppdatera adress:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="133"/>
        <source>Results Query</source>
        <translation>Förfrågning om resultat</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="141"/>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="249"/>
        <source>Address:</source>
        <translation>Adress:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="154"/>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="265"/>
        <source>Query:</source>
        <translation>Förfrågning:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="169"/>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="277"/>
        <source>POST method</source>
        <translation>POST metod</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="210"/>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="318"/>
        <source>Data encoding (enctype):</source>
        <translation>Datakodning (enctype):</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="238"/>
        <source>Suggestions Query</source>
        <translation>Förfrågning om föreslag</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.cpp" line="127"/>
        <source>Placeholders</source>
        <translation>Platshållare</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.cpp" line="128"/>
        <source>Search Terms</source>
        <translation>Söktermer</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.cpp" line="129"/>
        <source>Language</source>
        <translation>Språk</translation>
    </message>
</context>
<context>
    <name>Otter::SearchEnginesManager</name>
    <message>
        <location filename="../../src/core/SearchEnginesManager.cpp" line="171"/>
        <source>Manage Search Engines…</source>
        <translation>Hantera sökmotorer…</translation>
    </message>
    <message>
        <location filename="../../src/core/SearchEnginesManager.cpp" line="192"/>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
</context>
<context>
    <name>Otter::SearchWidget</name>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="193"/>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="194"/>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="670"/>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="671"/>
        <source>Search using %1</source>
        <translation>Sök med %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="311"/>
        <source>Add %1</source>
        <translation>Läg till %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="311"/>
        <source>(untitled)</source>
        <translation>(utan titel)</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="438"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="438"/>
        <source>Failed to add search engine.</source>
        <translation>Misslyckades med att lägga till sökmotor.</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="820"/>
        <source>Select Search Engine</source>
        <translation>Välj sökmotor</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="824"/>
        <source>Add Search Engine…</source>
        <translation>Lägg till sökmotor…</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="828"/>
        <source>Search</source>
        <translation>Sök efter</translation>
    </message>
</context>
<context>
    <name>Otter::SelectPasswordDialog</name>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.ui" line="14"/>
        <source>Select Password</source>
        <translation>Välj lösenord</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.ui" line="20"/>
        <source>Select set of credentials:</source>
        <translation>Välj en sats av anmälningsinformationer:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.ui" line="41"/>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="38"/>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="79"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="38"/>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="79"/>
        <source>Value</source>
        <translation>Värde</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="42"/>
        <source>Set #%1</source>
        <translation>Ställ in #%1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="87"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="87"/>
        <source>Do you really want to remove this credentials set?</source>
        <translation>Vill du verkligen ta bort den här satsen av anmälningsinformationer?</translation>
    </message>
</context>
<context>
    <name>Otter::SessionModel</name>
    <message>
        <location filename="../../src/core/SessionModel.cpp" line="247"/>
        <source>Session</source>
        <translation>Session</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionModel.cpp" line="250"/>
        <source>Trash</source>
        <translation>Papperskorg</translation>
    </message>
</context>
<context>
    <name>Otter::SessionsManager</name>
    <message>
        <location filename="../../src/core/SessionsManager.cpp" line="222"/>
        <source>Default</source>
        <translation>Förval</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionsManager.cpp" line="222"/>
        <location filename="../../src/core/SessionsManager.cpp" line="368"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionsManager.h" line="109"/>
        <source>Start Page</source>
        <translation>Startsida</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionsManager.h" line="112"/>
        <source>(Unknown)</source>
        <translation>(Okänd)</translation>
    </message>
</context>
<context>
    <name>Otter::SessionsManagerDialog</name>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.ui" line="14"/>
        <source>Sessions Manager</source>
        <translation>Sessionshanterare</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.ui" line="52"/>
        <source>Open</source>
        <translation>Öppna</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.ui" line="59"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.ui" line="77"/>
        <source>Open session in current window</source>
        <translation>Öppna sessionen i det aktuella fönstret</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="45"/>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="69"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="49"/>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="98"/>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="49"/>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="98"/>
        <source>Identifier</source>
        <translation>Identifierare</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="49"/>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="98"/>
        <source>Windows</source>
        <translation>Fönster</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="69"/>
        <source>%n window(s) (%1)</source>
        <translation><numerusform>%n fönster (%1)</numerusform><numerusform>%n fönster (%1)</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="69"/>
        <source>%n tab(s)</source>
        <translation><numerusform>%n flik</numerusform><numerusform>%n flikar</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="106"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="106"/>
        <source>This session was not saved correctly.
Are you sure that you want to restore this session anyway?</source>
        <translation>Den här sessionen sparades inte korrekt.
Är du säker på att du ändå vill återställa den här sessionen?
</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="123"/>
        <source>Confirm</source>
        <translation>Bekräfta</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="123"/>
        <source>Are you sure that you want to delete session %1?</source>
        <translation>Är du säker på att du vill ta bort sessionen %1?</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="131"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="131"/>
        <source>Failed to delete session.</source>
        <translation>Misslyckades med att ta bort sessionen.</translation>
    </message>
</context>
<context>
    <name>Otter::SettingsManager</name>
    <message>
        <location filename="../../src/core/SettingsManager.cpp" line="358"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../../src/core/SettingsManager.cpp" line="358"/>
        <source>No</source>
        <translation>Nej</translation>
    </message>
    <message>
        <location filename="../../src/core/SettingsManager.cpp" line="363"/>
        <source>Invalid</source>
        <translation>Ogiltig</translation>
    </message>
</context>
<context>
    <name>Otter::ShortcutWidget</name>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="41"/>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="71"/>
        <source>Clear</source>
        <translation>Töm</translation>
    </message>
</context>
<context>
    <name>Otter::SidebarWidget</name>
    <message>
        <location filename="../../src/ui/SidebarWidget.ui" line="69"/>
        <source>Panels</source>
        <translation>Paneler</translation>
    </message>
    <message>
        <location filename="../../src/ui/SidebarWidget.cpp" line="160"/>
        <source>Add web panel</source>
        <translation>Lägg till webbpanel</translation>
    </message>
    <message>
        <location filename="../../src/ui/SidebarWidget.cpp" line="467"/>
        <source>Add Web Panel…</source>
        <translation>Lägg till webbpanel…</translation>
    </message>
</context>
<context>
    <name>Otter::SourceViewerWebWidget</name>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="87"/>
        <source>Failed to save file: %1</source>
        <translation>Misslyckades med att spara filen: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="89"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="89"/>
        <source>Failed to save file.</source>
        <translation>Misslyckades med att spara fil.</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="115"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="115"/>
        <source>The document has been modified.
Do you want to save your changes or discard them?</source>
        <translation>Dokumentet har ändrats.
Vill du spara ändringarna eller kasta dem?</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="300"/>
        <source>Show Line Numbers</source>
        <translation>Visa radnummer</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="425"/>
        <source>Source Viewer: %1</source>
        <translation>Granskare för källor: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="425"/>
        <source>Source Viewer</source>
        <translation>Granskare för källor</translation>
    </message>
</context>
<context>
    <name>Otter::StartPageModel</name>
    <message>
        <location filename="../../src/modules/windows/web/StartPageModel.cpp" line="100"/>
        <location filename="../../src/modules/windows/web/StartPageModel.cpp" line="101"/>
        <source>Add Tile…</source>
        <translation>Lägg till kakel…</translation>
    </message>
</context>
<context>
    <name>Otter::StartPagePreferencesDialog</name>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="14"/>
        <source>Start Page Preferences</source>
        <translation>Egenskaper för startsida</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="20"/>
        <source>Use custom background image</source>
        <translation>Använd anpassad bakgrundsbild</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="66"/>
        <source>Scaling mode:</source>
        <translation>Skalningsläge:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="79"/>
        <source>Image path:</source>
        <translation>Sökväg till bild:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="89"/>
        <source>Color:</source>
        <translation>Färg:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="109"/>
        <source>Columns per row:</source>
        <translation>Kolumner per rad:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="119"/>
        <source>Automatic</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="126"/>
        <source>Zoom level:</source>
        <translation>Zoomningsnivå:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="136"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="154"/>
        <source>Show search field</source>
        <translation>Visa sökfältet</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="161"/>
        <source>Show tile to add new entries</source>
        <translation>Visa kakel för att lägga till nya element</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.cpp" line="40"/>
        <source>Images (*.png *.jpg *.bmp *.gif *.svg *.svgz)</source>
        <translation>Bilder (*.png *.jpg *.bmp *.gif *.svg *.svgz)</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.cpp" line="41"/>
        <source>Best fit</source>
        <translation>Bästa anpassning</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.cpp" line="42"/>
        <source>Center</source>
        <translation>Centrum</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.cpp" line="43"/>
        <source>Stretch</source>
        <translation>Sträck ut</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.cpp" line="44"/>
        <source>Tile</source>
        <translation>Kakel</translation>
    </message>
</context>
<context>
    <name>Otter::StartPageWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="560"/>
        <source>Add Tile</source>
        <translation>Lägg till kakel</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="847"/>
        <source>Edit…</source>
        <translation>Redigera…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="851"/>
        <source>Reload</source>
        <translation>Hämta om</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="859"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="863"/>
        <source>Configure…</source>
        <translation>Ställ in…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="867"/>
        <source>Add Tile…</source>
        <translation>Lägg till kakel…</translation>
    </message>
</context>
<context>
    <name>Otter::StartupDialog</name>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="14"/>
        <location filename="../../src/ui/StartupDialog.ui" line="27"/>
        <source>Welcome to Otter</source>
        <translation>Välkommen till Otter</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="34"/>
        <source>Continue session</source>
        <translation>Fortsätt med sessionen</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="104"/>
        <source>Begin with home page</source>
        <translation>Börja med hemsidan</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="114"/>
        <source>Begin with start page</source>
        <translation>Börja med startsidan</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="124"/>
        <source>Begin with blank page</source>
        <translation>Börja med tom sida</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="134"/>
        <source>Enable plugins</source>
        <translation>Aktivera insticksprogram</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.cpp" line="55"/>
        <location filename="../../src/ui/StartupDialog.cpp" line="62"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.cpp" line="122"/>
        <source>Window %1</source>
        <translation>Fönster %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.cpp" line="132"/>
        <source>Title: %1
Address: %2</source>
        <translation>Titel: %1 Adress: %2</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.cpp" line="225"/>
        <source>Default</source>
        <translation>Förval</translation>
    </message>
</context>
<context>
    <name>Otter::TabBarToolBarWidget</name>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="1186"/>
        <source>Switch Tabs Using the Mouse Wheel</source>
        <translation>Växla flikar med mushjulet</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="1190"/>
        <source>Show Thumbnails in Tabs</source>
        <translation>Visa minibilder i flikar</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="1209"/>
        <source>Arrange</source>
        <translation>Anordna</translation>
    </message>
</context>
<context>
    <name>Otter::TabBarWidget</name>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="808"/>
        <source>Arrange</source>
        <translation>Anordna</translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="820"/>
        <source>Switch Tabs Using the Mouse Wheel</source>
        <translation>Växla flikar med mushjulet</translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="824"/>
        <source>Show Thumbnails in Tabs</source>
        <translation>Visa minibilder i flikar</translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="843"/>
        <source>Customize</source>
        <translation>Anpassa</translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="1086"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/TabBarWidget.cpp" line="1087"/>
        <source>You are about to open %n URL(s).</source>
        <translation><numerusform>Du är på väg att öppna %n webbadress.</numerusform><numerusform>Du är på väg att öppna %n webbadresser.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="1088"/>
        <source>Do you want to continue?</source>
        <translation>Vill du fortsätta?</translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="1092"/>
        <source>Do not show this message again</source>
        <translation>Visa inte det här meddelandet igen</translation>
    </message>
</context>
<context>
    <name>Otter::TabHandleWidget</name>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="269"/>
        <source>Close Tab</source>
        <translation>Stäng flik</translation>
    </message>
</context>
<context>
    <name>Otter::TabHistoryContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="156"/>
        <source>Tab History</source>
        <translation>Flikhistorik</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="184"/>
        <source>Title: %1</source>
        <translation>Titel: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="184"/>
        <source>Address: %1</source>
        <translation>Adress: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="188"/>
        <source>Date: %1</source>
        <translation>Datum: %1</translation>
    </message>
</context>
<context>
    <name>Otter::TextLabelWidget</name>
    <message>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="42"/>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="98"/>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="138"/>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="182"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;empty&gt;</translation>
    </message>
    <message>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="70"/>
        <source>Copy</source>
        <translation>Kopiera</translation>
    </message>
    <message>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="76"/>
        <source>Copy Link Location</source>
        <translation>Kopiera länkens adress</translation>
    </message>
    <message>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="81"/>
        <source>Select All</source>
        <translation>Välj allt</translation>
    </message>
</context>
<context>
    <name>Otter::ToolBarDialog</name>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="14"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="64"/>
        <source>Edit Toolbar</source>
        <translation>Redigera verktygsraden</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="22"/>
        <source>Name:</source>
        <translation>Namn:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="45"/>
        <source>Entries</source>
        <translation>Element</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="106"/>
        <source>Edit…</source>
        <translation>Redigera…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="115"/>
        <source>Current entries:</source>
        <translation>Aktuella elementet:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="202"/>
        <source>Available entries:</source>
        <translation>Tillgängliga element:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="209"/>
        <location filename="../../src/ui/ToolBarDialog.ui" line="219"/>
        <source>Filter…</source>
        <translation>Filter…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="256"/>
        <source>Add Bookmark</source>
        <translation>Lägg till bokmärke</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="269"/>
        <source>Bookmarks folder:</source>
        <translation>Mapp för bokmärken:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="291"/>
        <source>New…</source>
        <translation>Ny…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="331"/>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="339"/>
        <source>Visibility:</source>
        <translation>Synlighet:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="352"/>
        <source>Visibility in full screen mode:</source>
        <translation>Synlighet i helskärmsläget:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="365"/>
        <source>Button style:</source>
        <translation>Knappstil:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="378"/>
        <source>Icon size:</source>
        <translation>Storlek på ikon:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="388"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="391"/>
        <location filename="../../src/ui/ToolBarDialog.ui" line="417"/>
        <source> px</source>
        <translation>px</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="404"/>
        <source>Maximum size of item:</source>
        <translation>Max storlek för element:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="414"/>
        <source>No limit</source>
        <translation>Ingen gräns</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="429"/>
        <source>Display toggle button</source>
        <translation>Visa knapp för omkoppling</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="46"/>
        <source>Edit Bookmarks Bar</source>
        <translation>Redigera bokmärkesraden</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="50"/>
        <source>Bookmarks Bar</source>
        <translation>Bokmärkesrad</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="55"/>
        <source>Edit Sidebar</source>
        <translation>Redigera sidorad</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="59"/>
        <source>Sidebar</source>
        <translation>Sidorad</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="68"/>
        <source>Toolbar</source>
        <translation>Verktygsrad</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="78"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="85"/>
        <source>Always visible</source>
        <translation>Alltid synlig</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="79"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="86"/>
        <source>Always hidden</source>
        <translation>Alltid gömd</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="80"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="87"/>
        <source>Visible only when needed</source>
        <translation>Endast synlig vid behov</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="88"/>
        <source>Visible only when cursor is close to screen edge</source>
        <translation>Endast synlig när muspekaren är nära till skärmkanten</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="93"/>
        <source>Follow style</source>
        <translation>Respektera stilen</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="94"/>
        <source>Icon only</source>
        <translation>Enbart ikoner</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="95"/>
        <source>Text only</source>
        <translation>Enbart text</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="96"/>
        <source>Text beside icon</source>
        <translation>Text bredvid ikon</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="97"/>
        <source>Text under icon</source>
        <translation>Text under ikon</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="339"/>
        <source>Edit Entry</source>
        <translation>Redigera element</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="356"/>
        <source>All</source>
        <translation>Alla</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="363"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="629"/>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="373"/>
        <source>Show search engine:</source>
        <translation>Visa sökmotor:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="374"/>
        <source>Show search button:</source>
        <translation>Visa sök-knapp:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="389"/>
        <source>Global</source>
        <translation>Globalt</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="389"/>
        <source>Tab</source>
        <translation>Flik</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="393"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="463"/>
        <source>Text:</source>
        <translation>Text:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="394"/>
        <source>Option:</source>
        <translation>Alternativ:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="395"/>
        <source>Scope:</source>
        <translation>Räckvidd:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="424"/>
        <source>Blocked Elements: {amount}</source>
        <translation>Blockerade element: {antal}</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="429"/>
        <source>Menu</source>
        <translation>Meny</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="434"/>
        <source>Downloads</source>
        <translation>Nedladdningar</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="462"/>
        <source>Icon:</source>
        <translation>Ikon:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="532"/>
        <source>--- separator ---</source>
        <translation>--- separerare ---</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="536"/>
        <source>--- spacer ---</source>
        <translation>--- platshållare ---</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="540"/>
        <source>Arbitrary List of Actions</source>
        <translation>Slumpmässig lista av händelser</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="548"/>
        <source>List of Closed Tabs and Windows</source>
        <translation>Lista av stängda flikar och fönster</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="553"/>
        <source>Address Field</source>
        <translation>Adressfält</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="562"/>
        <source>Configuration Widget (%1)</source>
        <translation>Konfigurations-komponent (%1)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="566"/>
        <source>Configuration Widget</source>
        <translation>Konfigurations-komponent</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="572"/>
        <source>Content Blocking Details</source>
        <translation>Detaljer för innehållsblockering</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="577"/>
        <source>Error Console</source>
        <translation>Felkonsol</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="581"/>
        <source>Menu Bar</source>
        <translation>Menyfält</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="586"/>
        <source>Menu Button</source>
        <translation>Menyknapp</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="590"/>
        <source>Sidebar Panel Chooser</source>
        <translation>Sidoradens panelurval</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="594"/>
        <source>Private Window Indicator</source>
        <translation>Indikator för privata fönster</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="599"/>
        <source>Progress Information (Document Progress)</source>
        <translation>Förloppsinformation (dokumentets förlopp)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="603"/>
        <source>Progress Information (Total Progress)</source>
        <translation>Förloppsinformation (totala förloppet)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="607"/>
        <source>Progress Information (Loaded Elements)</source>
        <translation>Förloppsinformation (hämtade element)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="611"/>
        <source>Progress Information (Loading Speed)</source>
        <translation>Förloppsinformation (laddningshastighet)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="615"/>
        <source>Progress Information (Elapsed Time)</source>
        <translation>Förloppsinformation (förfluten tid)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="619"/>
        <source>Progress Information (Status Message)</source>
        <translation>Förloppsinformation (statusmeddelande)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="629"/>
        <source>Search Field (%1)</source>
        <translation>Sökfält (%1)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="634"/>
        <source>Search Field</source>
        <translation>Sökfält</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="640"/>
        <source>Window Resize Handle</source>
        <translation>Tag för fönsterstorlek</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="644"/>
        <source>Status Message Field</source>
        <translation>Statusmeddelandets fält</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="648"/>
        <source>Tab Bar</source>
        <translation>Flikrad</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="652"/>
        <source>Downloads Progress Information</source>
        <translation>Information om nedladdningsförlopp</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="657"/>
        <source>Zoom Slider</source>
        <translation>Zoomningsregel</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="677"/>
        <source>Invalid Bookmark</source>
        <translation>Ogiltigt bokmärke</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="686"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="703"/>
        <source>Invalid Entry</source>
        <translation>Ogiltigt element</translation>
    </message>
</context>
<context>
    <name>Otter::ToolBarWidget</name>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="133"/>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="849"/>
        <source>Toggle Visibility</source>
        <translation>Koppla om synlighet</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="905"/>
        <source>Customize</source>
        <translation>Anpassa</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="907"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="908"/>
        <source>Configure…</source>
        <translation>Ställ in…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="911"/>
        <source>Reset to Defaults…</source>
        <translation>Återställ till förval…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="928"/>
        <source>Remove…</source>
        <translation>Ta bort…</translation>
    </message>
</context>
<context>
    <name>Otter::ToolBarsManager</name>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="365"/>
        <source>Reset Toolbar</source>
        <translation>Återställ verktygsrad</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="365"/>
        <source>Do you really want to reset this toolbar to default configuration?</source>
        <translation>Vill du verkligen återställa denna verktygsraden till den förvalda konfigurationen?</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="373"/>
        <source>Remove Toolbar</source>
        <translation>Ta bort verktygsrad</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="373"/>
        <source>Do you really want to remove this toolbar?</source>
        <translation>Vill du verkligen ta bort denna verktygsraden?</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="387"/>
        <source>Reset Toolbars</source>
        <translation>Återställ verktygsrader</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="387"/>
        <source>Do you really want to reset all toolbars to default configuration?</source>
        <translation>Vill du verkligen återställa alla verktygsrader till den förvalda konfigurationen?</translation>
    </message>
</context>
<context>
    <name>Otter::ToolButtonWidget</name>
    <message>
        <location filename="../../src/ui/ToolButtonWidget.cpp" line="130"/>
        <source>Menu</source>
        <translation>Meny</translation>
    </message>
</context>
<context>
    <name>Otter::Transfer</name>
    <message>
        <location filename="../../src/core/TransfersManager.cpp" line="670"/>
        <location filename="../../src/core/TransfersManager.cpp" line="703"/>
        <source>file</source>
        <translation>fil</translation>
    </message>
    <message>
        <location filename="../../src/core/TransfersManager.cpp" line="888"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/core/TransfersManager.cpp" line="888"/>
        <source>File with the same name already exists.
Do you want to overwrite it?

%1</source>
        <translation>En fil med det här namn existerar redan.
Vill du skriva över den?

%1</translation>
    </message>
</context>
<context>
    <name>Otter::TransferActionWidget</name>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="234"/>
        <source>From:</source>
        <translation>Från:</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="240"/>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="244"/>
        <source>Size:</source>
        <translation>Storlek:</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="240"/>
        <source>%1 (download completed)</source>
        <translation>%1 (nedladdning slutförd)</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="244"/>
        <source>%1 (%2% downloaded)</source>
        <translation>%1 (%2% hämtat)</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="263"/>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="297"/>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="270"/>
        <source>Redownload</source>
        <translation>Hämta om</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="275"/>
        <source>Open Folder</source>
        <translation>Öppna mapp</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="280"/>
        <source>Stop</source>
        <translation>Stoppa</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="297"/>
        <source>&lt;div style=&quot;white-space:pre;&quot;&gt;Source: %1
Target: %2
Size: %3
Downloaded: %4
Progress: %5&lt;/div&gt;</source>
        <translation>&lt;div style=&quot;white-space:pre;&quot;&gt;Källa: %1
Mål: %2
Storlek: %3
Hämtat: %4
Framgång: %5&lt;/div&gt;</translation>
    </message>
</context>
<context>
    <name>Otter::TransferDialog</name>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="14"/>
        <source>Opening unknown file</source>
        <translation>Öppna okänd fil</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="22"/>
        <source>Name:</source>
        <translation>Namn:</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="29"/>
        <source>Type:</source>
        <translation>Typ:</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="36"/>
        <source>Size:</source>
        <translation>Storlek:</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="43"/>
        <source>From:</source>
        <translation>Från:</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="50"/>
        <source>Open with:</source>
        <translation>Öppna med:</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="104"/>
        <source>Remember choice for this file type</source>
        <translation>Kom ihåg urvalet för denna filtyp</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.cpp" line="45"/>
        <source>unknown file</source>
        <translation>okänd fil</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.cpp" line="65"/>
        <source>Opening %1</source>
        <translation>Öppnar %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.cpp" line="171"/>
        <source>unknown</source>
        <translation>okänd</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.cpp" line="175"/>
        <source>%1 (download completed)</source>
        <translation>%1 (nedladdning slutförd)</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.cpp" line="179"/>
        <source>%1 (%2% downloaded)</source>
        <translation>%1 (%2% hämtat)</translation>
    </message>
</context>
<context>
    <name>Otter::TransfersContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="31"/>
        <source>Quick Download…</source>
        <translation>Snabb nedladdning…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="120"/>
        <source>Source:</source>
        <translation>Källa:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="130"/>
        <source>Target:</source>
        <translation>Mål:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="140"/>
        <source>Size:</source>
        <translation>Storlek:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="150"/>
        <source>Downloaded:</source>
        <translation>Hämtat:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="157"/>
        <source>Progress:</source>
        <translation>Framgång:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="190"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="405"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="452"/>
        <source>Stop</source>
        <translation>Stoppa</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="200"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="408"/>
        <source>Redownload</source>
        <translation>Hämta om</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Filename</source>
        <translation>Filnamn</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Progress</source>
        <translation>Framgång</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Time</source>
        <translation>Tid</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Speed</source>
        <translation>Hastighet</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Started</source>
        <translation>Påbörjade</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Finished</source>
        <translation>Slutfört</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="145"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="145"/>
        <source>This file is still being downloaded.
Do you really want to remove it?</source>
        <translation>Denna filen laddas precis ned.
Vill du verkligen ta bort den?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="277"/>
        <source>&lt;div style=&quot;white-space:pre;&quot;&gt;Source: %1
Target: %2
Size: %3
Downloaded: %4
Progress: %5&lt;/div&gt;</source>
        <translation>&lt;div style=&quot;white-space:pre;&quot;&gt;Källa: %1
Mål: %2
Storlek: %3
Hämtat: %4
Framgång: %5&lt;/div&gt;</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="277"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="467"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="469"/>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="400"/>
        <source>Open Folder</source>
        <translation>Öppna mapp</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="405"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="447"/>
        <source>Resume</source>
        <translation>Återuppta</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="412"/>
        <source>Copy Transfer Information</source>
        <translation>Kopiera information om överföringen</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="416"/>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="433"/>
        <source>Clear Finished Transfers</source>
        <translation>Ta bort slutförda överföringar</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="546"/>
        <source>Downloads</source>
        <translation>Nedladdningar</translation>
    </message>
</context>
<context>
    <name>Otter::TransfersManager</name>
    <message>
        <location filename="../../src/core/TransfersManager.cpp" line="1126"/>
        <source>Download completed:
%1</source>
        <translation>Nedladdat:
%1</translation>
    </message>
</context>
<context>
    <name>Otter::TransfersWidget</name>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="47"/>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="101"/>
        <source>Downloads</source>
        <translation>Nedladdningar</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="123"/>
        <source>Show all Downloads</source>
        <translation>Visa alla nedladdningar</translation>
    </message>
</context>
<context>
    <name>Otter::TrayIcon</name>
    <message>
        <location filename="../../src/ui/TrayIcon.cpp" line="41"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="148"/>
        <source>Show Windows</source>
        <translation>Visa fönster</translation>
    </message>
    <message>
        <location filename="../../src/ui/TrayIcon.cpp" line="79"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="176"/>
        <source>Otter Browser</source>
        <translation>Webbläsaren Otter</translation>
    </message>
    <message>
        <location filename="../../src/ui/TrayIcon.cpp" line="148"/>
        <source>Hide Windows</source>
        <translation>Göm fönster</translation>
    </message>
</context>
<context>
    <name>Otter::UpdateCheckerDialog</name>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.ui" line="14"/>
        <source>Check for Updates</source>
        <translation>Sök efter uppdateringar</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.ui" line="20"/>
        <source>Checking for update…</source>
        <translation>Sök efter uppdateringar…</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="50"/>
        <source>Checking for updates…</source>
        <translation>Söker efter uppdateringar…</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="91"/>
        <source>There are no new updates.</source>
        <translation>Det finns inga nya uppdateringar.</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="97"/>
        <source>Available updates:</source>
        <translation>Tillgängliga uppdateringar:</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="101"/>
        <source>Details…</source>
        <translation>Detaljer…</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="104"/>
        <source>Download</source>
        <translation>Ladda ned</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="117"/>
        <source>Version %1 from %2 channel</source>
        <translation>Version %1 från kanalen %2</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="127"/>
        <source>Some of the updates do not contain packages for your platform. Try to check for updates later or visit details page for more info.</source>
        <translation>Några av uppdateringarna innehåller inte paket för din plattform. Försök att kolla senare för nya uppdateringar eller besök detaljsidan för mera information.</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="151"/>
        <source>Downloading:</source>
        <translation>Hämtar:</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="166"/>
        <source>Download finished!</source>
        <translation>Nedladdningen är slutförd!</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="167"/>
        <source>Install</source>
        <translation>Installera</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="169"/>
        <source>New version of Otter Browser is ready to install.
Click Install button to restart browser and install the update or close this dialog to install the update during next browser restart.</source>
        <translation>En ny version av webbläsaren Otter är redo att installeras.
Klicka på knappen Installera för att starta om webbläsaren och installera uppdateringen eller stäng den här rutan för att installera uppdateringen nästa gång som webbläsaren startas.</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="191"/>
        <source>Download failed!</source>
        <translation>Nedladdningen misslyckades!</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="193"/>
        <source>Check Error Console for more information.</source>
        <translation>Se felkonsolen för mera information.</translation>
    </message>
</context>
<context>
    <name>Otter::UserAgentPropertiesDialog</name>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.ui" line="19"/>
        <source>Title:</source>
        <translation>Titel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.ui" line="29"/>
        <source>Value:</source>
        <translation>Värde:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.ui" line="47"/>
        <source>Preview</source>
        <translation>Förhandsgranska</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="52"/>
        <source>Edit User Agent</source>
        <translation>Redigera användaragent</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="52"/>
        <source>Add User Agent</source>
        <translation>Lägg till användaragent</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="105"/>
        <source>Placeholders</source>
        <translation>Platshållare</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="106"/>
        <source>Platform</source>
        <translation>Plattform</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="107"/>
        <source>Engine Version</source>
        <translation>Motorens version</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="108"/>
        <source>Application Version</source>
        <translation>Applikationens version</translation>
    </message>
</context>
<context>
    <name>Otter::WebContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="993"/>
        <source>Question</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="993"/>
        <source>This tab has crashed.</source>
        <translation>Denna fliken har kraschat.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="993"/>
        <source>Do you want to try to reload it?</source>
        <translation>Vill du hämta om den?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="994"/>
        <source>Do not show this message again</source>
        <translation>Visa inte detta meddelande igen</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="1160"/>
        <source>Failed to load requested web backend: %1</source>
        <translation>Misslyckades med att ladda den begärda webbakänden: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="1242"/>
        <source>Select User Agent</source>
        <translation>Visa användaragent</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="1242"/>
        <source>Enter User Agent:</source>
        <translation>Slå in användaragent:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="1399"/>
        <source>Start Page</source>
        <translation>Startsida</translation>
    </message>
</context>
<context>
    <name>Otter::WebWidget</name>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="267"/>
        <source>Title: %1</source>
        <translation>Titel: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="267"/>
        <source>Address: %1</source>
        <translation>Adress: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="313"/>
        <source>JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="313"/>
        <source>Webpage wants to close this tab, do you want to allow to close it?</source>
        <translation>Webbplatsen vill stänga denna fliken. Vill du tillåta det?</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="314"/>
        <source>Do not show this message again</source>
        <translation>Visa inte detta meddelande igen</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="729"/>
        <source>HTML file (*.html *.htm)</source>
        <translation>HTML fil (*.html *.htm)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="729"/>
        <source>HTML file with all resources (*.html *.htm)</source>
        <translation>HTML fil med alla resurser (*.html *.htm)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="729"/>
        <source>Web archive (*.mht)</source>
        <translation>Webbarkiv (*.mht)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="729"/>
        <source>PDF document (*.pdf)</source>
        <translation>PDF-dokument (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1031"/>
        <source>Open Image in New Background Tab (%1)</source>
        <translation>Öppna bild i ny bakgrundsflik (%1)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1035"/>
        <source>Open Image in New Tab (%1)</source>
        <translation>Öppna bild i ny flik (%1)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1091"/>
        <source>Playback Rate: %1x</source>
        <translation>Uppspelningshastighet: %1x</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1175"/>
        <source>Page Default</source>
        <translation>Sidans förvalda inställningar</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1183"/>
        <source>Never Reload</source>
        <translation>Hämta aldrig om</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/WebWidget.cpp" line="1187"/>
        <source>Reload Every: %n second(s)</source>
        <translation><numerusform>Hämta om varje sekund</numerusform><numerusform>Hämta om var %n. sekund</numerusform></translation>
    </message>
</context>
<context>
    <name>Otter::WebsiteInformationDialog</name>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="57"/>
        <source>General</source>
        <translation>Generell</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="69"/>
        <source>Information</source>
        <translation>Informatio</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="76"/>
        <source>Address:</source>
        <translation>Adress:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="83"/>
        <source>Encoding:</source>
        <translation>Kodning:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="90"/>
        <source>Size:</source>
        <translation>Storlek:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="97"/>
        <source>Elements:</source>
        <translation>Element:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="104"/>
        <source>Download date:</source>
        <translation>Hämtat den:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="126"/>
        <source>Title:</source>
        <translation>Titel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="137"/>
        <source>Permissions</source>
        <translation>Rättigheter</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="149"/>
        <source>Preferences</source>
        <translation>Egenskaper</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="171"/>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="307"/>
        <source>Details…</source>
        <translation>Detaljer…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="180"/>
        <source>Set cookies:</source>
        <translation>Ställ in kakor:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="187"/>
        <source>Set third-party cookies:</source>
        <translation>Ställ in kakor från tredjepart:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="194"/>
        <source>Show notifications:</source>
        <translation>Visa notifieringar:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="201"/>
        <source>Access your location:</source>
        <translation>Åtkomst till din ort:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="208"/>
        <source>Load plugins:</source>
        <translation>Ladda insticksprogram:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="215"/>
        <source>Load images:</source>
        <translation>Hämta bilder:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="222"/>
        <source>Use JavaScript:</source>
        <translation>Använd JavaScript:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="250"/>
        <source>Show pop-up windows:</source>
        <translation>Visa extrafönster:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="260"/>
        <source>Enter full screen mode:</source>
        <translation>Byt till helskärmsläge:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="271"/>
        <source>Security</source>
        <translation>Säkerhet</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="285"/>
        <source>Certificate</source>
        <translation>Certifikat</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="316"/>
        <source>Issued to:</source>
        <translation>Utfärdat till:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="323"/>
        <source>Issued by:</source>
        <translation>Utfärdat av:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="330"/>
        <source>Issued on:</source>
        <translation>Utfärdat den:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="337"/>
        <source>Expires on:</source>
        <translation>Giltigt till:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="350"/>
        <source>Cipher</source>
        <translation>Kodningsförfarande</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="357"/>
        <source>Protocol:</source>
        <translation>Protokoll:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="364"/>
        <source>Authentication method:</source>
        <translation>Autentiseringsmetod:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="371"/>
        <source>Encryption method:</source>
        <translation>Kodningsmetod:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="378"/>
        <source>Key exchange method:</source>
        <translation>Metod för nyckelutbyte:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="417"/>
        <source>SSL Errors</source>
        <translation>SSL-fel</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="43"/>
        <source>(unknown)</source>
        <translation>(okänd)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="48"/>
        <source>This website was marked as fraud.</source>
        <translation>Den här webbplatsen markerades som en bluff.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="53"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="63"/>
        <source>Your connection with this website is not private.</source>
        <translation>Din anslutning med den här webbplatsen är inte privat.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="58"/>
        <source>Your connection with this website is private.</source>
        <translation>Din anslutning till den här webbplatsen är privat.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="68"/>
        <source>You are viewing content from your local filesystem.</source>
        <translation>Du betraktar innehåll av dit lokala filsystem.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="73"/>
        <source>You are viewing safe page from Otter Browser.</source>
        <translation>Du betraktar en säker sida av Otter Browser.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="78"/>
        <source>No information.</source>
        <translation>Ingen information.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="85"/>
        <source>unknown</source>
        <translation>okänd</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="87"/>
        <source>%1 (%n blocked)</source>
        <translation><numerusform>%1 (%n blockerad)</numerusform><numerusform>%1 (%n blockerade)</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="94"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="113"/>
        <source>Only existing</source>
        <translation>Endast existerande</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="98"/>
        <source>Only read existing</source>
        <translation>Läs endast existerande</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="102"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="117"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="132"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="147"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="154"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="164"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="179"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="194"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="213"/>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="106"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="121"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="128"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="151"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="154"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="160"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="175"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="190"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="205"/>
        <source>Always</source>
        <translation>Alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="136"/>
        <source>On demand</source>
        <translation>Vid förfrågning</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="143"/>
        <source>Only cached</source>
        <translation>Endast cachade</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="168"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="183"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="198"/>
        <source>Always ask</source>
        <translation>Fråga alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="209"/>
        <source>Always (open in backgound)</source>
        <translation>Alltid (öppna i bakgrunden)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="217"/>
        <source>Ask</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="246"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="291"/>
        <source>Error Message</source>
        <translation>Felmeddelande</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="246"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="291"/>
        <source>URL</source>
        <translation>Webbadress</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="262"/>
        <source>Information for %1</source>
        <translation>Information för %1</translation>
    </message>
</context>
<context>
    <name>Otter::WebsitePreferencesDialog</name>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="14"/>
        <source>Website Preferences</source>
        <translation>Egenskaper för webbplats</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="25"/>
        <source>Website:</source>
        <translation>Webbplats:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="44"/>
        <source>Content</source>
        <translation>Innehåll</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="56"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="262"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="646"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="794"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="858"/>
        <source>Override</source>
        <translation>Skriv över</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="73"/>
        <source>Plugins:</source>
        <translation>Insticksprogram:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="90"/>
        <source>Encoding:</source>
        <translation>Kodning:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="110"/>
        <source>User style sheet:</source>
        <translation>Användars-stilmall:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="153"/>
        <source>Images:</source>
        <translation>Bilder:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="170"/>
        <source>Pop-ups:</source>
        <translation>Extrafönster:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="181"/>
        <source>Privacy</source>
        <translation>Integritet</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="205"/>
        <source>Keep until:</source>
        <translation>Behåll tills:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="248"/>
        <source>Remember browsing history</source>
        <translation>Kom ihåg surfningshistoriken</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="269"/>
        <source>Enable cookies</source>
        <translation>Aktivera kakor</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="294"/>
        <source>Accept cookies:</source>
        <translation>Ta emot kakor:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="303"/>
        <source>Do Not Track:</source>
        <translation>Spåra inte:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="323"/>
        <source>Cookies:</source>
        <translation>Kakor:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="350"/>
        <source>Add…</source>
        <translation>Lägg till…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="360"/>
        <source>Properties…</source>
        <translation>Egenskaper…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="370"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="412"/>
        <source>Accept third-party cookies:</source>
        <translation>Ta emot kakor från tredjepart:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="448"/>
        <source>Scripting</source>
        <translation>Skripter</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="486"/>
        <source>Allow to receive right mouse button clicks</source>
        <translation>Tillåt att ta emot högra musknappens klickar</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="520"/>
        <source>Allow changing of status field</source>
        <translation>Tillåt ändring av statusraden</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="567"/>
        <source>Allow to close windows:</source>
        <translation>Tillåt att stänga fönster:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="600"/>
        <source>Allow script to hide address bar</source>
        <translation>Tillåt skriptet att gömma adressraden</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="627"/>
        <source>Allow moving and resizing of windows</source>
        <translation>Tillåt flyttning och storleksförändring av fönster</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="660"/>
        <source>Enable JavaScript</source>
        <translation>Aktivera JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="698"/>
        <source>Allow access to clipboard</source>
        <translation>Tillåt åtkomst till klippbordet</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="745"/>
        <source>Allow to enter full screen mode:</source>
        <translation>Tillåt at byta till helskärmsläge:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="758"/>
        <source>Network</source>
        <translation>Nätverk</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="787"/>
        <source>Send referrer information</source>
        <translation>Sänd referensinformation</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="801"/>
        <source>Proxy:</source>
        <translation>Proxy:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="811"/>
        <source>User Agent:</source>
        <translation>Användaragent:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="852"/>
        <source>Content Blocking</source>
        <translation>Blockering av innehåll</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="865"/>
        <source>Profiles:</source>
        <translation>Profiler:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="895"/>
        <source>Enable custom rules</source>
        <translation>Aktivera anpassade regler</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="66"/>
        <source>Auto Detect</source>
        <translation>Upptäck automatiskt</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="82"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="95"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="99"/>
        <source>Ask</source>
        <translation>Fråga</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="83"/>
        <source>Block all</source>
        <translation>Blockera alla</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="84"/>
        <source>Open all</source>
        <translation>Öppna alla</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="85"/>
        <source>Open all in background</source>
        <translation>Öppna alla i bakgrunden</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="87"/>
        <source>All images</source>
        <translation>Alla bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="88"/>
        <source>Cached images</source>
        <translation>Cachade bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="89"/>
        <source>No images</source>
        <translation>Inga bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="91"/>
        <source>Enabled</source>
        <translation>Aktiverad</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="92"/>
        <source>On demand</source>
        <translation>Vid begäran</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="93"/>
        <source>Disabled</source>
        <translation>Inaktiverad</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="96"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="100"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="107"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="115"/>
        <source>Always</source>
        <translation>Alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="97"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="101"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="117"/>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="103"/>
        <source>Inform websites that I do not want to be tracked</source>
        <translation>Informera hemsidor att jag inte vill bli spårad</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="104"/>
        <source>Inform websites that I allow tracking</source>
        <translation>Informera hemsidor att jag vill tillåta spårning</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="105"/>
        <source>Do not inform websites about my preference</source>
        <translation>Informera hemsidor inte om vad jag föredrar</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="108"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="116"/>
        <source>Only existing</source>
        <translation>Endast existerande</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="109"/>
        <source>Only read existing</source>
        <translation>Läs endast existerande</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="111"/>
        <source>Expires</source>
        <translation>Slutar gälla</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="112"/>
        <source>Current session is closed</source>
        <translation>Den aktuella sessionen är stängd</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="113"/>
        <source>Always ask</source>
        <translation>Fråga alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="120"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="200"/>
        <source>Domain</source>
        <translation>Domän</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="120"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="200"/>
        <source>Name</source>
        <translation>Namn</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="120"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="200"/>
        <source>Path</source>
        <translation>Sökväg</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="120"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="200"/>
        <source>Value</source>
        <translation>Värde</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="120"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="200"/>
        <source>Expiration Date</source>
        <translation>Utgångsdatum:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="206"/>
        <source>this session only</source>
        <translation>enbart denna sessionen</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="453"/>
        <source>Style sheets (*.css)</source>
        <translation>Stilmallar (*.css)</translation>
    </message>
</context>
<context>
    <name>Otter::WindowsContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/windows/WindowsContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Sök…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/windows/WindowsContentsWidget.cpp" line="267"/>
        <source>Windows and Tabs</source>
        <translation>Fönster och flikar</translation>
    </message>
</context>
<context>
    <name>Otter::WindowsPlatformIntegration</name>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="73"/>
        <source>New tab</source>
        <translation>Ny flik</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="74"/>
        <source>New private tab</source>
        <translation>Ny privat flik</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="75"/>
        <source>New window</source>
        <translation>Nytt fönster</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="76"/>
        <source>New private window</source>
        <translation>Nytt privat fönster</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="177"/>
        <source>Failed to run command &quot;%1&quot;, file is not executable</source>
        <translation>Misslyckades med att köra kommandot &quot;%1&quot;, filen är inte exekverbar</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="204"/>
        <source>Failed to run command &quot;%1&quot; (arguments: &quot;%2&quot;)</source>
        <translation>Misslyckades med att köra kommandot &quot;%1&quot; (argument: &quot;%2&quot;)</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="291"/>
        <source>No valid suffix for given MIME type: %1</source>
        <translation>Ingen giltig ändelse för den givna MIME-typen: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="358"/>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="408"/>
        <source>Failed to load a valid application path for MIME type %1: %2</source>
        <translation>Misslyckades med att ladda en giltig applikations-sökväg för MIME-typen %1: %2</translation>
    </message>
</context>
<context>
    <name>Otter::WorkspaceWidget</name>
    <message>
        <location filename="../../src/ui/WorkspaceWidget.cpp" line="550"/>
        <location filename="../../src/ui/WorkspaceWidget.cpp" line="645"/>
        <source>Arrange</source>
        <translation>Anordna</translation>
    </message>
</context>
<context>
    <name>Otter::ZoomWidget</name>
    <message>
        <location filename="../../src/modules/widgets/zoom/ZoomWidget.cpp" line="132"/>
        <location filename="../../src/modules/widgets/zoom/ZoomWidget.cpp" line="133"/>
        <source>Zoom %1%</source>
        <translation>Zooma %1%</translation>
    </message>
</context>
<context>
    <name>actions</name>
    <message>
        <source>Reload Every</source>
        <translation>Hämta om alla</translation>
    </message>
    <message>
        <source>1 Minute</source>
        <translation>1 minut</translation>
    </message>
    <message>
        <source>30 Minutes</source>
        <translation>30 minuter</translation>
    </message>
    <message>
        <source>1 Hour</source>
        <translation>1 timme</translation>
    </message>
    <message>
        <source>2 Hours</source>
        <translation>2 timmar</translation>
    </message>
    <message>
        <source>6 Hours</source>
        <translation>6 timmar</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Aldrig</translation>
    </message>
    <message>
        <source>Custom…</source>
        <translation>Anpassad…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="286"/>
        <source>Run Macro</source>
        <translation>Kör makro</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="286"/>
        <source>Run Arbitrary List of Actions</source>
        <translation>Kör slumpmässig lista av aktioner</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="287"/>
        <source>Set Option</source>
        <translation>Ställ in alternativ</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="287"/>
        <source>Set, Reset or Toggle Option</source>
        <translation>Ställ in, återställ eller byt alternativ</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="288"/>
        <source>New Tab</source>
        <translation>Ny flik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="289"/>
        <source>New Private Tab</source>
        <translation>Ny privat flik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="290"/>
        <source>New Window</source>
        <translation>Nytt fönster</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="291"/>
        <source>New Private Window</source>
        <translation>Nytt privat fönster</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="292"/>
        <source>Open…</source>
        <translation>Öppna…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="293"/>
        <source>Save…</source>
        <translation>Spara…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="294"/>
        <source>Clone Tab</source>
        <translation>Klona fliken</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="295"/>
        <source>Peek Tab</source>
        <translation>Kolla flik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="296"/>
        <location filename="../../src/ui/Window.cpp" line="656"/>
        <source>Pin Tab</source>
        <translation>Fäst fast fliken</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="297"/>
        <source>Detach Tab</source>
        <translation>Koppla av flik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="298"/>
        <source>Maximize</source>
        <translation>Maximera</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="298"/>
        <source>Maximize Tab</source>
        <translation>Maximera flik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="299"/>
        <source>Minimize</source>
        <translation>Minimera</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="299"/>
        <source>Minimize Tab</source>
        <translation>Minimera flik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="300"/>
        <source>Restore</source>
        <translation>Återställ</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="300"/>
        <source>Restore Tab</source>
        <translation>Återställ flik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="301"/>
        <source>Stay on Top</source>
        <translation>Stanna längst upp</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="302"/>
        <source>Clear Tab History</source>
        <translation>Töm flikhistorik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="302"/>
        <source>Remove Local Tab History</source>
        <translation>Ta bort lokal flikhistorik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="303"/>
        <location filename="../../src/modules/widgets/action/ActionWidget.cpp" line="267"/>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="150"/>
        <location filename="../../src/ui/WebWidget.cpp" line="918"/>
        <source>Purge Tab History</source>
        <translation>Rensa flikhistorik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="303"/>
        <source>Remove Local and Global Tab History</source>
        <translation>Ta bort lokal och global flikhistorik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="304"/>
        <location filename="../../src/ui/WebWidget.cpp" line="1103"/>
        <source>Mute Tab Media</source>
        <translation>Stum flik media</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="305"/>
        <source>Suspend Tab</source>
        <translation>Låt flik vila</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="306"/>
        <source>Close Tab</source>
        <translation>Stäng flik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="307"/>
        <source>Close Other Tabs</source>
        <translation>Stäng andra flikar</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="308"/>
        <source>Close All Private Tabs</source>
        <translation>Stäng alla privata flikar</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="308"/>
        <source>Close All Private Tabs in Current Window</source>
        <translation>Stäng alla privata flikar i detta fönstret</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="309"/>
        <source>Close Private Tabs and Windows</source>
        <translation>Stäng alla privata flikar och fönster</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="310"/>
        <source>Reopen Previously Closed Tab</source>
        <translation>Öppna nyligen stängd flik igen</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="311"/>
        <source>Maximize All</source>
        <translation>Maximera allt</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="312"/>
        <source>Minimize All</source>
        <translation>Minimera allt</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="313"/>
        <source>Restore All</source>
        <translation>Återställ allt</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="314"/>
        <source>Cascade</source>
        <translation>Kaskad</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="315"/>
        <source>Tile</source>
        <translation>Kakel</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="316"/>
        <source>Close Window</source>
        <translation>Stäng ner fönstret</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="317"/>
        <source>Reopen Previously Closed Window</source>
        <translation>Öppna nyligen stängd flik igen</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="318"/>
        <source>Manage Sessions…</source>
        <translation>Hantera sessioner…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="319"/>
        <source>Save Current Session…</source>
        <translation>Spara aktuella sessionen…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="320"/>
        <source>Open URL</source>
        <translation>Öppna webbadress</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="321"/>
        <location filename="../../src/core/ActionsManager.cpp" line="336"/>
        <location filename="../../src/core/ActionsManager.cpp" line="337"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="177"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="350"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="404"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="370"/>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="222"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="389"/>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="843"/>
        <location filename="../../src/ui/Menu.cpp" line="326"/>
        <location filename="../../src/ui/WebWidget.cpp" line="797"/>
        <source>Open</source>
        <translation>Öppna</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="322"/>
        <location filename="../../src/ui/WebWidget.cpp" line="754"/>
        <source>Open in This Tab</source>
        <translation>Öppna i den här fliken</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="323"/>
        <location filename="../../src/core/ActionsManager.cpp" line="338"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="179"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="352"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="372"/>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="224"/>
        <location filename="../../src/ui/Menu.cpp" line="327"/>
        <location filename="../../src/ui/WebWidget.cpp" line="759"/>
        <source>Open in New Tab</source>
        <translation>Öppna i ny flik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="324"/>
        <location filename="../../src/core/ActionsManager.cpp" line="339"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="182"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="355"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="375"/>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="227"/>
        <location filename="../../src/ui/Menu.cpp" line="328"/>
        <location filename="../../src/ui/WebWidget.cpp" line="764"/>
        <source>Open in New Background Tab</source>
        <translation>Öppna i ny bakgrundsflik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="325"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="187"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="360"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="380"/>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="232"/>
        <location filename="../../src/ui/Menu.cpp" line="330"/>
        <location filename="../../src/ui/WebWidget.cpp" line="769"/>
        <source>Open in New Window</source>
        <translation>Öppna i nytt fönster</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="326"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="190"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="363"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="383"/>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="235"/>
        <location filename="../../src/ui/Menu.cpp" line="331"/>
        <location filename="../../src/ui/WebWidget.cpp" line="774"/>
        <source>Open in New Background Window</source>
        <translation>Öppna i nytt bakgrundfönster</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="327"/>
        <location filename="../../src/ui/WebWidget.cpp" line="779"/>
        <source>Open in New Private Tab</source>
        <translation>Öppna i ny privat flik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="328"/>
        <location filename="../../src/ui/WebWidget.cpp" line="784"/>
        <source>Open in New Private Background Tab</source>
        <translation>Öppna i ny privat bakgrundsflik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="329"/>
        <location filename="../../src/ui/WebWidget.cpp" line="789"/>
        <source>Open in New Private Window</source>
        <translation>Öppna i nytt privat fönster</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="330"/>
        <location filename="../../src/ui/WebWidget.cpp" line="794"/>
        <source>Open in New Private Background Window</source>
        <translation>Öppna i nytt privat bakgrundsfönster</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="331"/>
        <source>Copy Link to Clipboard</source>
        <translation>Kopiera länken till klippbordet</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="332"/>
        <location filename="../../src/ui/WebWidget.cpp" line="955"/>
        <source>Bookmark Link…</source>
        <translation>Bokmärkeslänk…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="333"/>
        <source>Save Link Target As…</source>
        <translation>Spara länkmålet som…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="334"/>
        <source>Save to Downloads</source>
        <translation>Spara ner till Nedladdningar</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="335"/>
        <source>Go to This Address</source>
        <translation>Gå till den här adressen</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="336"/>
        <source>Open Frame</source>
        <translation>Öppna ram</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="337"/>
        <source>Open Frame in This Tab</source>
        <translation>Öppna ramen i den här fliken</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="338"/>
        <source>Open Frame in New Tab</source>
        <translation>Öppna ramen i ny flik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="339"/>
        <source>Open Frame in New Background Tab</source>
        <translation>Öppna ram i ny bakgrundsflik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="340"/>
        <source>Copy Frame Link to Clipboard</source>
        <translation>Kopiera ramens länk till klippbordet</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="341"/>
        <location filename="../../src/core/ActionsManager.cpp" line="372"/>
        <location filename="../../src/core/ActionsManager.cpp" line="373"/>
        <source>Reload</source>
        <translation>Hämta om</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="341"/>
        <source>Reload Frame</source>
        <translation>Hämta om ram</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="342"/>
        <source>View Frame Source</source>
        <translation>Visa ramens källa</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="343"/>
        <source>Open Image</source>
        <translation>Öppna bild</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="344"/>
        <source>Open Image In New Tab</source>
        <translation>Öppna bild i ny flik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="345"/>
        <location filename="../../src/ui/WebWidget.cpp" line="995"/>
        <source>Open Image in New Background Tab</source>
        <translation>Öppna bild i ny bakgrundsflik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="346"/>
        <source>Save Image…</source>
        <translation>Spara bild…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="347"/>
        <source>Copy Image to Clipboard</source>
        <translation>Kopiera bild till klippbordet</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="348"/>
        <source>Copy Image Link to Clipboard</source>
        <translation>Kopiera länken till klippbordet</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="349"/>
        <source>Reload Image</source>
        <translation>Hämta om bild</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="350"/>
        <source>Image Properties…</source>
        <translation>Bildegenskaper…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="351"/>
        <source>Save Media…</source>
        <translation>Spara media…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="352"/>
        <source>Copy Media Link to Clipboard</source>
        <translation>Kopiera media-länk till klippbordet</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="353"/>
        <source>Show Controls</source>
        <translation>Visa kontroller</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="353"/>
        <source>Show Media Controls</source>
        <translation>Visa mediakontroller</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="354"/>
        <source>Looping</source>
        <translation>Ögla</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="354"/>
        <source>Playback Looping</source>
        <translation>Uppspelningsslinga</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="355"/>
        <location filename="../../src/ui/WebWidget.cpp" line="1076"/>
        <source>Play</source>
        <translation>Spela upp</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="355"/>
        <source>Play Media</source>
        <translation>Spela upp media</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="356"/>
        <location filename="../../src/ui/WebWidget.cpp" line="1082"/>
        <source>Mute</source>
        <translation>Stäng av ljudet</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="356"/>
        <source>Mute Media</source>
        <translation>Tyst media</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="357"/>
        <source>Playback Rate</source>
        <translation>Uppspelningshastighet</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="358"/>
        <source>Log In</source>
        <translation>Logga in</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="359"/>
        <source>Go</source>
        <translation>Kör</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="359"/>
        <source>Go to URL</source>
        <translation>Gå till webbadress</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="360"/>
        <source>Back</source>
        <translation>Bakåt</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="360"/>
        <source>Go Back</source>
        <translation>Gå bakåt</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="361"/>
        <source>Forward</source>
        <translation>Framåt</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="361"/>
        <source>Go Forward</source>
        <translation>Gå framåt</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="362"/>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="142"/>
        <source>Go to History Entry</source>
        <translation>Gå till historikelement</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="363"/>
        <source>Go to Page or Search</source>
        <translation>Gå till sidan eller Sök</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="364"/>
        <source>Go to Home Page</source>
        <translation>Gå till hemsidan</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="365"/>
        <source>Go to Parent Directory</source>
        <translation>Gå upp en nivå</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="366"/>
        <source>Rewind</source>
        <translation>Spola bakåt</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="366"/>
        <source>Rewind History</source>
        <translation>Hoppa tillbaka i historiken</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="367"/>
        <source>Fast Forward</source>
        <translation>Spola framåt</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="368"/>
        <source>Remove History Entry</source>
        <translation>Ta bort historikelement</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="369"/>
        <source>Stop</source>
        <translation>Stoppa</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="370"/>
        <source>Stop Scheduled Page Reload</source>
        <translation>Stoppa köad omhämting av sidan</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="371"/>
        <source>Stop All Pages</source>
        <translation>Stoppa alla sidor</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="373"/>
        <source>Reload or Stop</source>
        <translation>Hämta om eller stopp</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="374"/>
        <source>Reload and Bypass Cache</source>
        <translation>Hämta om och ignorera cachen</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="375"/>
        <source>Reload All Tabs</source>
        <translation>Hämta om alla flikar</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="376"/>
        <source>Schedule Page Reload</source>
        <translation>Planera omhämtning av sidan</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="377"/>
        <source>Show Context Menu</source>
        <translation>Visa snabbmeny</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="378"/>
        <source>Undo</source>
        <translation>Ångra</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="379"/>
        <source>Redo</source>
        <translation>Gör om</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="380"/>
        <source>Cut</source>
        <translation>Klipp</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="381"/>
        <source>Copy</source>
        <translation>Kopiera</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="382"/>
        <source>Copy as Plain Text</source>
        <translation>Kopiera som text</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="383"/>
        <source>Copy Address</source>
        <translation>Kopiera adress</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="384"/>
        <source>Copy to Note</source>
        <translation>Kopiera till anteckningar</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="385"/>
        <source>Paste</source>
        <translation>Klistra in</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="386"/>
        <source>Paste and Go</source>
        <translation>Klistra in och kör</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="387"/>
        <source>Delete</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="388"/>
        <source>Select All</source>
        <translation>Välj allt</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="389"/>
        <source>Deselect</source>
        <translation>Upphäv</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="390"/>
        <source>Clear All</source>
        <translation>Ta bort allt</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="391"/>
        <source>Check Spelling</source>
        <translation>Kontrollera rättstavning</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="392"/>
        <source>Find…</source>
        <translation>Hitta…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="393"/>
        <source>Find Next</source>
        <translation>Hitta sedan</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="394"/>
        <source>Find Previous</source>
        <translation>Hitta före</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="395"/>
        <source>Quick Find</source>
        <translation>Snabbsök</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="396"/>
        <location filename="../../src/ui/WebWidget.cpp" line="1266"/>
        <source>Search</source>
        <translation>Sök</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="397"/>
        <source>Create Search…</source>
        <translation>Skapa sökning…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="398"/>
        <source>Zoom In</source>
        <translation>Zooma in</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="399"/>
        <source>Zoom Out</source>
        <translation>Zooma ut</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="400"/>
        <source>Zoom Original</source>
        <translation>Originalstorlek</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="401"/>
        <source>Go to Start of the Page</source>
        <translation>Gå till början av sidan</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="402"/>
        <source>Go to the End of the Page</source>
        <translation>Gå till slutet av sidan</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="403"/>
        <source>Page Up</source>
        <translation>Sida upp</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="404"/>
        <source>Page Down</source>
        <translation>Sida ned</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="405"/>
        <source>Page Left</source>
        <translation>Sida vänster</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="406"/>
        <source>Page Right</source>
        <translation>Sida höger</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="407"/>
        <source>Enter Drag Scroll Mode</source>
        <translation>Aktivera rullning med vänster musknapp</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="408"/>
        <source>Enter Move Scroll Mode</source>
        <translation>Aktivera rullning med mellersta musknappen</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="409"/>
        <source>Exit Scroll Mode</source>
        <translation>Lämna rullningsläget</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="410"/>
        <source>Print…</source>
        <translation>Skriv ut…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="411"/>
        <source>Print Preview</source>
        <translation>Förhandsgranskning för utskrift</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="412"/>
        <source>Take Screenshot</source>
        <translation>Ta skärmbild</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="413"/>
        <source>Activate Address Field</source>
        <translation>Aktivera adressfältet</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="414"/>
        <source>Activate Search Field</source>
        <translation>Aktivera sökfältet</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="415"/>
        <source>Activate Content</source>
        <translation>Aktivera innehåll</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="416"/>
        <source>Go to Previously Used Tab</source>
        <translation>Gå till den senast använda fliken</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="417"/>
        <source>Go to Least Recently Used Tab</source>
        <translation>Gå till den minst nyss använda fliken</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="418"/>
        <source>Activate Tab</source>
        <translation>Aktivera flik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="419"/>
        <source>Go to Tab on Left</source>
        <translation>Gå till fliken till vänster</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="420"/>
        <source>Go to Tab on Right</source>
        <translation>Gå till fliken till höger</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="421"/>
        <source>Activate Window</source>
        <translation>Aktivera fönster</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="422"/>
        <source>Manage Bookmarks</source>
        <translation>Hantera bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="423"/>
        <source>Bookmark Page…</source>
        <translation>Bokmärk sidan…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="424"/>
        <source>Bookmark All Open Pages</source>
        <translation>Bokmärk alla öppna sidor</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="425"/>
        <source>Open Bookmark</source>
        <translation>Öppna bokmärke</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="426"/>
        <source>Quick Bookmark Access</source>
        <translation>Snabb bokmärkestillgång</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="427"/>
        <source>Cookies</source>
        <translation>Kakor</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="428"/>
        <source>Load All Plugins on the Page</source>
        <translation>Ladda alla insticksprogram på sidan</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="429"/>
        <source>Enable JavaScript</source>
        <translation>Aktivera JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="430"/>
        <source>Enable Referrer</source>
        <translation>Aktivera referensinformationer</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="431"/>
        <source>View Source</source>
        <translation>Visa källa</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="432"/>
        <source>Inspect Page</source>
        <translation>Inspektera sida</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="433"/>
        <source>Inspect Element…</source>
        <translation>Granska element…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="434"/>
        <source>Work Offline</source>
        <translation>Arbeta utan att vara uppkopplad</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="435"/>
        <location filename="../../src/ui/Menu.cpp" line="416"/>
        <source>Full Screen</source>
        <translation>Fullskärm</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="436"/>
        <source>Show Tab Switcher</source>
        <translation>Visa flikbytare</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="437"/>
        <source>Show Toolbar</source>
        <translation>Visa verktygsrad</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="438"/>
        <source>Show Menubar</source>
        <translation>Visa menyrad</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="439"/>
        <source>Show Tabbar</source>
        <translation>Visa flikrad</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="440"/>
        <source>Show Sidebar</source>
        <translation>Visa sidorad</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="441"/>
        <source>Show Error Console</source>
        <translation>Visa felkonsol</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="442"/>
        <source>Lock Toolbars</source>
        <translation>Lås verktygsrader</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="443"/>
        <source>Reset to Defaults…</source>
        <translation>Återställ till förval…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="443"/>
        <source>Reset Toolbars to Defaults…</source>
        <translation>Återställ verktygsrader till förval…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="444"/>
        <source>Show Panel</source>
        <translation>Visa panel</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="444"/>
        <source>Show Specified Panel in Sidebar</source>
        <translation>Visa utsökt panel i sidoraden</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="445"/>
        <source>Open Panel as Tab</source>
        <translation>Öppna panel som flik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="445"/>
        <source>Open Curent Sidebar Panel as Tab</source>
        <translation>Öppna nuvarande panelen som sida</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="446"/>
        <source>Content Blocking…</source>
        <translation>Innehållsblockering…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="447"/>
        <source>View History</source>
        <translation>Visa historik</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="448"/>
        <source>Clear History…</source>
        <translation>Töm historik…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="449"/>
        <source>Addons</source>
        <translation>Tillägg</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="450"/>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="210"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="66"/>
        <source>Notes</source>
        <translation>Anteckningar</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="451"/>
        <source>Passwords</source>
        <translation>Lösenord</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="452"/>
        <source>Downloads</source>
        <translation>Nedladdningar</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="453"/>
        <source>Preferences…</source>
        <translation>Egenskaper…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="454"/>
        <source>Website Preferences…</source>
        <translation>Egenskaper för webbplats…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="455"/>
        <source>Quick Preferences</source>
        <translation>Snabbinställningar</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="456"/>
        <source>Reset Options</source>
        <translation>Återställ alternativ</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="457"/>
        <source>Website Information…</source>
        <translation>Information om webbplatsen…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="458"/>
        <source>Website Certificate Information…</source>
        <translation>Information om webbplatsens certifikat…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="459"/>
        <source>Switch Application Language…</source>
        <translation>Byt applikationens språk…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="460"/>
        <source>Check for Updates…</source>
        <translation>Sök efter uppdateringar…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="461"/>
        <source>Diagnostic Report…</source>
        <translation>Diagnostisk rapport…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="462"/>
        <source>About Otter…</source>
        <translation>Om Otter…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="463"/>
        <source>About Qt…</source>
        <translation>Om Qt…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="464"/>
        <source>Exit</source>
        <translation>Avsluta</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1532"/>
        <source>Set %1</source>
        <translation>Ställ in %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1536"/>
        <source>Set %1 for %2</source>
        <translation>Ställ in %1 för %2</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1543"/>
        <source>Reset %1</source>
        <translation>Återställ %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1547"/>
        <source>Reset %1 for %2</source>
        <translation>Återställ %1 för %2</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1556"/>
        <source>Toggle %1</source>
        <translation>Byt %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1560"/>
        <source>Toggle %1 for %2</source>
        <translation>Byt %1 för %2</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="46"/>
        <source>Menu Bar</source>
        <translation>Menyrad</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="47"/>
        <source>Bookmarks Bar</source>
        <translation>Bokmärkesrad</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="48"/>
        <source>Tab Bar</source>
        <translation>Flikrad</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="49"/>
        <source>Address Bar</source>
        <translation>Adressrad</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="50"/>
        <source>Navigation Bar</source>
        <translation>Navigeringsrad</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="51"/>
        <source>Progress Bar</source>
        <translation>Förloppsindikator</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="52"/>
        <source>Sidebar</source>
        <translation>Sidorad</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="53"/>
        <source>Status Bar</source>
        <translation>Statusrad</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="54"/>
        <source>Error Console</source>
        <translation>Felkonsol</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="198"/>
        <location filename="../../src/ui/Menu.cpp" line="73"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="54"/>
        <source>Bookmarks</source>
        <translation>Bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="202"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="58"/>
        <source>Transfers</source>
        <translation>Överföringar</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="206"/>
        <location filename="../../src/ui/Menu.cpp" line="60"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="62"/>
        <source>History</source>
        <translation>Historik</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="366"/>
        <source>Remove Bookmark</source>
        <translation>Ta bort bokmärket</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="479"/>
        <source>Remove Cookie</source>
        <translation>Ta bort kaka</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="400"/>
        <source>Update</source>
        <translation>Uppdatera</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="365"/>
        <source>Copy address of source page</source>
        <translation>Kopiera källsidans adress</translation>
    </message>
    <message>
        <location filename="../../src/ui/MainWindow.cpp" line="2338"/>
        <source>Close Panel</source>
        <translation>Stäng ner panel</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="57"/>
        <source>File</source>
        <translation>Fil</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="58"/>
        <source>Edit</source>
        <translation>Redigera</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="59"/>
        <source>View</source>
        <translation>Visa</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="61"/>
        <source>Tools</source>
        <translation>Verktyg</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="62"/>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="63"/>
        <source>Page</source>
        <translation>Sida</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="64"/>
        <source>Print</source>
        <translation>Skriv ut</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="65"/>
        <source>Settings</source>
        <translation>Inställningar</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="66"/>
        <source>Frame</source>
        <translation>Ram</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="95"/>
        <source>Character Encoding</source>
        <translation>Teckenkondning</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="105"/>
        <source>Closed Tabs and Windows</source>
        <translation>Stängda flikar och fönster</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="123"/>
        <source>Dictionaries</source>
        <translation>Ordböcker</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="129"/>
        <source>Import and Export</source>
        <translation>Importera och Exportera</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="130"/>
        <source>Import Opera Bookmarks…</source>
        <translation>Importera bokmärken för Opera…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="131"/>
        <source>Import HTML Bookmarks…</source>
        <translation>Importera HTML-bokmärken…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="133"/>
        <source>Import OPML Feeds…</source>
        <translation>Importera OPML-flöden…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="135"/>
        <source>Import Opera Notes…</source>
        <translation>Importera anteckningar för Opera…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="137"/>
        <source>Import Opera Search Engines…</source>
        <translation>Importera sökmotorer för Opera…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="139"/>
        <source>Import Opera Session…</source>
        <translation>Importera session för Opera…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="152"/>
        <source>Insert Note</source>
        <translation>Klistra in anteckning</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="166"/>
        <source>Open with</source>
        <translation>Öppna med</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="172"/>
        <source>Proxy</source>
        <translation>Proxy</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="181"/>
        <source>Search Using</source>
        <translation>Sök med</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="187"/>
        <source>Sessions</source>
        <translation>Sessioner</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="200"/>
        <source>Style</source>
        <translation>Stil</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="220"/>
        <source>Toolbars</source>
        <translation>Verktygsrader</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="226"/>
        <source>User Agent</source>
        <translation>Användaragent</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="235"/>
        <source>Validate Using</source>
        <translation>Bekräfta med</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="241"/>
        <source>Tabs and Windows</source>
        <translation>Flika och Fönster</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="404"/>
        <source>Keep Cookie Until</source>
        <translation>Behåll kaka tills</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="408"/>
        <source>Accept Cookies</source>
        <translation>Ta emot kakor</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="412"/>
        <source>Accept Third-party Cookies</source>
        <translation>Ta emot kakor från tredjepart</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="420"/>
        <source>Geolocation</source>
        <translation>Geografisk platsinformation</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="424"/>
        <source>Images</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="428"/>
        <source>Capture Audio</source>
        <translation>Teckna upp ljud</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="432"/>
        <source>Capture Video</source>
        <translation>Teckna upp video</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="436"/>
        <source>Playback Audio</source>
        <translation>Spela upp ljud</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="440"/>
        <source>Notifications</source>
        <translation>Aviseringar</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="444"/>
        <source>Plugins</source>
        <translation>Insticksprogram</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="448"/>
        <source>Pointer Lock</source>
        <translation>Spärr för muspekare</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="452"/>
        <source>Closing Windows by JavaScript</source>
        <translation>Stäng fönster genom JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="456"/>
        <source>Pop-Ups</source>
        <translation>Extrafönster</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="624"/>
        <location filename="../../src/ui/Menu.cpp" line="791"/>
        <source>Open All</source>
        <translation>Öppna alla</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="677"/>
        <source>This Folder</source>
        <translation>Denna mappen</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="755"/>
        <source>Ask What to Do</source>
        <translation>Fråga vad som ska göras</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="759"/>
        <source>Always Allow</source>
        <translation>Tillåt alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="763"/>
        <source>Always Deny</source>
        <translation>Neka alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="767"/>
        <source>Expires</source>
        <translation>Upphör att gälla</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="771"/>
        <source>Current Session is Closed</source>
        <translation>Aktuella sessionen är stängd</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="775"/>
        <source>Always</source>
        <translation>Alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="779"/>
        <source>Only Existing</source>
        <translation>Endast existerande</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="783"/>
        <source>Only Read Existing</source>
        <translation>Läs endast existerande</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="787"/>
        <source>Ignore</source>
        <translation>Ignorera</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="795"/>
        <source>Open in Background</source>
        <translation>Öppna alla i bakgrunden</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="799"/>
        <source>Block All</source>
        <translation>Blockera alla</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="803"/>
        <source>Only Cached</source>
        <translation>Endast cachade</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="807"/>
        <source>Enabled</source>
        <translation>Aktiverad</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="811"/>
        <source>On Demand</source>
        <translation>Vid begäran</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="815"/>
        <source>Disabled</source>
        <translation>Inaktiverad</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="842"/>
        <source>Auto Detect</source>
        <translation>Upptäck automatiskt</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="895"/>
        <source>Clear</source>
        <translation>Töm</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1053"/>
        <source>Default Application</source>
        <translation>Standardapplikation</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1061"/>
        <source>Unknown</source>
        <translation>Okänd</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1202"/>
        <source>Default Style</source>
        <translation>Förvald stil</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1256"/>
        <source>Add New</source>
        <translation>Lägg till ny</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1259"/>
        <source>Add Toolbar…</source>
        <translation>Lägg till verktygsrad…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1260"/>
        <source>Add Bookmarks Bar…</source>
        <translation>Lägg till bokmärkesrad…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1261"/>
        <source>Add Sidebar…</source>
        <translation>Lägg till sidorad…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1343"/>
        <source>Custom User Agent…</source>
        <translation>Anpassad användaragent…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1387"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="955"/>
        <source>Edit Link Bookmark…</source>
        <translation>Redigera länk-bokmärke…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="987"/>
        <source>Open Image in This Tab</source>
        <translation>Öppna bilden i denna fliken</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="991"/>
        <source>Open Image in New Tab</source>
        <translation>Öppna bilden i ny flik</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="999"/>
        <source>Open Image in New Window</source>
        <translation>Öppna bilden i nytt fönster</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1003"/>
        <source>Open Image in New Background Window</source>
        <translation>Öppna bilden in nytt bakgrundsfönster</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1007"/>
        <source>Open Image in New Private Tab</source>
        <translation>Öppna bilden in ny privat flik</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1011"/>
        <source>Open Image in New Private Background Tab</source>
        <translation>Öppna bilden i ny privat bakgrundsflik</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1015"/>
        <source>Open Image in New Private Window</source>
        <translation>Öppna bilden in nytt privat fönster</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1019"/>
        <source>Open Image in New Private Background Window</source>
        <translation>Öppna bilden in nytt privat bakgrundsfönster</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1056"/>
        <source>Save Video…</source>
        <translation>Spara video…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1056"/>
        <source>Save Audio…</source>
        <translation>Spara ljud…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1061"/>
        <source>Copy Video Link to Clipboard</source>
        <translation>Kopiera videons länk till klippbordet</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1061"/>
        <source>Copy Audio Link to Clipboard</source>
        <translation>Kopiera ljudets länk till klippbordet</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1076"/>
        <source>Pause</source>
        <translation>Paus</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1082"/>
        <source>Unmute</source>
        <translation>Sätt på ljud</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1103"/>
        <source>Unmute Tab Media</source>
        <translation>Sätt på ljud ur flikens media</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1137"/>
        <source>Purge History Entry</source>
        <translation>Rensa historikelement</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1281"/>
        <source>Edit Bookmark…</source>
        <translation>Redigera Bokmärke…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1281"/>
        <source>Add Bookmark…</source>
        <translation>Lägg till bokmärke…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Window.cpp" line="656"/>
        <source>Unpin Tab</source>
        <translation>Lossa fliken</translation>
    </message>
    <message>
        <location filename="../../src/ui/WorkspaceWidget.cpp" line="543"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
</context>
<context>
    <name>addons</name>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="123"/>
        <source>Addons</source>
        <translation>Tillägg</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="124"/>
        <source>Bookmarks</source>
        <translation>Bokmärken</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="125"/>
        <source>Cache</source>
        <translation>Cache</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="126"/>
        <source>Advanced Configuration</source>
        <translation>Avancerad konfiguration</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="127"/>
        <source>Cookies</source>
        <translation>Kakor</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="128"/>
        <source>Feeds</source>
        <translation>Flöden</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="129"/>
        <source>History</source>
        <translation>Historik</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="130"/>
        <source>Links</source>
        <translation>Länkar</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="131"/>
        <source>Notes</source>
        <translation>Anteckningar</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="132"/>
        <source>Page Information</source>
        <translation>Sidoinformation</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="133"/>
        <source>Passwords</source>
        <translation>Lösenord</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="134"/>
        <source>Tab History</source>
        <translation>Flikhistorik</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="135"/>
        <source>Downloads</source>
        <translation>Nedladdningar</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="136"/>
        <source>Windows and Tabs</source>
        <translation>Fönster och flikar</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="105"/>
        <source>Failed to open content blocking profile file: %1</source>
        <translation>Misslyckades med att öppna profilfil för innehållsblockering: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="604"/>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="632"/>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="645"/>
        <source>Failed to update content blocking profile: %1</source>
        <translation>Misslyckades med att uppdatera profilen för innehållsblockering: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="618"/>
        <source>Failed to update content blocking profile: checksum mismatch</source>
        <translation>Misslyckades med att uppdatera profilen för innehållsblockering: kontrollsumman stämmer inte överens</translation>
    </message>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="885"/>
        <source>Failed to update content blocking profile, update URL is empty</source>
        <translation>Misslyckades med att uppdatera profilen för innehållsblockering, webbadressen är tom</translation>
    </message>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="889"/>
        <source>Failed to update content blocking profile, update URL (%1) is invalid</source>
        <translation>Misslyckades med att uppdatera profilen för innehållsblockering, webbadressen (%1) är ogiltig</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="200"/>
        <source>Failed to find User Script file: %1</source>
        <translation>Misslyckades med att hitta användars-skriptfilen: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="125"/>
        <source>URL to open</source>
        <translation>Webbadress att öppnas</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="126"/>
        <source>Uses &lt;path&gt; as cache directory</source>
        <translation>Använder &lt;sökväg&gt; som katalog för cachen</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="127"/>
        <source>Uses &lt;path&gt; as profile directory</source>
        <translation>Använder &lt;sökväg&gt; som profil-katalog</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="128"/>
        <source>Restores session &lt;session&gt; if it exists</source>
        <translation>Återupptar sessionen &lt;session&gt; falls den existerar</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="129"/>
        <source>Starts private session</source>
        <translation>Startar privat session</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="130"/>
        <source>Forces session chooser dialog</source>
        <translation>Visar dialogen som väljer session</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="131"/>
        <source>Sets profile and cache paths to directories inside the same directory as that of application binary</source>
        <translation>Ställer in profil- och cache-sökvägarna som kataloger inom samma katalog där applikationens körbara fil befinner sig</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="132"/>
        <source>Loads URL in new tab</source>
        <translation>Hämtar webbadress i ny flik</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="133"/>
        <source>Loads URL in new private tab</source>
        <translation>Hämtar webbadress i ny privat flik</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="134"/>
        <source>Loads URL in new window</source>
        <translation>Hämtar webbadress i nytt fönster</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="135"/>
        <source>Loads URL in new private window</source>
        <translation>Hämtar webbadress i nytt privat fönster</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="136"/>
        <source>Tells application to avoid writing data to disk</source>
        <translation>Användingen ska undvikas att skriva data till disk</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="137"/>
        <source>Prints out diagnostic report and exits application</source>
        <translation>Sriver ut en diagnostisk rapport och avslutar applikationen</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkAutomaticProxy.cpp" line="414"/>
        <source>Failed to parse entry of proxy auto-config (PAC): %1</source>
        <translation>Misslyckades med att tolka element av proxyns automatiska konfiguration (PAC): %1</translation>
    </message>
    <message>
        <location filename="../../src/core/PlatformIntegration.cpp" line="135"/>
        <source>Failed to install update
Updater: %1
Script: %2</source>
        <translation>Misslyckades med att installera uppdatering
Programm: %1
Skript: %2</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionsManager.h" line="161"/>
        <source>Start Page</source>
        <translation>Startsida</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionsManager.h" line="165"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
    <message>
        <location filename="../../src/core/UpdateChecker.cpp" line="44"/>
        <source>Unable to check for updates. Invalid URL: %1</source>
        <translation>Det var inte möjligt att kolla för uppdateringar. Ogiltig webbadress: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/UpdateChecker.cpp" line="62"/>
        <source>Unable to check for updates: %1</source>
        <translation>Det var inte möjligt att kolla för uppdateringar: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/UpdateChecker.cpp" line="95"/>
        <source>Unable to parse version number: %1</source>
        <translation>Det var inte möjligt att tolka versionsnummret: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Updater.cpp" line="84"/>
        <source>Downloaded update script is not valid: %1</source>
        <translation>Uppdaterings-skriptet som hämtades är inte giltigt: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Updater.cpp" line="104"/>
        <source>Unable to download update: %1</source>
        <translation>Det var inte möjligt att hämta uppdateringen: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/UserScript.cpp" line="65"/>
        <source>Failed to open User Script file: %1</source>
        <translation>Misslyckades med att öppna användars-skriptfilen: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/UserScript.cpp" line="151"/>
        <source>Invalid match rule for User Script: %1</source>
        <translation>Ogiltig regel om överensstämmelse för användarsskriptet: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/UserScript.cpp" line="228"/>
        <source>Failed to locate header of User Script file</source>
        <translation>Misslyckades med att hitta huvudet av användars-skriptfilen</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="163"/>
        <source>Default</source>
        <translation>Förval</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="80"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineUrlRequestInterceptor.cpp" line="157"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="691"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="249"/>
        <source>Request blocked by rule from profile %1:
%2</source>
        <translation>Förfågan blockerades av regeln från profilen %1:
%2</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineUrlRequestInterceptor.cpp" line="157"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="691"/>
        <source>(Unknown)</source>
        <translation>(Okänd)</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="503"/>
        <source>Failed to run File Associations Manager, error code: %1
Application ID: %2</source>
        <translation>Misslyckades med att köra filbindelse-förvaltningen, felkod: %1
Applikations-ID: %2</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="522"/>
        <source>Failed to run File Associations Manager, error code: %1</source>
        <translation>Misslyckades med att köra filbindelse-förvaltningen, felkod: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="577"/>
        <source>Failed to register application to system registry: %1, %2</source>
        <translation>Misslyckades med att registrera applikationen i system-registret: %1, %2</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="211"/>
        <source>Failed to load custom rules: invalid adblock header</source>
        <translation>Misslyckades med att ladda anpassade regler: ogiltigt huvud för reklamblockeringen</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="519"/>
        <source>Failed to create a file with custom rules: %1</source>
        <translation>Misslyckades med att skapa en fil med anpassade regler: %1</translation>
    </message>
</context>
<context>
    <name>migrations</name>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="193"/>
        <source>Keyboard and Mouse Configuration Profiles</source>
        <translation>Konfigurationsprofiler för tangentbord och mus</translation>
    </message>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="327"/>
        <source>Options</source>
        <translation>Alternativ</translation>
    </message>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="363"/>
        <source>Search Engines</source>
        <translation>Sökmotorer</translation>
    </message>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="486"/>
        <source>Sessions</source>
        <translation>Sessioner</translation>
    </message>
</context>
<context>
    <name>notifications</name>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="87"/>
        <source>Feed Updated</source>
        <translation>Flödet uppdaterades</translation>
    </message>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="87"/>
        <source>Feed update was completed</source>
        <translation>Uppdateringen för flödet slutfördes</translation>
    </message>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="88"/>
        <source>Download Completed</source>
        <translation>Nedladdningen är slutförd</translation>
    </message>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="88"/>
        <source>File download was completed</source>
        <translation>Nedladdningen av filen slutfördes</translation>
    </message>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="89"/>
        <source>Update Available</source>
        <translation>Uppdatering tillgänglig</translation>
    </message>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="89"/>
        <source>Update is available to be downloaded</source>
        <translation>Uppdateringen står redo för hämtning</translation>
    </message>
</context>
<context>
    <name>proxies</name>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.cpp" line="693"/>
        <location filename="../../src/core/NetworkManagerFactory.h" line="90"/>
        <source>System Configuration</source>
        <translation>System-konfiguration</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.h" line="85"/>
        <source>No Proxy</source>
        <translation>Ingen proxy</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.h" line="94"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
</context>
<context>
    <name>userAgents</name>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.cpp" line="582"/>
        <location filename="../../src/core/NetworkManagerFactory.cpp" line="723"/>
        <location filename="../../src/core/NetworkManagerFactory.h" line="118"/>
        <source>Default User Agent</source>
        <translation>Förvald användaragent</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.h" line="123"/>
        <source>Mask as {name}</source>
        <translation>Dölj som {namn}</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.h" line="127"/>
        <source>(Untitled)</source>
        <translation>(Utan titel)</translation>
    </message>
</context>
<context>
    <name>utils</name>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="52"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="61"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="922"/>
        <source>Try Again</source>
        <translation>Försök igen</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="185"/>
        <source>You tried to access the address &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;, which was blocked by content blocker.</source>
        <translation>Du försökta att komma åt adressen &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;, som avvisades av innehållsblockeringen.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="189"/>
        <source>The owner of &lt;strong&gt;%1&lt;/strong&gt; has configured their page improperly. To protect your information from being stolen, connection to this website was aborted.</source>
        <translation>Ägaren av &lt;strong&gt;%1&lt;/strong&gt; har konfigurerat servern felaktigt. Anslutningen till denna webbplatsen avbröts för att skydda dinna informationer mot missbruk.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="193"/>
        <source>This web page at &lt;strong&gt;%1&lt;/strong&gt; has been reported as a web forgery. To protect your information from being stolen, connection to this website was aborted.</source>
        <translation>Webbplatsen &lt;strong&gt;%1&lt;/strong&gt; har mälts som förfalskning. Anslutningen till denna webbplatsen avbröts för att förhindra att dinna informationer stjäls.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="197"/>
        <source>You tried to access the address &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;, which is currently unavailable. Please make sure that the web address (URL) is correctly spelled and punctuated, then try reloading the page.</source>
        <translation>Du försökte att komma åt adressen &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;, som för närvarande inte är tillgänglig. Se upp med att webbadressen är rätt stavad och försök sedan att hämta om sidan.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="201"/>
        <source>Check the file name for capitalization or other typing errors.</source>
        <translation>Pröva stavningen av filnamnet (storbokstäver eller andra fel).</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="201"/>
        <source>Check to see if the file was moved, renamed or deleted.</source>
        <translation>Pröva om filen flyttades, bytte namn eller togs bort.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="205"/>
        <source>Check the address for typing errors.</source>
        <translation>Pröva adressen på stavningsfel.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="205"/>
        <source>Make sure your internet connection is active and check whether other applications that rely on the same connection are working.</source>
        <translation>Pröva att din nätverksanslutning är aktiv. Kolla om andra applikationer, som arbetar med samma anslutning, fungerar.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="205"/>
        <source>Check that the setup of any internet security software is correct and does not interfere with ordinary web browsing.</source>
        <translation>Pröva att inga brandväggs- eller säkerhetsinställningar stör Otters verksamhet.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="205"/>
        <source>Try pressing the F12 key on your keyboard and disabling proxy servers, unless you know that you are required to use a proxy to connect to the internet, and then reload the page.</source>
        <translation>Försök att inaktivera proxy-servrar genom att trycka F12-tangenten, om inte du är säker att en proxy behövs, och hämta sedan om sidan.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="216"/>
        <source>Address blocked</source>
        <translation>Adress blockerad</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="220"/>
        <source>Connection is insecure</source>
        <translation>Anslutningen är osäker</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="224"/>
        <source>Connection refused</source>
        <translation>Anslutningen avvisades</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="228"/>
        <source>File not found</source>
        <translation>Filen hittades inte</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="232"/>
        <source>Fraud attempt</source>
        <translation>Bedrägeriförsök</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="236"/>
        <source>Server not found</source>
        <translation>Servern hittades inte</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="240"/>
        <source>Unsupported address type</source>
        <translation>Adresstypen stöds inte</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="244"/>
        <source>Network error</source>
        <translation>Nätverksfel</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="279"/>
        <source>Advanced</source>
        <translation>Avancerat</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="322"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="423"/>
        <source>Today at %1</source>
        <translation>Idag, %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="428"/>
        <source>Yesterday at %1</source>
        <translation>Igår, %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="434"/>
        <source>%1 at %2</source>
        <translation>%1, %2</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="474"/>
        <location filename="../../src/core/Utils.cpp" line="481"/>
        <location filename="../../src/core/Utils.cpp" line="551"/>
        <location filename="../../src/core/Utils.cpp" line="617"/>
        <source>All files (*)</source>
        <translation>Alla filer (*)</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="555"/>
        <source>Open Files</source>
        <translation>Öppna filer</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="559"/>
        <source>Open File</source>
        <translation>Öppna fil</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="613"/>
        <source>%1 files (*.%2)</source>
        <translation>%1 filer (*.%2)</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="623"/>
        <source>Save File</source>
        <translation>Spara fil</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="645"/>
        <location filename="../../src/core/Utils.cpp" line="654"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="645"/>
        <source>This path is already used by different download, pick another one.</source>
        <translation>Denna sökvägen används redan av en annan överföring. Välj en annan.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="654"/>
        <source>Target path is not writable.
Select another one.</source>
        <translation>Målsökvägen är inte skrivbar. Välj en annan.</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="890"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="906"/>
        <source>Go Back</source>
        <translation>Gå bakåt</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="895"/>
        <source>Load Blocked Page</source>
        <translation>Hämta blockerad sida</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="911"/>
        <source>Load Insecure Page</source>
        <translation>Hämta osäker sida</translation>
    </message>
</context>
</TS>