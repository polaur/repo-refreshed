<?xml version="1.0" ?><!DOCTYPE TS><TS language="nb" version="2.1">
<context>
    <name>Otter::AcceptCookieDialog</name>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="14"/>
        <source>Accept Cookie</source>
        <translation>Tillat kake</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="35"/>
        <source>Name:</source>
        <translation>Navn:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="45"/>
        <source>Value:</source>
        <translation>Verdi:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="55"/>
        <source>Expiration date:</source>
        <translation>Utløpsdato:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="69"/>
        <source>Send for:</source>
        <translation>Send i:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="83"/>
        <source>Accessible using JavaScript:</source>
        <translation>Tilgjengelig ved bruk av JavaScript:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.ui" line="100"/>
        <source>Domain:</source>
        <translation>Domene:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="47"/>
        <source>Website %1 requested to add new cookie.</source>
        <translation>Nettsiden %1 forespurte tillegg av ny informasjonskapsel.</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="51"/>
        <source>Website %1 requested to update existing cookie.</source>
        <translation>Nettsiden %1 forespurte oppdatering av eksisterende informasjonskapsel.</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="55"/>
        <source>Website %1 requested to remove existing cookie.</source>
        <translation>Nettsiden %1 forespurte fjerning av eksisterende informasjonskapsel.</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="61"/>
        <source>This session only</source>
        <translation>Kun for denne økta</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="62"/>
        <source>Secure connections only</source>
        <translation>Kun sikre tilkoblinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="62"/>
        <source>Any type of connection</source>
        <translation>Enhver type tilkobling</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="63"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="63"/>
        <source>No</source>
        <translation>Nei</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="64"/>
        <source>Accept</source>
        <translation>Godta</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="68"/>
        <source>Accept For This Session Only</source>
        <translation>Bare godta for denne økta</translation>
    </message>
    <message>
        <location filename="../../src/ui/AcceptCookieDialog.cpp" line="71"/>
        <source>Discard</source>
        <translation>Avfei</translation>
    </message>
</context>
<context>
    <name>Otter::AcceptLanguageDialog</name>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="14"/>
        <source>Preferred Webpage Language</source>
        <translation>Foretrukket språk for nettsider</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="20"/>
        <source>To add language, please choose one from list or type its code.</source>
        <translation>For å legge til et språk, velg ett fra listen eller tast dets kode.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="39"/>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="82"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="107"/>
        <source>Move Up</source>
        <translation>Flytt opp</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.ui" line="133"/>
        <source>Move Down</source>
        <translation>Flytt ned</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="38"/>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="113"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="38"/>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="113"/>
        <source>Code</source>
        <translation>Kode</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="61"/>
        <source>Unknown [%1]</source>
        <translation>Ukjent [%1]</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="78"/>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="142"/>
        <source>Any other</source>
        <translation>Enhver annen</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="79"/>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="146"/>
        <source>System language (%1 - %2)</source>
        <translation>Systemspråk (%1 - %2)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="154"/>
        <source>Custom</source>
        <translation>Egentilpasset</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/AcceptLanguageDialog.cpp" line="158"/>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
</context>
<context>
    <name>Otter::Action</name>
    <message>
        <location filename="../../src/ui/Action.cpp" line="119"/>
        <source>Creating instance of deprecated action: %1</source>
        <translation>Oppretter instans for foreldet handling: %1</translation>
    </message>
</context>
<context>
    <name>Otter::ActionComboBoxWidget</name>
    <message>
        <location filename="../../src/ui/ActionComboBoxWidget.cpp" line="84"/>
        <source>Select Action</source>
        <translation>Velg en handling</translation>
    </message>
    <message>
        <location filename="../../src/ui/ActionComboBoxWidget.cpp" line="155"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
</context>
<context>
    <name>Otter::AdblockContentFiltersProfile</name>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="708"/>
        <source>(Unknown)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Otter::AddonsContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="119"/>
        <source>User Scripts</source>
        <translation>Brukerskript</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="147"/>
        <source>Select Files</source>
        <translation>Velg filer</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="147"/>
        <source>User Script files (*.js)</source>
        <translation>Brukerskript-filer (*.js)</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="183"/>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="365"/>
        <source>Question</source>
        <translation>Spørsmål</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="184"/>
        <source>User Script with this name already exists:
%1</source>
        <translation>Brukerskript ved dette navnet finnes allerede:
%1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="185"/>
        <source>Do you want to replace it?</source>
        <translation>Ønsker du å erstatte det?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="192"/>
        <source>Apply to all</source>
        <translation>Bruk for alle</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="237"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="237"/>
        <source>Failed to import following User Script file(s):
%1</source>
        <translation><numerusform>Klarte ikke å importere følgende brukerskriptfil:
%1</numerusform><numerusform>Klarte ikke å importere følgende brukerskriptfiler:
%1</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="366"/>
        <source>You are about to irreversibly remove %n addon(s).</source>
        <translation><numerusform>Du er i ferd med å fjerne ett tillegg.</numerusform><numerusform>Du er i ferd med å fjerne %n tillegg.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="367"/>
        <source>Do you want to continue?</source>
        <translation>Ønsker du å fortsette?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="433"/>
        <source>Add Addon…</source>
        <translation>Legg til programtillegg…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="439"/>
        <source>Open Addon File</source>
        <translation>Åpne programtilleggsfil</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="440"/>
        <source>Reload Addon</source>
        <translation>Gjeninnlast programtillegg</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="444"/>
        <source>Remove Addon…</source>
        <translation>Fjern programtillegg…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/addons/AddonsContentsWidget.cpp" line="485"/>
        <source>Addons</source>
        <translation>Programtillegg</translation>
    </message>
</context>
<context>
    <name>Otter::AddressCompletionModel</name>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="93"/>
        <source>Search with %1</source>
        <translation>Søk mde %1</translation>
    </message>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="111"/>
        <source>Bookmarks</source>
        <translation>Bokmerker</translation>
    </message>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="145"/>
        <source>Local files</source>
        <translation>Lokale filer</translation>
    </message>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="161"/>
        <source>History</source>
        <translation>Historikk</translation>
    </message>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="176"/>
        <source>Typed history</source>
        <translation>Skrivehistorikk</translation>
    </message>
    <message>
        <location filename="../../src/core/AddressCompletionModel.cpp" line="198"/>
        <source>Special pages</source>
        <translation>Spesialsider</translation>
    </message>
</context>
<context>
    <name>Otter::AddressWidget</name>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="341"/>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="372"/>
        <source>Enter address or search…</source>
        <translation>Skriv inn adresse lelr søk…</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="540"/>
        <source>Remove this Icon</source>
        <translation>Fjern dette ikonet</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="631"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="662"/>
        <source>Add to Bookmarks</source>
        <translation>Legg til som bokmerke…</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="674"/>
        <source>Add to Start Page</source>
        <translation>Legg på startsiden</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1045"/>
        <source>Show website information</source>
        <translation>Vis nettsideinformasjon</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1059"/>
        <source>Show feed list</source>
        <translation>Vis informasjonskanalliste</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1071"/>
        <source>Remove bookmark</source>
        <translation>Fjern bokmerke</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1076"/>
        <source>Add bookmark</source>
        <translation>Legg til bokmerke</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1085"/>
        <source>Load all plugins on the page</source>
        <translation>Last alle programtillegg på siden</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/address/AddressWidget.cpp" line="1093"/>
        <source>Log in</source>
        <translation>Logg inn</translation>
    </message>
</context>
<context>
    <name>Otter::Application</name>
    <message>
        <location filename="../../src/core/Application.cpp" line="322"/>
        <location filename="../../src/core/Application.cpp" line="353"/>
        <location filename="../../src/core/Application.cpp" line="442"/>
        <location filename="../../src/core/Application.cpp" line="1017"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="322"/>
        <source>Profile directory (%1) is not writable, application will be running in read-only mode.</source>
        <translation>Profilmappa (%1) er skrivebeskyttet, programmet vil kjøre i skrivebeskyttet modus.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="345"/>
        <source>Your profile directory (%1) ran out of free disk space.
This may lead to malfunctions or even data loss.</source>
        <translation>Din profilmappe (%1) har ikke mer diskplass igjen.
Dette kan føre til feilaktig oppførsel eller selv datatap.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="349"/>
        <source>Your profile directory (%1) is running low on free disk space (%2 remaining).
This may lead to malfunctions or even data loss.</source>
        <translation>Din profilmappe (%1) begynner å gå tom for diskplass (%2 gjenstående).
Dette kan føre til feilaktig oppførsel eller selv datatap.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="355"/>
        <location filename="../../src/core/Application.cpp" line="1643"/>
        <location filename="../../src/core/Application.cpp" line="1692"/>
        <source>Do you want to continue?</source>
        <translation>Vil du fortsette?</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="357"/>
        <location filename="../../src/core/Application.cpp" line="1647"/>
        <location filename="../../src/core/Application.cpp" line="1696"/>
        <source>Do not show this message again</source>
        <translation>Ikke vis denne meldingen igjen</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="358"/>
        <source>Continue in Read-only Mode</source>
        <translation>Fortsett i skrivebeskyttet modus</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="360"/>
        <source>Ignore</source>
        <translation>Ignorer</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="361"/>
        <source>Quit</source>
        <translation>Avslutt</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="442"/>
        <source>SSL support is not available or incomplete.
Some websites may work incorrectly or do not work at all.</source>
        <translation>SSL-støtte er ikke tilgjengelig eller ufullstendig.
Noen nettsider fungerer kanskje ikke rett eller ikke i det hele tatt.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="741"/>
        <source>&lt;b&gt;Otter %1&lt;/b&gt;&lt;br&gt;Web browser controlled by the user, not vice-versa.&lt;br&gt;&lt;a href=&quot;https://www.otter-browser.org/&quot;&gt;https://www.otter-browser.org/&lt;/a&gt;</source>
        <translation>&lt;b&gt;Oter %1&lt;/b&gt;&lt;br&gt;Nettleser kontrollert av brukeren, ikke motsatt.&lt;br&gt;&lt;a href=&quot;https://www.otter-browser.org/&quot;&gt;https://www.otter-browser.org/&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="747"/>
        <source>Web backend: %1 %2.</source>
        <translation>Vev-bakstykke: %1 %2</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="751"/>
        <source>SSL library not available.</source>
        <translation>SSL-bibliotek ikke tilgjengelig.</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="755"/>
        <source>SSL library version: %1.</source>
        <translation>SSL-bibliotek versjon: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1017"/>
        <source>This session was not saved correctly.
Are you sure that you want to restore this session anyway?</source>
        <translation>Denne økta ble ikke lagret på rett måte.
Er du sikker på at du vil gjenopprette den likevel?</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1171"/>
        <source>New update %1 from %2 channel is available!</source>
        <translation>Ny oppdatering %1 fra kanal %2 er tilgjengelig!</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1641"/>
        <location filename="../../src/core/Application.cpp" line="1690"/>
        <source>Question</source>
        <translation>Spørsmål</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/core/Application.cpp" line="1642"/>
        <source>You are about to quit while %n files are still being downloaded.</source>
        <translation><numerusform>Du er i ferd med å avslutte mens %n fil blir lastet ned.</numerusform><numerusform>Du er i ferd med å avslutte mens %n filer blir lastet ned.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1649"/>
        <location filename="../../src/core/Application.cpp" line="1698"/>
        <source>Hide</source>
        <translation>Gjem</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1691"/>
        <source>You are about to quit the current Otter Browser session.</source>
        <translation>Du er i ferd med å avslutte gjeldende Oter-økt.</translation>
    </message>
</context>
<context>
    <name>Otter::ApplicationComboBoxWidget</name>
    <message>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="34"/>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="47"/>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="122"/>
        <source>Default Application</source>
        <translation>Forvalgt program</translation>
    </message>
    <message>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="36"/>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="48"/>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="144"/>
        <source>Other…</source>
        <translation>Annet…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="60"/>
        <source>Select Application</source>
        <translation>Velg program</translation>
    </message>
    <message>
        <location filename="../../src/ui/ApplicationComboBoxWidget.cpp" line="130"/>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
</context>
<context>
    <name>Otter::AtomFeedParser</name>
    <message>
        <location filename="../../src/core/FeedParser.cpp" line="215"/>
        <source>Failed to parse feed file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/FeedParser.cpp" line="226"/>
        <source>Failed to parse feed: no valid entries found</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Otter::AuthenticationDialog</name>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="14"/>
        <source>Authentication Required</source>
        <translation>Identitetsbekreftelse kreves</translation>
    </message>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="22"/>
        <source>Server:</source>
        <translation>Tjener:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="42"/>
        <source>Message:</source>
        <translation>Melding:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="62"/>
        <source>User:</source>
        <translation>Bruker:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="72"/>
        <source>Password:</source>
        <translation>Passord:</translation>
    </message>
    <message>
        <location filename="../../src/ui/AuthenticationDialog.ui" line="101"/>
        <source>Remember password</source>
        <translation>Husk passord</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarkPropertiesDialog</name>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="19"/>
        <source>Title:</source>
        <translation>Tittel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="29"/>
        <source>Description:</source>
        <translation>Beskrivelse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="39"/>
        <source>Address:</source>
        <translation>Adresse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="49"/>
        <source>Folder:</source>
        <translation>Mappe:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="71"/>
        <source>New…</source>
        <translation>Ny…</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="96"/>
        <source>Visits:</source>
        <translation>Besøk:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="103"/>
        <source>Last visit:</source>
        <translation>Siste besøk:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="110"/>
        <source>Created:</source>
        <translation>Opprettet:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="138"/>
        <source>Modified:</source>
        <translation>Endret:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.ui" line="152"/>
        <source>Keyword:</source>
        <translation>Nøkkelord:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="50"/>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="51"/>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="62"/>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="75"/>
        <source>View Bookmark</source>
        <translation>Se bokmerke</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="87"/>
        <source>Edit Bookmark</source>
        <translation>Rediger bokmerke</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="116"/>
        <source>Add Bookmark</source>
        <translation>Opprett bokmerke</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="159"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarkPropertiesDialog.cpp" line="159"/>
        <source>Bookmark with this keyword already exists.</source>
        <translation>Bokmerke med dette nøkkelordet finnes allerede</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarkWidget</name>
    <message>
        <location filename="../../src/modules/widgets/bookmark/BookmarkWidget.cpp" line="97"/>
        <source>Title: %1</source>
        <translation>Tittel: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/bookmark/BookmarkWidget.cpp" line="101"/>
        <source>Address: %1</source>
        <translation>Adresse: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/bookmark/BookmarkWidget.cpp" line="106"/>
        <source>Description: %1</source>
        <translation>Beskrivelse: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/bookmark/BookmarkWidget.cpp" line="111"/>
        <source>Created: %1</source>
        <translation>Opprettet: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/bookmark/BookmarkWidget.cpp" line="116"/>
        <source>Visited: %1</source>
        <translation>Besøkt: %1</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarksComboBoxWidget</name>
    <message>
        <location filename="../../src/ui/BookmarksComboBoxWidget.cpp" line="43"/>
        <source>Folder Name</source>
        <translation>Mappenavn</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksComboBoxWidget.cpp" line="43"/>
        <source>Select name of new folder:</source>
        <translation>Velg navn på ny mappe:</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarksContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="85"/>
        <source>Address:</source>
        <translation>Adresse:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="92"/>
        <source>Title:</source>
        <translation>Tittel:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="99"/>
        <source>Description:</source>
        <translation>Beskrivelse:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="115"/>
        <source>Keyword:</source>
        <translation>Nøkkelord:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="130"/>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="140"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="246"/>
        <source>Properties…</source>
        <translation>Egenskaper…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.ui" line="150"/>
        <source>Delete</source>
        <translation>Slett</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="50"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="168"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="221"/>
        <source>Add Folder…</source>
        <translation>Legg til mappe…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="51"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="169"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="222"/>
        <source>Add Bookmark…</source>
        <translation>Legg til bokmerke…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="52"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="170"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="223"/>
        <source>Add Separator</source>
        <translation>Legg til inndeling</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Description</source>
        <translation>Beskrivelse</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Keyword</source>
        <translation>Nøkkelord</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Added</source>
        <translation>Lagt til</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Modified</source>
        <translation>Modifisert</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Visited</source>
        <translation>Besøkt</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="54"/>
        <source>Visits</source>
        <translation>Besøk</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="160"/>
        <source>Empty Trash</source>
        <translation>Tøm papirkurv</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="219"/>
        <source>Add Bookmark</source>
        <translation>Opprett bokmerke</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="232"/>
        <source>Restore Bookmark</source>
        <translation>Gjenopprett bokmerker</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="337"/>
        <source>Bookmarks</source>
        <translation>Bokmerker</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarksImporterWidget</name>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="17"/>
        <source>Remove existing bookmarks</source>
        <translation>Fjern eksisterende bokmerker</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="51"/>
        <source>Import into folder:</source>
        <translation>Importer til mappe:</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="70"/>
        <source>New…</source>
        <translation>Ny…</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="81"/>
        <source>Allow to duplicate already existing bookmarks</source>
        <translation>Tillat opprettelse av kopier av allerede eksisterende bokmerker</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="107"/>
        <source>Import into subfolder</source>
        <translation>Importer til undermappe</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="120"/>
        <source>Leave empty to import into main folder</source>
        <translation>La stå tom for å importere til hovedmappe</translation>
    </message>
    <message>
        <location filename="../../src/ui/BookmarksImporterWidget.ui" line="127"/>
        <source>Subfolder name:</source>
        <translation>Undermappens navn:</translation>
    </message>
</context>
<context>
    <name>Otter::BookmarksModel</name>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="155"/>
        <source>Notes</source>
        <translation>Notater</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="159"/>
        <source>Bookmarks</source>
        <translation>Bokmerker</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="161"/>
        <source>Trash</source>
        <translation>Papirkurv</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="185"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="362"/>
        <source>Failed to open notes file: %1</source>
        <translation>Kunne ikke åpne fil med notater: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="362"/>
        <source>Failed to open bookmarks file: %1</source>
        <translation>Kunne ikke åpne fil med bokmerker: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="386"/>
        <source>Failed to load notes file: %1</source>
        <translation>Klarte ikke å legge til notatfil: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="386"/>
        <source>Failed to load bookmarks file: %1</source>
        <translation>Klarte ikke å laste bokmerkefil: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="388"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="388"/>
        <source>Failed to load notes file.</source>
        <translation>Klarte ikke å laste notatfil.</translation>
    </message>
    <message>
        <location filename="../../src/core/BookmarksModel.cpp" line="388"/>
        <source>Failed to load bookmarks file.</source>
        <translation>Klarte ikke å laste bokmerkefil.</translation>
    </message>
</context>
<context>
    <name>Otter::CacheContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="97"/>
        <source>Address:</source>
        <translation>Adresse:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="107"/>
        <source>Type:</source>
        <translation>Type:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="117"/>
        <source>Size:</source>
        <translation>Størrelse:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="127"/>
        <source>Last Modified:</source>
        <translation>Sist endret:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="137"/>
        <source>Expires:</source>
        <translation>Utløper:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="147"/>
        <source>Location:</source>
        <translation>Plassering:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="168"/>
        <source>Preview</source>
        <translation>Forhåndsvis</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.ui" line="207"/>
        <source>Delete</source>
        <translation>Slett</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="115"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="115"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="115"/>
        <source>Size</source>
        <translation>Størresle</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="115"/>
        <source>Last Modified</source>
        <translation>Sist endret</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="79"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="115"/>
        <source>Expires</source>
        <translation>Utløper</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="368"/>
        <source>Copy Link to Clipboard</source>
        <translation>Kopier til utklippstavle</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="372"/>
        <source>Remove Entry</source>
        <translation>Fjern oppføring</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="381"/>
        <source>Remove All Entries from This Domain</source>
        <translation>Fjern alle oppføringer tilknytttet dette domenet</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="449"/>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="535"/>
        <source>Cache</source>
        <translation>Hurtiglager</translation>
    </message>
</context>
<context>
    <name>Otter::CertificateDialog</name>
    <message>
        <location filename="../../src/ui/CertificateDialog.ui" line="17"/>
        <source>Certificate chain:</source>
        <translation>Sertifikatkjede:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.ui" line="34"/>
        <source>Certificate fields:</source>
        <translation>Sertifikatfelter:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.ui" line="51"/>
        <source>Field value:</source>
        <translation>Feltverdi:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="44"/>
        <source>Export…</source>
        <translation>Eksporter…</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="48"/>
        <source>Invalid Certificate</source>
        <translation>Ugyldig sertifikat</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="53"/>
        <source>View Certificate for %1</source>
        <translation>Vis sertifikat for %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="62"/>
        <location filename="../../src/ui/CertificateDialog.cpp" line="456"/>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="116"/>
        <source>Select File</source>
        <translation>Velg fil</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="116"/>
        <source>DER encoded X.509 certificates (*.der)</source>
        <translation>DER-kodede X.509-sertifikater (*.der)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="116"/>
        <source>PEM encoded X.509 certificates (*.pem)</source>
        <translation>PEM-kodede X.509-sertifikater (*.pem)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="116"/>
        <source>Text files (*.txt)</source>
        <translation>Tekstfiler (*.txt)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="124"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="124"/>
        <source>Failed to open file for writing.</source>
        <translation>Klarte ikke å åpne fil for skriving</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="183"/>
        <source>Authority Key Identifier</source>
        <translation>Myndighetsnøkkelidentifikator (AKI)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="187"/>
        <source>Subject Key Identifier</source>
        <translation>Emnenøkkelidentifikator (SKI)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="191"/>
        <source>Key Usage</source>
        <translation>Nøkkelbruk</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="195"/>
        <source>Certificate Policies</source>
        <translation>Sertifikatpraksis:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="199"/>
        <source>Policy Mappings</source>
        <translation>Praksistilordning</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="203"/>
        <source>Subject Alternative Name</source>
        <translation>Alternativt emnenavn (SAN)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="207"/>
        <source>Issuer Alternative Name</source>
        <translation>Alternativt utstedernavn (IAN)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="211"/>
        <source>Subject Directory Attributes</source>
        <translation>Mappeemneatributter (SDA)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="215"/>
        <source>Basic Constraints</source>
        <translation>Grunnleggende begrensninger</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="219"/>
        <source>Name Constraints</source>
        <translation>Navnebegrensninger</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="223"/>
        <source>Policy Constraints</source>
        <translation>Praksisbegrensninger</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="227"/>
        <source>Extended Key Usage</source>
        <translation>Utvidet nøkkelbruk</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="231"/>
        <source>CRL Distribution Points</source>
        <translation>CRL-distribusjonspunkter</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="235"/>
        <source>Inhibit Any Policy</source>
        <translation>Forhindre alle praksiser</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="239"/>
        <source>Delta CRL Distribution Point</source>
        <translation>Delta-CRL-distribusjonspunkt</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="243"/>
        <source>Authority Information Access</source>
        <translation>Myndighetsinformasjonstilgang (AIA)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="247"/>
        <source>Subject Information Access</source>
        <translation>Emneinformasjonstilgang (SIA)</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="336"/>
        <source>Modulus:
%1

Exponent: %2</source>
        <translation>Modulus:
%1

Eksponent: %2</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="349"/>
        <source>Critical</source>
        <translation>Kritisk</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="349"/>
        <source>Not Critical</source>
        <translation>Ikke kritisk</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="350"/>
        <source>OID: %1</source>
        <translation>OID: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="354"/>
        <source>Value:</source>
        <translation>Verdi:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="408"/>
        <source>Version</source>
        <translation>Versjon:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="412"/>
        <source>Serial Number</source>
        <translation>Serienummer</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="416"/>
        <source>Certificate Signature Algorithm</source>
        <translation>Sertifikatsigneringsalgoritme</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="420"/>
        <source>Issuer</source>
        <translation>Utsteder</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="424"/>
        <source>Validity</source>
        <translation>Gyldighet</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="428"/>
        <source>Not Before</source>
        <translation>Ikke før</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="432"/>
        <source>Not After</source>
        <translation>Ikke etter</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="436"/>
        <source>Subject</source>
        <translation>Emne</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="440"/>
        <source>Subject Public Key</source>
        <translation>Velg offentlig nøkkel</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="444"/>
        <source>Algorithm</source>
        <translation>Algoritme</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="448"/>
        <source>Public Key</source>
        <translation>Offentlig nøkkel</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="452"/>
        <source>Extensions</source>
        <translation>Programtillegg</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="460"/>
        <source>Fingerprint</source>
        <translation>Fingeravtrykk</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="464"/>
        <source>SHA-1 Fingerprint</source>
        <translation>SHA-1-fingeravtrykk</translation>
    </message>
    <message>
        <location filename="../../src/ui/CertificateDialog.cpp" line="468"/>
        <source>SHA-256 Fingerprint</source>
        <translation>SHA-256-fingeravtrykk</translation>
    </message>
</context>
<context>
    <name>Otter::ClearHistoryDialog</name>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="14"/>
        <source>Clear History</source>
        <translation>Lagre historikk</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="35"/>
        <source>Period to clear:</source>
        <translation>Periode å fjerne:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="42"/>
        <source>All</source>
        <translation>Alt/alle</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="45"/>
        <source> h</source>
        <translation>t</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="61"/>
        <source>Clear browsing history</source>
        <translation>Slett surfehistorikk</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="68"/>
        <source>Clear cookies</source>
        <translation>Slett informasjonskapsler</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="78"/>
        <source>Clear forms history</source>
        <translation>Tøm skjemahistorikk</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="85"/>
        <source>Clear downloads history</source>
        <translation>Slett nedlastings-historikk</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="95"/>
        <source>Clear search history</source>
        <translation>Slett søke-historikk</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="102"/>
        <source>Clear caches</source>
        <translation>Slett hurtilagre</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="112"/>
        <source>Clear websites storage data</source>
        <translation>Tøm lagret data for nettside(r)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.ui" line="119"/>
        <source>Clear passwords</source>
        <translation>Slett alle passord</translation>
    </message>
    <message>
        <location filename="../../src/ui/ClearHistoryDialog.cpp" line="54"/>
        <location filename="../../src/ui/ClearHistoryDialog.cpp" line="85"/>
        <source>Clear Now</source>
        <translation>Tøm nå</translation>
    </message>
</context>
<context>
    <name>Otter::ColorWidget</name>
    <message>
        <location filename="../../src/ui/ColorWidget.cpp" line="56"/>
        <location filename="../../src/ui/ColorWidget.cpp" line="177"/>
        <source>Invalid</source>
        <translation>Ugyldig</translation>
    </message>
    <message>
        <location filename="../../src/ui/ColorWidget.cpp" line="105"/>
        <source>Select Color…</source>
        <translation>Velg farge…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ColorWidget.cpp" line="106"/>
        <source>Copy Color</source>
        <translation>Kopier farge</translation>
    </message>
    <message>
        <location filename="../../src/ui/ColorWidget.cpp" line="113"/>
        <source>Clear</source>
        <translation>Tøm</translation>
    </message>
</context>
<context>
    <name>Otter::ConfigurationContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="69"/>
        <source>Option Name:</source>
        <translation>Valgets navn:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="76"/>
        <source>Current Value:</source>
        <translation>Nåværende verdi:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="83"/>
        <source>Default Value:</source>
        <translation>Forvalgt verdi:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="106"/>
        <source>Save All</source>
        <translation>Lagre alt</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.ui" line="116"/>
        <source>Restore Defaults</source>
        <translation>Gjenopprett forvalg</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="212"/>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="262"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="212"/>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="262"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="212"/>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="262"/>
        <source>Value</source>
        <translation>Verdi</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="290"/>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="363"/>
        <source>Question</source>
        <translation>Spørsmål</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="290"/>
        <source>The settings have been changed.
Do you want to save them?</source>
        <translation>Innstillingene har blitt endret.
Ønsker du å lagre dem?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="363"/>
        <source>Do you really want to restore default values of all options?</source>
        <translation>Ønsker du virkelig å gjenopprette forvalgte verdier for alle valg?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="500"/>
        <source>Copy Option Name</source>
        <translation>Kopier valgets navn</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="501"/>
        <source>Copy Option Value</source>
        <translation>Kopier valgets verdi</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="505"/>
        <source>Save Value</source>
        <translation>Lagre verdi</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="508"/>
        <source>Restore Default Value</source>
        <translation>Gjenopprett til forvalgt verdi</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="517"/>
        <source>Expand All</source>
        <translation>Utvid alle</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="518"/>
        <source>Collapse All</source>
        <translation>Fold sammen alle</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/configuration/ConfigurationContentsWidget.cpp" line="544"/>
        <source>Advanced Configuration</source>
        <translation>Avansert oppsett</translation>
    </message>
</context>
<context>
    <name>Otter::ConfigurationOptionWidget</name>
    <message>
        <location filename="../../src/modules/widgets/configurationOption/ConfigurationOptionWidget.cpp" line="46"/>
        <source>Choose option</source>
        <translation>Velg alternativ</translation>
    </message>
</context>
<context>
    <name>Otter::ContentBlockingDialog</name>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="14"/>
        <source>Content Blocking</source>
        <translation>Innholdsblokkering</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="24"/>
        <source>General</source>
        <translation>Hovedinnstillinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="36"/>
        <source>Profiles</source>
        <translation>Profiler</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="43"/>
        <source>Select lists which you want to use for content blocking (AdBlock Plus compatible):</source>
        <translation>Velg listene du ønsker å bruke for innholdsblokkering (AdBlock-plus -kompatibel):</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="76"/>
        <source>Settings</source>
        <translation>Innstillinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="85"/>
        <source>Cosmetic filters:</source>
        <translation>Kosmetiske filter:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="95"/>
        <source>Enable wildcard expressions</source>
        <translation>Skru på jokertegn-uttrykk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="102"/>
        <source>Enable custom rules</source>
        <translation>Skru på egendefinerte regler</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="115"/>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="190"/>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="125"/>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="197"/>
        <source>Edit</source>
        <translation>Rediger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="135"/>
        <source>Update</source>
        <translation>Oppdater</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="145"/>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="204"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.ui" line="170"/>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="510"/>
        <source>Custom Rules</source>
        <translation>Egendefinerte regler</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="183"/>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="184"/>
        <source>Domain specific only</source>
        <translation>Bare demenespesifikke</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="185"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
</context>
<context>
    <name>Otter::ContentBlockingInformationWidget</name>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="45"/>
        <source>Active Profiles</source>
        <translation>Aktive profiler</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="46"/>
        <source>Blocked Elements</source>
        <translation>Blokkerte elementer</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="150"/>
        <source>main frame</source>
        <translation>hovedramme</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="154"/>
        <source>subframe</source>
        <translation>underramme</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="158"/>
        <source>pop-up</source>
        <translation>oppsprett</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="162"/>
        <source>stylesheet</source>
        <translation>stilark</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="166"/>
        <source>script</source>
        <translation>skript</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="170"/>
        <source>image</source>
        <translation>bilde</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="174"/>
        <source>object</source>
        <translation>objekt</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="178"/>
        <source>object subrequest</source>
        <translation>objekt-underforespørsel</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="182"/>
        <source>XHR</source>
        <translation>XHR</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="186"/>
        <source>WebSocket</source>
        <translation>WebSocket</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="190"/>
        <source>other</source>
        <translation>annet</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="209"/>
        <source>Enable Content Blocking</source>
        <translation>Skru på innholdsblokkering</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/contentBlockingInformation/ContentBlockingInformationWidget.cpp" line="339"/>
        <source>Blocked Elements: {amount}</source>
        <translation>Blokkerte elementer: {amount}</translation>
    </message>
</context>
<context>
    <name>Otter::ContentBlockingIntervalDelegate</name>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="145"/>
        <source> day(s)</source>
        <translation>dag(er)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="146"/>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="166"/>
        <source>Never</source>
        <translation>Aldri</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="166"/>
        <source>%n day(s)</source>
        <translation><numerusform>%n dag</numerusform><numerusform>%n dager</numerusform></translation>
    </message>
</context>
<context>
    <name>Otter::ContentBlockingProfileDialog</name>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="14"/>
        <source>Profile Settings</source>
        <translation>Profilinnstillinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="22"/>
        <source>Title:</source>
        <translation>Tittel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="35"/>
        <source>Category:</source>
        <translation>Kategori:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="55"/>
        <source>Address:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="68"/>
        <source>Update interval:</source>
        <translation>Oppdateringsintervall:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="78"/>
        <source>Never</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="81"/>
        <source> days</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.ui" line="91"/>
        <source>Last update:</source>
        <translation>Siste oppdatering:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="40"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="77"/>
        <source>Advertisements</source>
        <translation>Reklame</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="41"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="78"/>
        <source>Annoyance</source>
        <translation>Irritasjonsmoment</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="42"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="79"/>
        <source>Privacy</source>
        <translation>Personvern</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="43"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="80"/>
        <source>Social</source>
        <translation>Sosial</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="44"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="81"/>
        <source>Regional</source>
        <translation>Regional</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="45"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="82"/>
        <source>Other</source>
        <translation>Annet</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="93"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="114"/>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="121"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="93"/>
        <source>Valid update URL is required.</source>
        <translation>Gyldig oppdateringsnettadresse kreves</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="114"/>
        <source>Profile with name %1.txt already exists.</source>
        <translation>Profil ved navn %1.txt finnes allerede.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingProfileDialog.cpp" line="121"/>
        <source>Failed to create profile file: %1.</source>
        <translation>Klarte ikke å opprette profil-fil: %1</translation>
    </message>
</context>
<context>
    <name>Otter::ContentBlockingTitleDelegate</name>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="90"/>
        <source>Failed to read profile file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="94"/>
        <source>Failed to download profile rules</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="98"/>
        <source>Failed to verify profile rules using checksum</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="107"/>
        <source>Profile was never updated</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="111"/>
        <source>Profile was last updated more than one week ago</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Otter::ContentFiltersManager</name>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="197"/>
        <source>Custom Rules</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="318"/>
        <source>Failed to remove content blocking profile file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="318"/>
        <source>Unknown</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="353"/>
        <source>Title</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="353"/>
        <source>Update Interval</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="353"/>
        <source>Last Update</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Advertisements</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Annoyance</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Privacy</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Social</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Regional</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/ContentFiltersManager.cpp" line="399"/>
        <source>Other</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Otter::ContentsDialog</name>
    <message>
        <location filename="../../src/ui/ContentsDialog.cpp" line="75"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
</context>
<context>
    <name>Otter::ContentsWidget</name>
    <message>
        <location filename="../../src/ui/ContentsWidget.cpp" line="149"/>
        <source>Print Page</source>
        <translation>Skriv ut side</translation>
    </message>
    <message>
        <location filename="../../src/ui/ContentsWidget.cpp" line="166"/>
        <source>Print Preview</source>
        <translation>Utskriftsforhåndsvisning</translation>
    </message>
</context>
<context>
    <name>Otter::CookiePropertiesDialog</name>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="22"/>
        <source>Name:</source>
        <translation>Navn:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="38"/>
        <source>Value:</source>
        <translation>Verdi:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="51"/>
        <source>Expires:</source>
        <translation>Utløper:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="64"/>
        <source>this session only</source>
        <translation>kun for denne økta</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="71"/>
        <source>MM.dd.yyyy HH:mm</source>
        <comment>Date and time format</comment>
        <translation>dd.MM.yyyy.HH.mm</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="81"/>
        <source>Domain:</source>
        <translation>Domene:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="97"/>
        <source>Path:</source>
        <translation>Sti:</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="112"/>
        <source>Send only for secure connections</source>
        <translation>Kun send for sikre tilkoblinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.ui" line="119"/>
        <source>Allow accessing using JavaScript</source>
        <translation>Tillat tilgang ved bruk av JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.cpp" line="35"/>
        <source>Add Cookie</source>
        <translation>Legg til kake</translation>
    </message>
    <message>
        <location filename="../../src/ui/CookiePropertiesDialog.cpp" line="39"/>
        <source>Edit Cookie</source>
        <translation>Rediger kake</translation>
    </message>
</context>
<context>
    <name>Otter::CookiesContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="99"/>
        <source>Name:</source>
        <translation>Navn:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="109"/>
        <source>Value:</source>
        <translation>Verdi:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="116"/>
        <source>Expires:</source>
        <translation>Utløper:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="126"/>
        <source>Domain:</source>
        <translation>Domene:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="151"/>
        <source>Path:</source>
        <translation>Sti:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="165"/>
        <source>Add…</source>
        <translation>Legg til…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="175"/>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="359"/>
        <source>Properties…</source>
        <translation>Egenskaper…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.ui" line="185"/>
        <source>Delete</source>
        <translation>Slett</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="201"/>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="222"/>
        <source>Question</source>
        <translation>Spørsmål</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="202"/>
        <source>You are about to delete %n cookie(s).</source>
        <translation><numerusform>Du er i ferd med å slette én kake.</numerusform><numerusform>Du er i ferd med å slette én kake.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="203"/>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="224"/>
        <source>Do you want to continue?</source>
        <translation>Vil du fortsette?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="223"/>
        <source>You are about to delete all cookies.</source>
        <translation>Du er i ferd med å slette alle informasjonskapsler.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="335"/>
        <source>Add Cookie…</source>
        <translation>Legg til kake…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="346"/>
        <source>Remove All Cookies from This Domain…</source>
        <translation>Fjern alle kaker fra dette domenet…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="349"/>
        <source>Remove All Cookies…</source>
        <translation>Fjern alle informasjonskapsler</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="423"/>
        <source>this session only</source>
        <translation>kun for denne økta</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="447"/>
        <source>Cookies</source>
        <translation>Kaker</translation>
    </message>
</context>
<context>
    <name>Otter::CookiesExceptionsDialog</name>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="14"/>
        <source>Third-party Cookies Exceptions</source>
        <translation>Tredjepartskake-unntak</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="26"/>
        <source>Always ACCEPT third-party cookies from:</source>
        <translation>Alltid GODTA tredjepartskaker fra:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="44"/>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="106"/>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="51"/>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="113"/>
        <source>Edit</source>
        <translation>Rediger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="58"/>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="120"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/CookiesExceptionsDialog.ui" line="88"/>
        <source>Always REJECT third-party cookies from:</source>
        <translation>Alltid AVSLÅ tredjepartskaker fra:</translation>
    </message>
</context>
<context>
    <name>Otter::ErrorConsoleWidget</name>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="31"/>
        <source>Scope</source>
        <translation>Rekkevidde</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="60"/>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="163"/>
        <source>Network</source>
        <translation>Nettverk</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="76"/>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="167"/>
        <source>Security</source>
        <translation>Sikkerhet</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="92"/>
        <source>CSS</source>
        <translation>CSS</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="108"/>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="171"/>
        <source>JS</source>
        <translation>JS</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="124"/>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="175"/>
        <source>Other</source>
        <translation>Annet</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="156"/>
        <source>Clear</source>
        <translation>Tøm</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="185"/>
        <source>Filter…</source>
        <translation>Filtrer…</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.ui" line="195"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="60"/>
        <source>All Tabs</source>
        <translation>Alle faner</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="65"/>
        <source>Current Tab Only</source>
        <translation>Bare gjeldende fane</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="71"/>
        <source>Other Sources</source>
        <translation>Andre kilder</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="181"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;tom&gt;</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="272"/>
        <source>Copy</source>
        <translation>Kopier</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="279"/>
        <source>Expand All</source>
        <translation>Utvid alle</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/errorConsole/ErrorConsoleWidget.cpp" line="280"/>
        <source>Collapse All</source>
        <translation>Fold sammen alle</translation>
    </message>
</context>
<context>
    <name>Otter::Feed</name>
    <message>
        <location filename="../../src/core/FeedsManager.cpp" line="289"/>
        <source>Feed updated:
%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/FeedsManager.cpp" line="322"/>
        <source>Failed to parse feed: invalid feed type</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/FeedsManager.cpp" line="332"/>
        <source>Failed to download feed</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Otter::FeedPropertiesDialog</name>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="14"/>
        <source>Edit Feed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="22"/>
        <source>Folder:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="44"/>
        <source>New…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="53"/>
        <source>Title:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="80"/>
        <source>Change Icon…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="89"/>
        <source>Address:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="102"/>
        <source>Update interval:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="112"/>
        <source>Never</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.ui" line="115"/>
        <source> minutes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.cpp" line="50"/>
        <source>Add Feed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.cpp" line="80"/>
        <source>Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/FeedPropertiesDialog.cpp" line="80"/>
        <source>Valid address is required.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Otter::FeedsComboBoxWidget</name>
    <message>
        <location filename="../../src/ui/FeedsComboBoxWidget.cpp" line="41"/>
        <source>Folder Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/FeedsComboBoxWidget.cpp" line="41"/>
        <source>Select name of new folder:</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Otter::FeedsContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.ui" line="67"/>
        <source>OK</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.ui" line="74"/>
        <source>Cancel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.ui" line="107"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.ui" line="151"/>
        <source>Search…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.ui" line="161"/>
        <source>Categories</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="148"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="535"/>
        <source>Title</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="148"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="535"/>
        <source>From</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="148"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="535"/>
        <source>Published</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="194"/>
        <source>Question</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="195"/>
        <source>You already subscribed this feed.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="196"/>
        <source>Do you want to continue?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="214"/>
        <source>Select Folder Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="214"/>
        <source>Enter folder name:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="359"/>
        <source>Open</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="378"/>
        <source>Empty Trash</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="386"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="411"/>
        <source>Add Folder…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="387"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="412"/>
        <source>Add Feed…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="409"/>
        <source>Add New</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="421"/>
        <source>Restore Feed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="435"/>
        <source>Properties…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="477"/>
        <source>Send email to %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="479"/>
        <source>Go to %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="615"/>
        <source>All (%1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="665"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="802"/>
        <source>(Untitled)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="733"/>
        <source>Subscribe to this feed using:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="802"/>
        <source>Feed: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="805"/>
        <source>Feeds</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="912"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="921"/>
        <source>Title: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="912"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="925"/>
        <source>Address: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="916"/>
        <source>Last update: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Otter::FeedsModel</name>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="57"/>
        <source>Feeds</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="59"/>
        <source>Trash</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="63"/>
        <source>(Untitled)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="230"/>
        <source>Failed to open feeds file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="253"/>
        <source>Failed to load feeds file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="255"/>
        <source>Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/FeedsModel.cpp" line="255"/>
        <source>Failed to load feeds file.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Otter::FilePasswordsStorageBackend</name>
    <message>
        <location filename="../../src/modules/backends/passwords/file/FilePasswordsStorageBackend.cpp" line="53"/>
        <source>Failed to open passwords file: %1</source>
        <translation>Klarte ikke å åpne passordsfil: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/passwords/file/FilePasswordsStorageBackend.cpp" line="109"/>
        <source>Failed to save passwords file: %1</source>
        <translation>Klarte ikke å lagre passordfil: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/passwords/file/FilePasswordsStorageBackend.cpp" line="196"/>
        <source>Failed to remove passwords file</source>
        <translation>Klarte ikke å fjerne passordfil</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/passwords/file/FilePasswordsStorageBackend.cpp" line="325"/>
        <source>Encrypted File</source>
        <translation>Kryptert fil</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/passwords/file/FilePasswordsStorageBackend.cpp" line="330"/>
        <source>Stores passwords in AES encrypted file.</source>
        <translation>Lagre passord i AES-kryptert fil.</translation>
    </message>
</context>
<context>
    <name>Otter::FilePathWidget</name>
    <message>
        <location filename="../../src/ui/FilePathWidget.cpp" line="49"/>
        <location filename="../../src/ui/FilePathWidget.cpp" line="74"/>
        <source>Browse…</source>
        <translation>Utforsk…</translation>
    </message>
    <message>
        <location filename="../../src/ui/FilePathWidget.cpp" line="88"/>
        <source>Select File</source>
        <translation>Velg fil</translation>
    </message>
    <message>
        <location filename="../../src/ui/FilePathWidget.cpp" line="88"/>
        <source>Select Directory</source>
        <translation>Velg mappe</translation>
    </message>
</context>
<context>
    <name>Otter::FreeDesktopOrgPlatformIntegration</name>
    <message>
        <location filename="../../src/modules/platforms/freedesktoporg/FreeDesktopOrgPlatformIntegration.cpp" line="212"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/freedesktoporg/FreeDesktopOrgPlatformIntegration.cpp" line="216"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/freedesktoporg/FreeDesktopOrgPlatformIntegration.cpp" line="220"/>
        <source>Information</source>
        <translation>Informasjon</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/freedesktoporg/FreeDesktopOrgPlatformIntegration.cpp" line="230"/>
        <source>Notification</source>
        <translation>Merknad</translation>
    </message>
</context>
<context>
    <name>Otter::HandlersManager</name>
    <message>
        <location filename="../../src/core/HandlersManager.cpp" line="172"/>
        <source>Error</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/HandlersManager.cpp" line="172"/>
        <source>Profile with this address already exists.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/HandlersManager.cpp" line="174"/>
        <source>Question</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/HandlersManager.cpp" line="174"/>
        <source>Do you want to add this content blocking profile?</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Otter::HeaderViewWidget</name>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="65"/>
        <source>Sorting</source>
        <translation>Rekkefølge</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="66"/>
        <source>Sort Ascending</source>
        <translation>Sorter stigende</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="71"/>
        <source>Sort Descending</source>
        <translation>Sorter synkende</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="78"/>
        <source>No Sorting</source>
        <translation>Ingen sortering</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="91"/>
        <source>Visible Columns</source>
        <translation>Synlige kolonner</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="99"/>
        <source>Show All</source>
        <translation>Vis alle</translation>
    </message>
    <message>
        <location filename="../../src/ui/ItemViewWidget.cpp" line="111"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
</context>
<context>
    <name>Otter::HistoryContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Today</source>
        <translation>I dag</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Yesterday</source>
        <translation>I går</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Earlier This Week</source>
        <translation>Tidligere denne uken</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Previous Week</source>
        <translation>Foregående uke</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Earlier This Month</source>
        <translation>Tidligere denne måneden</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Earlier This Year</source>
        <translation>Tidligere dette året</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="45"/>
        <source>Older</source>
        <translation>Eldre</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="52"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="93"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="52"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="93"/>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="52"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="93"/>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="388"/>
        <source>Add to Bookmarks…</source>
        <translation>Legg til som bokmerke…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="389"/>
        <source>Copy Link to Clipboard</source>
        <translation>Kopier lenke til utklippstavle</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="393"/>
        <source>Remove Entry</source>
        <translation>Fjern oppføring</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="394"/>
        <source>Remove All Entries from This Domain</source>
        <translation>Fjern alle oppføringer tilknyttet dette domenet</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="431"/>
        <source>History</source>
        <translation>Historikk</translation>
    </message>
</context>
<context>
    <name>Otter::HistoryEntryItem</name>
    <message>
        <location filename="../../src/core/HistoryModel.cpp" line="58"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
</context>
<context>
    <name>Otter::HistoryModel</name>
    <message>
        <location filename="../../src/core/HistoryModel.cpp" line="90"/>
        <source>Failed to open history file: %1</source>
        <translation>Klarte ikke å åpne historikkfil: %1</translation>
    </message>
</context>
<context>
    <name>Otter::HtmlBookmarksImporter</name>
    <message>
        <location filename="../../src/modules/importers/html/HtmlBookmarksImporter.cpp" line="178"/>
        <source>HTML Bookmarks</source>
        <translation>HTML-bokmerker</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/html/HtmlBookmarksImporter.cpp" line="183"/>
        <source>Imports bookmarks from HTML file (Netscape format).</source>
        <translation>Importer bokmerker fra HTML-fil (Netscape-format).</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/html/HtmlBookmarksImporter.cpp" line="228"/>
        <source>HTML files (*.htm *.html)</source>
        <translation>HTML-filer (*.htm *.html)</translation>
    </message>
</context>
<context>
    <name>Otter::IconWidget</name>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="37"/>
        <location filename="../../src/ui/IconWidget.cpp" line="51"/>
        <location filename="../../src/ui/IconWidget.cpp" line="76"/>
        <location filename="../../src/ui/IconWidget.cpp" line="86"/>
        <source>Select Icon</source>
        <translation>Velg ikon</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="76"/>
        <source>Images (*.png *.jpg *.bmp *.gif *.svg *.svgz *.ico)</source>
        <translation>Bilder (*.png *.jpg *.bmp *.gif *.svg *.svgz *.ico)</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="86"/>
        <source>Icon Name:</source>
        <translation>Ikonnavn:</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="98"/>
        <source>Select From File…</source>
        <translation>Velg fra fil…</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="99"/>
        <source>Select From Theme…</source>
        <translation>Velg fra drakt…</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="105"/>
        <source>Reset</source>
        <translation>Tilbakestill</translation>
    </message>
    <message>
        <location filename="../../src/ui/IconWidget.cpp" line="113"/>
        <source>Clear</source>
        <translation>Tøm</translation>
    </message>
</context>
<context>
    <name>Otter::ImagePropertiesDialog</name>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="14"/>
        <source>Image Properties</source>
        <translation>Billedegenskaper</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="22"/>
        <source>Size:</source>
        <translation>Størrelse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="29"/>
        <source>Type:</source>
        <translation>Type:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="36"/>
        <source>File size:</source>
        <translation>Filstørrelse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="43"/>
        <source>Address:</source>
        <translation>Adresse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="50"/>
        <source>Alternative text:</source>
        <translation>Alternativ tekst:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.ui" line="57"/>
        <source>Long description:</source>
        <translation>Lang beskrivelse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="38"/>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="39"/>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="40"/>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="70"/>
        <source>%1 x %2 pixels @ %3 bits per pixel in %n frame(s)</source>
        <translation><numerusform>%1 x %2 piksler @ %3 bit per piksel i %n ramme</numerusform><numerusform>%1 x %2 piksler @ %3 bit per piksel i %n rammer</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="74"/>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="81"/>
        <source>%1 x %2 pixels @ %3 bits per pixel</source>
        <translation>%1 x %2 piksler @ %3 bit per piksel</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImagePropertiesDialog.cpp" line="85"/>
        <source>%1 x %2 pixels</source>
        <translation>%1 x %2 piksler</translation>
    </message>
</context>
<context>
    <name>Otter::ImportDialog</name>
    <message>
        <location filename="../../src/ui/ImportDialog.ui" line="42"/>
        <source>Options</source>
        <translation>Valg</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.ui" line="54"/>
        <source>Source:</source>
        <translation>Kilde:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.ui" line="98"/>
        <source>Results</source>
        <translation>Resultater</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.ui" line="123"/>
        <source>Initializing…</source>
        <translation>Igangsetter…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.ui" line="135"/>
        <source>%p% (%v/%m)</source>
        <translation>%p% (%v/%m)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="125"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="125"/>
        <source>Unable to import selected type.</source>
        <translation>Kunne ikke importere valgt type.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="158"/>
        <source>Processing…</source>
        <translation>Behandler…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="186"/>
        <source>Failed to import data.</source>
        <translation>Klarte ikke å importere data.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="190"/>
        <source>Import cancelled by the user.</source>
        <translation>Import avbrutt av bruker.</translation>
    </message>
    <message>
        <location filename="../../src/ui/ImportDialog.cpp" line="194"/>
        <source>Import finished successfully.</source>
        <translation>Import fullført.</translation>
    </message>
</context>
<context>
    <name>Otter::JavaScriptPreferencesDialog</name>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="14"/>
        <source>JavaScript Options</source>
        <translation>Valg for JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="26"/>
        <source>Allow moving and resizing of windows</source>
        <translation>Tillat flytting og endring av størrelse på vinduer</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="39"/>
        <source>Allow changing of status field</source>
        <translation>Tillat endring av statusfelt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="49"/>
        <source>Allow script to hide address bar</source>
        <translation>Tillat skript å gjemme adressefelt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="56"/>
        <source>Allow access to clipboard</source>
        <translation>Tillat tilgang til utklippstavle</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="63"/>
        <source>Allow to receive right mouse button clicks</source>
        <translation>Tillat å motta høyreklikk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="72"/>
        <source>Allow to close windows:</source>
        <translation>Tillat lukking av vinduer:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.ui" line="88"/>
        <source>Allow to enter full screen mode:</source>
        <translation>Tillat å gå inn i fullskjermsmodus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="37"/>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="40"/>
        <source>Ask</source>
        <translation>Spør</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="38"/>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="41"/>
        <source>Always</source>
        <translation>Alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="39"/>
        <location filename="../../src/ui/preferences/JavaScriptPreferencesDialog.cpp" line="42"/>
        <source>Never</source>
        <translation>Aldri</translation>
    </message>
</context>
<context>
    <name>Otter::KeyboardProfile</name>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="190"/>
        <location filename="../../src/core/ActionsManager.cpp" line="224"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
</context>
<context>
    <name>Otter::KeyboardProfileDialog</name>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="14"/>
        <source>Profile Configuration</source>
        <translation>Profilloppsett</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="24"/>
        <source>Actions</source>
        <translation>Handlinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="32"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="71"/>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="81"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="107"/>
        <source>Information</source>
        <translation>Informasjon</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="113"/>
        <source>Title:</source>
        <translation>Tittel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="123"/>
        <source>Description:</source>
        <translation>Beskrivelse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="133"/>
        <source>Version:</source>
        <translation>Versjon:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.ui" line="143"/>
        <source>Author:</source>
        <translation>Forfatter:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="233"/>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="270"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="233"/>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="270"/>
        <source>Action</source>
        <translation>Handling</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="233"/>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="270"/>
        <source>Parameters</source>
        <translation>Parameter</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="233"/>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="270"/>
        <source>Shortcut</source>
        <translation>Snarvei</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="390"/>
        <source>This shortcut already used by %1</source>
        <translation>Denne snarveien brukes allerede av %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="390"/>
        <source>unknown action</source>
        <translation>ukjent handling</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="401"/>
        <source>This shortcut cannot be used because it would be overriden by a native hotkey used by an editing action</source>
        <translation>Denne snarveien kan ikke brukes fordi den ville blitt overskrivet av en innebygget snarvei brukt av en redigeringshandling</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="409"/>
        <source>Single key shortcuts are currently disabled</source>
        <translation>Enkelttast-snarveier er for tiden avskrudd</translation>
    </message>
</context>
<context>
    <name>Otter::LinksContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="252"/>
        <source>Lock Panel</source>
        <translation>Lås panel</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="266"/>
        <source>Links</source>
        <translation>Lenker</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="318"/>
        <source>Title: %1</source>
        <translation>Tittel: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="321"/>
        <source>Address: %1</source>
        <translation>Adresse: %1</translation>
    </message>
</context>
<context>
    <name>Otter::LocalListingNetworkReply</name>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="61"/>
        <source>Directory does not exist</source>
        <translation>Mappa finnes allerede</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="66"/>
        <source>Directory is not readable</source>
        <translation>Mappa er ikke lesbar</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="67"/>
        <source>Cannot read directory listing</source>
        <translation>Kan ikke lese mappeopplisting</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="109"/>
        <source>Directory Contents</source>
        <translation>Mappeinnhold</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="112"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="113"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="114"/>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="115"/>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
</context>
<context>
    <name>Otter::LocaleDialog</name>
    <message>
        <location filename="../../src/ui/LocaleDialog.ui" line="14"/>
        <source>Switch Application Language</source>
        <translation>Bytt programspråk</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.ui" line="22"/>
        <source>Language:</source>
        <translation>Språk:</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.ui" line="32"/>
        <source>Custom path:</source>
        <translation>Brukervalgt sti:</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.ui" line="43"/>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.ui" line="48"/>
        <source>Custom</source>
        <translation>Tilpasset</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.cpp" line="47"/>
        <source>Unknown [%1]</source>
        <translation>Ukjent [%1]</translation>
    </message>
    <message>
        <location filename="../../src/ui/LocaleDialog.cpp" line="72"/>
        <source>Translation files (*.qm)</source>
        <translation>Oversettelsesfiler (*.qm)</translation>
    </message>
</context>
<context>
    <name>Otter::MacPlatformIntegration</name>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="370"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="374"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="378"/>
        <source>Information</source>
        <translation>Informasjon</translation>
    </message>
</context>
<context>
    <name>Otter::MainWindow</name>
    <message>
        <location filename="../../src/ui/MainWindow.cpp" line="832"/>
        <source>Question</source>
        <translation>Spørsmål</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/MainWindow.cpp" line="833"/>
        <source>You are about to open %n bookmark(s).</source>
        <translation><numerusform>Du er i ferd med å åpne ett bokmerke.</numerusform><numerusform>Du er i ferd med å åpne %n bokmerker.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/ui/MainWindow.cpp" line="834"/>
        <source>Do you want to continue?</source>
        <translation>Ønsker du å fortsette?</translation>
    </message>
    <message>
        <location filename="../../src/ui/MainWindow.cpp" line="838"/>
        <source>Do not show this message again</source>
        <translation>Ikke vis denne meldingen igjen</translation>
    </message>
    <message>
        <location filename="../../src/ui/MainWindow.cpp" line="2177"/>
        <source>Empty</source>
        <translation>Tom</translation>
    </message>
</context>
<context>
    <name>Otter::MasterPasswordDialog</name>
    <message>
        <location filename="../../src/ui/MasterPasswordDialog.ui" line="14"/>
        <source>Set Master Password</source>
        <translation>Sett hovedpassord</translation>
    </message>
    <message>
        <location filename="../../src/ui/MasterPasswordDialog.ui" line="22"/>
        <source>Current password:</source>
        <translation>Gjeldende passord:</translation>
    </message>
    <message>
        <location filename="../../src/ui/MasterPasswordDialog.ui" line="32"/>
        <source>New password:</source>
        <translation>Nytt passord:</translation>
    </message>
    <message>
        <location filename="../../src/ui/MasterPasswordDialog.ui" line="42"/>
        <source>Confirm new password:</source>
        <translation>Bekreft nytt passord:</translation>
    </message>
</context>
<context>
    <name>Otter::Menu</name>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="491"/>
        <location filename="../../src/ui/Menu.cpp" line="580"/>
        <source>Failed to create menu action: %1</source>
        <translation>Klarte ikke å opprette menyhandling: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="917"/>
        <source>Window - %1</source>
        <translation>Vindu - %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1173"/>
        <location filename="../../src/ui/Menu.cpp" line="1188"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/Menu.cpp" line="1188"/>
        <source>%1 (%n tab(s))</source>
        <translation><numerusform>%1 (%n fane)</numerusform><numerusform>%1 (%n faner)</numerusform></translation>
    </message>
</context>
<context>
    <name>Otter::MenuButtonWidget</name>
    <message>
        <location filename="../../src/modules/widgets/menuButton/MenuButtonWidget.cpp" line="35"/>
        <source>Menu</source>
        <translation>Meny</translation>
    </message>
</context>
<context>
    <name>Otter::Migrator</name>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="586"/>
        <source>Settings Migration</source>
        <translation>Innstillingsflytting</translation>
    </message>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="589"/>
        <source>Configuration of the components listed below needs to be updated to new version.
Do you want to migrate it?</source>
        <translation>Oppsettet av komponentene listet opp nedenfor trenger å oppdateres til ny versjon.
Ønsker du å migrere det?</translation>
    </message>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="612"/>
        <source>Create backup</source>
        <translation>Opprett sikkerhetskopi</translation>
    </message>
</context>
<context>
    <name>Otter::MouseProfile</name>
    <message>
        <location filename="../../src/core/GesturesManager.cpp" line="493"/>
        <location filename="../../src/core/GesturesManager.cpp" line="532"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
</context>
<context>
    <name>Otter::MouseProfileDialog</name>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="14"/>
        <source>Profile Configuration</source>
        <translation>Profiloppsett:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="24"/>
        <source>Actions</source>
        <translation>Handlinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="30"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="78"/>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="144"/>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="88"/>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="154"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="169"/>
        <source>Move Up</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="186"/>
        <source>Move Down</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="200"/>
        <source>Information</source>
        <translation>Informasjon</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="206"/>
        <source>Title:</source>
        <translation>Tittel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="216"/>
        <source>Description:</source>
        <translation>Beskrivelse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="226"/>
        <source>Version:</source>
        <translation>Versjon:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.ui" line="236"/>
        <source>Author:</source>
        <translation>Forfatter:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Generic</source>
        <translation>Hovedinnstillinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Link</source>
        <translation>Lenke</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Editable Content</source>
        <translation>Redigerbart innhold</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Tab Handle</source>
        <translation>Ikon og adresse på fane</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Tab Handle of Active Tab</source>
        <translation>Ikon og adresse på aktiv fane</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Empty Area of Tab Bar</source>
        <translation>Tomt område i faneområde</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="81"/>
        <source>Any Toolbar</source>
        <translation>Enhver verkrøylinje</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="139"/>
        <source>Context and Action</source>
        <translation>Bindeleddsinformasjon og handling</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="139"/>
        <source>Parameters</source>
        <translation>Parameter</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="139"/>
        <source>Steps</source>
        <translation>Steg</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="143"/>
        <source>Step</source>
        <translation>Steg</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/MouseProfileDialog.cpp" line="201"/>
        <source>Select Action</source>
        <translation>Velg handling</translation>
    </message>
</context>
<context>
    <name>Otter::NavigationActionWidget</name>
    <message>
        <location filename="../../src/modules/widgets/action/ActionWidget.cpp" line="340"/>
        <source>Remove Entry</source>
        <translation>Fjern oppføring</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/action/ActionWidget.cpp" line="343"/>
        <source>Purge Entry</source>
        <translation>Fjern oppføring</translation>
    </message>
</context>
<context>
    <name>Otter::NetworkAutomaticProxy</name>
    <message>
        <location filename="../../src/core/NetworkAutomaticProxy.cpp" line="322"/>
        <location filename="../../src/core/NetworkAutomaticProxy.cpp" line="342"/>
        <source>Failed to load proxy auto-config (PAC): %1</source>
        <translation>Klarte ikke å laste automatisk oppsett for mellomtjener (PAC): %1</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkAutomaticProxy.cpp" line="357"/>
        <source>Failed to load proxy auto-config (PAC). Invalid URL: %1</source>
        <translation>Klarte ikke å laste automatisk oppsett for mellomtjener (PAC): Ugyldig nettadresse: %1</translation>
    </message>
</context>
<context>
    <name>Otter::NetworkManager</name>
    <message>
        <location filename="../../src/core/NetworkManager.cpp" line="125"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkManager.cpp" line="125"/>
        <source>SSL errors occurred:

%1

Do you want to continue?</source>
        <translation>SSL-feil inntraff:

%1

Vil du fortsette?</translation>
    </message>
</context>
<context>
    <name>Otter::NetworkManagerFactory</name>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.cpp" line="708"/>
        <source>Custom</source>
        <translation>Tilpasset</translation>
    </message>
</context>
<context>
    <name>Otter::NotesContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.ui" line="98"/>
        <source>Address:</source>
        <translation>Adresse:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.ui" line="105"/>
        <source>Date:</source>
        <translation>Dato:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.ui" line="136"/>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.ui" line="146"/>
        <source>Delete</source>
        <translation>Slett</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="48"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="164"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="195"/>
        <source>Add Folder…</source>
        <translation>Legg til mappe…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="49"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="165"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="193"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="196"/>
        <source>Add Note</source>
        <translation>Legg til notat</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="50"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="166"/>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="197"/>
        <source>Add Separator</source>
        <translation>Legg til inndeling</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="60"/>
        <source>Add note…</source>
        <translation>Legg til notat…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="106"/>
        <source>Select Folder Name</source>
        <translation>Velg mappenavn…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="106"/>
        <source>Enter folder name:</source>
        <translation>Skriv inn mappenavn:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="156"/>
        <source>Empty Trash</source>
        <translation>Tøm papirkurv</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="181"/>
        <source>Open source page</source>
        <translation>Vis kildekodeside</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="206"/>
        <source>Restore Note</source>
        <translation>Gjenopprett notat</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="340"/>
        <source>Notes</source>
        <translation>Notater</translation>
    </message>
</context>
<context>
    <name>Otter::NotificationDialog</name>
    <message>
        <location filename="../../src/ui/NotificationDialog.cpp" line="74"/>
        <location filename="../../src/ui/NotificationDialog.cpp" line="122"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
</context>
<context>
    <name>Otter::OpenAddressDialog</name>
    <message>
        <location filename="../../src/ui/OpenAddressDialog.ui" line="14"/>
        <source>Go to Page</source>
        <translation>Surf til siden</translation>
    </message>
    <message>
        <location filename="../../src/ui/OpenAddressDialog.ui" line="20"/>
        <source>Enter a web address or choose one from the list:</source>
        <translation>Skriv inn en nettadresse, eller velg en fra listen:</translation>
    </message>
</context>
<context>
    <name>Otter::OpenBookmarkDialog</name>
    <message>
        <location filename="../../src/ui/OpenBookmarkDialog.ui" line="14"/>
        <source>Go to Bookmark</source>
        <translation>Gå til bokmerke</translation>
    </message>
    <message>
        <location filename="../../src/ui/OpenBookmarkDialog.ui" line="20"/>
        <source>Enter the keyword of bookmark:</source>
        <translation>Skriv inn nøkkelord tilhørende bokmerke:</translation>
    </message>
</context>
<context>
    <name>Otter::OperaBookmarksImporter</name>
    <message>
        <location filename="../../src/modules/importers/opera/OperaBookmarksImporter.cpp" line="51"/>
        <source>Opera Bookmarks</source>
        <translation>Opera-bokmerker</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaBookmarksImporter.cpp" line="56"/>
        <source>Imports bookmarks from Opera Browser version 12 or earlier</source>
        <translation>Importer bokmerker fra Opera nettleser versjon 12 eller tidligere</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaBookmarksImporter.cpp" line="101"/>
        <source>Opera bookmarks files (bookmarks.adr)</source>
        <translation>Bokmerkefiler fra Opera (bookmarks.adr)</translation>
    </message>
</context>
<context>
    <name>Otter::OperaNotesImporter</name>
    <message>
        <location filename="../../src/modules/importers/opera/OperaNotesImporter.cpp" line="57"/>
        <source>Import into folder:</source>
        <translation>Importer til mappe:</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaNotesImporter.cpp" line="65"/>
        <source>Opera Notes</source>
        <translation>Opera-notater</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaNotesImporter.cpp" line="70"/>
        <source>Imports notes from Opera Browser version 12 or earlier</source>
        <translation>Importer notater fra Opera-nettleseren, versjon 12 eller tidligere</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaNotesImporter.cpp" line="115"/>
        <source>Opera notes files (notes.adr)</source>
        <translation>Opera-notatfiler (notes.adr)</translation>
    </message>
</context>
<context>
    <name>Otter::OperaSearchEnginesImporter</name>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSearchEnginesImporter.cpp" line="45"/>
        <source>Remove existing search engines</source>
        <translation>Fjern eksisterende søkemotorer</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSearchEnginesImporter.cpp" line="54"/>
        <source>Opera search engines</source>
        <translation>Opera-søkemotorer</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSearchEnginesImporter.cpp" line="59"/>
        <source>Imports search engines from Opera Browser version 12 or earlier</source>
        <translation>Importer søkemotorer fra Opera-nettleseren versjon 12 eller tidligere</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSearchEnginesImporter.cpp" line="105"/>
        <source>Opera search engines files (search.ini)</source>
        <translation>Opera-søkemotorfiler (search.ini)</translation>
    </message>
</context>
<context>
    <name>Otter::OperaSessionImporter</name>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSessionImporter.cpp" line="44"/>
        <source>Opera Session</source>
        <translation>Opera-økt</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSessionImporter.cpp" line="49"/>
        <source>Imports session from Opera Browser version 12 or earlier</source>
        <translation>Importer økt fra Opera-nettleseren, versjon 12 eller tidligere</translation>
    </message>
    <message>
        <location filename="../../src/modules/importers/opera/OperaSessionImporter.cpp" line="94"/>
        <source>Opera session files (*.win)</source>
        <translation>Opera-øktfiler (*.win)</translation>
    </message>
</context>
<context>
    <name>Otter::OpmlImporter</name>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporter.cpp" line="84"/>
        <source>OPML Feeds</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporter.cpp" line="89"/>
        <source>Imports feeds from OPML file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporter.cpp" line="119"/>
        <source>OPML files (*.opml)</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Otter::OpmlImporterWidget</name>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporterWidget.ui" line="22"/>
        <source>Import into folder:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporterWidget.ui" line="41"/>
        <source>New…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/importers/opml/OpmlImporterWidget.ui" line="52"/>
        <source>Allow to duplicate already existing feeds</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Otter::OptionWidget</name>
    <message>
        <location filename="../../src/ui/OptionWidget.cpp" line="50"/>
        <source>No</source>
        <translation>Nei</translation>
    </message>
    <message>
        <location filename="../../src/ui/OptionWidget.cpp" line="51"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../../src/ui/OptionWidget.cpp" line="194"/>
        <source>Defaults</source>
        <translation>Forvalg</translation>
    </message>
</context>
<context>
    <name>Otter::PageInformationContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="42"/>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="110"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="42"/>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="110"/>
        <source>Value</source>
        <translation>Verdi</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="136"/>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="137"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;tom&gt;</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="158"/>
        <source>General</source>
        <translation>Hovedinnstillinger</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="164"/>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="168"/>
        <source>MIME type</source>
        <translation>MIME-type</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="169"/>
        <source>Document size</source>
        <translation>Dokumentstørrelse</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="170"/>
        <source>Total size</source>
        <translation>Total størrelse</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="174"/>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="178"/>
        <source>Number of requests</source>
        <translation>Antall forespørsler</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="174"/>
        <source>%1 (%n blocked)</source>
        <translation><numerusform>%1 (%n blokkert)</numerusform><numerusform>%1 (%n blokkert)</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="181"/>
        <source>Downloaded</source>
        <translation>Nedlastet</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="187"/>
        <source>Headers</source>
        <translation>Hoder</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="202"/>
        <source>Meta</source>
        <translation>Meta</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="220"/>
        <source>Permissions</source>
        <translation>Tilganger</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="224"/>
        <source>Security</source>
        <translation>Sikkerhet</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="232"/>
        <source>Cipher protocol</source>
        <translation>Krypteringsprotokoll</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="233"/>
        <source>Cipher authentication method</source>
        <translation>Krypteringsautentiseringsmetode:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="234"/>
        <source>Cipher encryption method</source>
        <translation>Krypteringsalgoritmemetode</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="235"/>
        <source>Cipher key exchange method</source>
        <translation>Krypteringsnøkkelutvekslingsmetode</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/pageInformation/PageInformationContentsWidget.cpp" line="262"/>
        <source>Page Information</source>
        <translation>Sideinformasjon</translation>
    </message>
</context>
<context>
    <name>Otter::PasswordBarWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.ui" line="61"/>
        <source>Save</source>
        <translation>Lagre</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.ui" line="68"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.cpp" line="37"/>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.cpp" line="55"/>
        <source>Do you want to update login data for %1?</source>
        <translation>Ønsker du å oppdatere innloggingsdata for %1?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.cpp" line="37"/>
        <location filename="../../src/modules/windows/web/PasswordBarWidget.cpp" line="55"/>
        <source>Do you want to save login data for %1?</source>
        <translation>Ønsker du å lagre innloggingsdata for %1?</translation>
    </message>
</context>
<context>
    <name>Otter::PasswordsContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="70"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="77"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="70"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="77"/>
        <source>Value</source>
        <translation>Verdi</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="91"/>
        <source>Set #%1</source>
        <translation>Sett #%1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="179"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="235"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="254"/>
        <source>Question</source>
        <translation>Spørsmål</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="180"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="236"/>
        <source>You are about to delete %n password(s).</source>
        <translation><numerusform>Du er i ferd med å slette ett passord.</numerusform><numerusform>Du er i ferd med å slette %n passord.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="181"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="237"/>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="256"/>
        <source>Do you want to continue?</source>
        <translation>Vil du fortsette?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="255"/>
        <source>You are about to delete all passwords.</source>
        <translation>Du er i ferd med å slette alle passord.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="277"/>
        <source>Remove Password</source>
        <translation>Fjern passord</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="280"/>
        <source>Remove All Passwords from This Domain…</source>
        <translation>Fjern alle passord fra dette domenet…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="283"/>
        <source>Remove All Passwords…</source>
        <translation>Fjern alle passord…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/passwords/PasswordsContentsWidget.cpp" line="369"/>
        <source>Passwords</source>
        <translation>Passord</translation>
    </message>
</context>
<context>
    <name>Otter::PermissionBarWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.ui" line="62"/>
        <source>Allow this time</source>
        <translation>Tillat denne gangen</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.ui" line="67"/>
        <source>Always allow</source>
        <translation>Alltid tillat</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.ui" line="72"/>
        <source>Always deny</source>
        <translation>Alltid nekt</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.ui" line="80"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.ui" line="87"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="66"/>
        <source>%1 wants to enter full screen mode.</source>
        <translation>%1 ønsker å gå inn i fullskjermsmodus.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="71"/>
        <source>%1 wants access to your location.</source>
        <translation>%1 vil ha tilgang til din plassering.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="76"/>
        <source>%1 wants to show notifications.</source>
        <translation>%1 ønsker å vise merknader.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="81"/>
        <source>%1 wants to lock mouse pointer.</source>
        <translation>%1 ønsker å låse musepekeren.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="86"/>
        <source>%1 wants to access your microphone.</source>
        <translation>%1 ønsker å få tilgang til din mikrofon.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="91"/>
        <source>%1 wants to access your camera.</source>
        <translation>%1 ønsker å få tilgang til ditt kamera.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="96"/>
        <source>%1 wants to access your microphone and camera.</source>
        <translation>%1 ønsker å få tilgang til din mikrofon og ditt kamera.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="101"/>
        <source>%1 wants to play audio.</source>
        <translation>%1 ønsker å spille lyd.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PermissionBarWidget.cpp" line="106"/>
        <source>Invalid permission request from %1.</source>
        <translation>Ugyldig tilgangsforespørsel fra %1.</translation>
    </message>
</context>
<context>
    <name>Otter::PlatformIntegration</name>
    <message>
        <location filename="../../src/core/PlatformIntegration.cpp" line="137"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/core/PlatformIntegration.cpp" line="137"/>
        <source>Failed to install update.</source>
        <translation>Klarte ikke å installere oppdatering.</translation>
    </message>
</context>
<context>
    <name>Otter::PopupsBarWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.ui" line="61"/>
        <source>Details</source>
        <translation>Detaljer</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.ui" line="71"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="62"/>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="70"/>
        <source>%1 wants to open %n pop-up window(s).</source>
        <translation><numerusform>%1 ønsker å åpne ett oppsprettsvindu.</numerusform><numerusform>%1 ønsker å åpne %n oppsprettsvinduer.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="104"/>
        <source>Open All Pop-Ups from This Website</source>
        <translation>Åpne alle oppsprettsvindu fra dette nettstedet.</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="104"/>
        <source>Open Pop-Ups from This Website in Background</source>
        <translation>Åpne oppsprettsvindu fra dette nettstedet i bakgrunnen</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="104"/>
        <source>Block All Pop-Ups from This Website</source>
        <translation>Blokker alle oppsprettsvindu fra dette nettstedet</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="104"/>
        <source>Always Ask What to Do for This Website</source>
        <translation>Alltid spør hva jeg ønsker å gjøre på dette nettstedet</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="118"/>
        <source>Blocked Pop-ups</source>
        <translation>Blokkerte oppsprettsvinduer</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/PopupsBarWidget.cpp" line="119"/>
        <source>Open All</source>
        <translation>Åpne alle</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesAdvancedPageWidget</name>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="55"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="374"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="768"/>
        <source>General</source>
        <translation>Hovedinnstillinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="62"/>
        <source>Smooth scrolling</source>
        <translation>Jevn rulling</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="69"/>
        <source>Check spelling</source>
        <translation>Sjekk staving</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="82"/>
        <source>Address Field Suggestions</source>
        <translation>Adressefeltforslag</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="91"/>
        <source>Suggest bookmarks</source>
        <translation>Foreslå bokmerker</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="98"/>
        <source>Suggest history</source>
        <translation>Foreslå historikk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="108"/>
        <source>Suggest search results</source>
        <translation>Foreslå søkeresultater</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="115"/>
        <source>Local paths</source>
        <translation>Lokale stier</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="130"/>
        <source>Address Completion</source>
        <translation>Adressefullføring</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="139"/>
        <source>Show category headers</source>
        <translation>Vis kategorihoder</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="148"/>
        <source>Display mode:</source>
        <translation>Visningsmodus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="185"/>
        <source>Events</source>
        <translation>Hendelser</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="225"/>
        <source>Play sound:</source>
        <translation>Spill lyd:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="240"/>
        <source>Show notification</source>
        <translation>Vis merknad</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="247"/>
        <source>Mark taskbar entry</source>
        <translation>Merk oppgavelinjeoppføring</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="263"/>
        <source>Options</source>
        <translation>Valg</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="270"/>
        <source>Prefer native notifications</source>
        <translation>Foretrekk systemets merknadsstil</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="300"/>
        <source>Style</source>
        <translation>Stil</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="309"/>
        <source>Widget style:</source>
        <translation>Miniprogramstil:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="319"/>
        <source>Interface style sheet:</source>
        <translation>Stilsett for grensesnitt:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="343"/>
        <source>Other</source>
        <translation>Annet</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="350"/>
        <source>Show tray icon</source>
        <translation>Vis systemkurv</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="383"/>
        <source>Images:</source>
        <translation>Bilder:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="397"/>
        <source>Enable JavaScript</source>
        <translation>Skru på JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="404"/>
        <source>JavaScript Options…</source>
        <translation>Valg for JavaScript…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="415"/>
        <source>Plugins:</source>
        <translation>Program-tillegg:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="425"/>
        <source>User style sheet:</source>
        <translation>Brukerstyrt stilsett:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="443"/>
        <source>Website Preferences</source>
        <translation>Nettsideinnstillinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="454"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="481"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="559"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="821"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="904"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1016"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1239"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1392"/>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="491"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="831"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="914"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1249"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1402"/>
        <source>Edit…</source>
        <translation>Rediger…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="501"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="569"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="841"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="924"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1026"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1269"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1422"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="535"/>
        <source>MIME Types</source>
        <translation>MIME-typer</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="611"/>
        <source>Show download dialog</source>
        <translation>Vis nedlastningsdialogvindu</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="621"/>
        <source>Save to disk</source>
        <translation>Lagre til disk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="664"/>
        <source>Do not ask for folder, save directly to</source>
        <translation>Ikke spør om mappe, lagre direkte i</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="679"/>
        <source>Open with application</source>
        <translation>Åpne med program</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="725"/>
        <source>Pass web address directly to application</source>
        <translation>Send nettadresse direkte til program</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="775"/>
        <source>Send referrer information</source>
        <translation>Send henvendelsesinformasjon (referent)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="788"/>
        <source>User Agent</source>
        <translation>Brukeragent</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="871"/>
        <source>Proxy</source>
        <translation>Mellomtjener</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="971"/>
        <source>SSL Ciphers</source>
        <translation>SSL-krypteringsalgoritmer</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1051"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1294"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1447"/>
        <source>Move Up</source>
        <translation>Flytt opp</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1077"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1320"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1473"/>
        <source>Move Down</source>
        <translation>Flytt ned</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1100"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Updates</source>
        <translation>Oppdateringer</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1107"/>
        <source>Select channels from which you want to receive updates:</source>
        <translation>Velg kanaler du ønsker å motta oppdateringer fra:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1149"/>
        <source>Check for updates every</source>
        <translation>Se etter oppdateringer hver</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1159"/>
        <source>day(s)</source>
        <translation>dag(er)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1168"/>
        <source>Install updates automatically</source>
        <translation>Installer oppdateringer automatisk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1200"/>
        <source>Keyboard Shortcuts</source>
        <translation>Tastatursnarveier</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1259"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1412"/>
        <source>Clone</source>
        <translation>Klon</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1333"/>
        <source>Enable single key shortcuts</source>
        <translation>Skru på enkelttasttastatursnarveier</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1353"/>
        <source>Mouse Actions and Gestures</source>
        <translation>Musehandlinger og håndvendinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.ui" line="1486"/>
        <source>Enable mouse gestures</source>
        <translation>Skru på musehåndvendinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Browsing</source>
        <translation>Surfing</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Notifications</source>
        <translation>Merknader</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Appearance</source>
        <translation>Utseende</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Content</source>
        <translation>Innhold</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Downloads</source>
        <translation>Nedlastinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Programs</source>
        <translation>Programmer</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>History</source>
        <translation>Historikk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Network</source>
        <translation>Nettverk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Security</source>
        <translation>Sikkerhet</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Keyboard</source>
        <translation>Tastatur</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="66"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="453"/>
        <source>Mouse</source>
        <translation>Mus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="107"/>
        <source>Compact</source>
        <translation>Kompakt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="108"/>
        <source>Columns</source>
        <translation>Kolonner</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="115"/>
        <source>WAV files (*.wav)</source>
        <translation>WAV-filer (*.wav)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="118"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="186"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="118"/>
        <source>Description</source>
        <translation>Beskrivelse</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="140"/>
        <source>System Style</source>
        <translation>Systemstil</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="149"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="169"/>
        <source>Style sheets (*.css)</source>
        <translation>Stilsett (*.css)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="152"/>
        <source>All images</source>
        <translation>Alle bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="153"/>
        <source>Cached images</source>
        <translation>Hurtiglagrede bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="154"/>
        <source>No images</source>
        <translation>Ingen bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="161"/>
        <source>Enabled</source>
        <translation>Påskrudd</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="162"/>
        <source>On demand</source>
        <translation>Ved behov</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="163"/>
        <source>Disabled</source>
        <translation>Avskrudd</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="209"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="224"/>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="209"/>
        <source>Value</source>
        <translation>Verdi</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="217"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="232"/>
        <source>Add Folder…</source>
        <translation>Legg til mappe…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="218"/>
        <source>Add User Agent…</source>
        <translation>Legg til brukeragent…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="219"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="234"/>
        <source>Add Separator</source>
        <translation>Legg til inndeling</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="233"/>
        <source>Add Proxy…</source>
        <translation>Legg til mellomtjener…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="291"/>
        <source>Stable version</source>
        <translation>Stabil versjon</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="291"/>
        <source>Beta version</source>
        <translation>Beta-versjon</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="291"/>
        <source>Weekly development version</source>
        <translation>Ukentlig utviklingsversjon</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="339"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="375"/>
        <source>New…</source>
        <translation>Ny…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="340"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="376"/>
        <source>Readd</source>
        <translation>Legg til igjen</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="576"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1265"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1460"/>
        <source>Question</source>
        <translation>Spørsmål</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="576"/>
        <source>Do you really want to remove preferences for this website?</source>
        <translation>Ønsker du virkelig å fjerne innstillingene for denne nettsiden?</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="594"/>
        <source>MIME Type Name</source>
        <translation>MIME-typenavn</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="594"/>
        <source>Select name of MIME Type:</source>
        <translation>Velg navn for MIME-type:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="614"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="614"/>
        <source>Invalid MIME Type name.</source>
        <translation>Ugyldig MIME-typenavn</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="739"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="801"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="905"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="967"/>
        <source>Folder Name</source>
        <translation>Mappenavn</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="739"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="801"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="905"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="967"/>
        <source>Select folder name:</source>
        <translation>Velg mappenavn:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="743"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="767"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="805"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="822"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="909"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="934"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="971"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="987"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1156"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1351"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="757"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="923"/>
        <source>Custom</source>
        <translation>Egendefinert</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1266"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1461"/>
        <source>Do you really want to remove this profile?</source>
        <translation>Ønsker du å fjerne denne profilen?</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1275"/>
        <location filename="../../src/ui/preferences/PreferencesAdvancedPageWidget.cpp" line="1470"/>
        <source>Delete profile permanently</source>
        <translation>Slett profil for godt</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesContentPageWidget</name>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="23"/>
        <source>Blocking</source>
        <translation>Blokkering</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="35"/>
        <source>Pop-ups:</source>
        <translation>Oppsprettsvinduer:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="56"/>
        <source>Zoom</source>
        <translation>Forstørr</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="68"/>
        <source>Default zoom:</source>
        <translation>Forvalgt forstørrelsesnivå:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="78"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="96"/>
        <source>Zoom text only</source>
        <translation>Bare forstørr tekst</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="109"/>
        <source>Fonts</source>
        <translation>Skrifter</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="143"/>
        <source>Default proportional font size:</source>
        <translation>Forvalgt proposjonal tekststørrelse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="153"/>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="179"/>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="208"/>
        <source> px</source>
        <translation>px</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="169"/>
        <source>Default fixed-width font size:</source>
        <translation>Forvalgt fastbreddeskriftstørrelse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="195"/>
        <source>Minimum font size:</source>
        <translation>Minimal skriftstørrelse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="205"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.ui" line="229"/>
        <source>Colors</source>
        <translation>Farger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="119"/>
        <source>Ask</source>
        <translation>Spør</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="120"/>
        <source>Block all</source>
        <translation>Blokker alle</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="121"/>
        <source>Open all</source>
        <translation>Åpne alle</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="122"/>
        <source>Open all in background</source>
        <translation>Åpne alle i bakgrunn</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="134"/>
        <source>Style</source>
        <translation>Stil</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="134"/>
        <source>Font</source>
        <translation>Skrift</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="134"/>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="157"/>
        <source>Preview</source>
        <translation>Forhåndsvis</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Standard font</source>
        <translation>Forvalgt skrift</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Fixed-width font</source>
        <translation>Fastbreddeskrift</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Serif font</source>
        <translation>Skrift med seriffer</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Sans-serif font</source>
        <translation>Skrift uten seriffer</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Cursive font</source>
        <translation>Kursiv skrift</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="138"/>
        <source>Fantasy font</source>
        <translation>Fantasi-skrift</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="143"/>
        <source>The quick brown fox jumps over the lazy dog</source>
        <translation>Den raske brunreven hopper over den late hunden</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="157"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="161"/>
        <source>Background Color</source>
        <translation>Bakgrunnsfarge</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="161"/>
        <source>Text Color</source>
        <translation>Tekstfarge</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="161"/>
        <source>Link Color</source>
        <translation>Lenkefarge</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesContentPageWidget.cpp" line="161"/>
        <source>Visited Link Color</source>
        <translation>Farge for besøkte sider</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesDialog</name>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="17"/>
        <source>Preferences</source>
        <translation>Innstillinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="27"/>
        <source>General</source>
        <translation>Hovedinnstillinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="33"/>
        <source>Content</source>
        <translation>Innhold</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="39"/>
        <source>Privacy</source>
        <translation>Personvern</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="45"/>
        <source>Search</source>
        <translation>Søk</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="51"/>
        <source>Advanced</source>
        <translation>Avansert</translation>
    </message>
    <message>
        <location filename="../../src/ui/PreferencesDialog.ui" line="62"/>
        <source>All Settings</source>
        <translation>Alle innstillinger</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesGeneralPageWidget</name>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="23"/>
        <source>Startup</source>
        <translation>Oppstart</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="35"/>
        <source>Startup behavior:</source>
        <translation>Oppstartsoppførsel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="48"/>
        <source>Home page:</source>
        <translation>Hjemmeside:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="76"/>
        <source>Use Current Page</source>
        <translation>Bruk gjeldende side</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="83"/>
        <source>Use Bookmark</source>
        <translation>Bruk bokmerke</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="90"/>
        <source>Restore to Default</source>
        <translation>Gjenopprett til forvalg</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="99"/>
        <source>Do not load the tab contents until selected</source>
        <translation>Ikke last inn faneinnholdet før den velges</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="114"/>
        <source>Downloads</source>
        <translation>Nedlastinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="126"/>
        <source>Save files to:</source>
        <translation>Lagre filer til:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="141"/>
        <source>Always ask me where to save files</source>
        <translation>Alltid spør meg om hvor filer skal lagres</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="154"/>
        <source>Tabs</source>
        <translation>Faner</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="161"/>
        <source>Open new windows in new tabs instead</source>
        <translation>Åpne nye vinduer i faner i faner istedenfor</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="168"/>
        <source>Reuse current tab</source>
        <translation>Gjenbruk gjeldende fane</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="175"/>
        <source>Open new tab next to active</source>
        <translation>Åpne ny fane ved siden av aktiv</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="184"/>
        <source>When closing tab:</source>
        <translation>Når fane lukkes:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="198"/>
        <source>Activate the last active tab</source>
        <translation>Aktiver siste aktive fane</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="203"/>
        <source>Activate the next tab</source>
        <translation>Aktiver neste fane</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="208"/>
        <source>Activate the first tab opened from current tab</source>
        <translation>Aktiver første fane åpnet fra nåværende fane</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="224"/>
        <source>Language</source>
        <translation>Språk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="233"/>
        <source>Preferred webpage language:</source>
        <translation>Foretrukket språk for nettsider:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="258"/>
        <source>Edit…</source>
        <translation>Rediger…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="275"/>
        <source>System Defaults</source>
        <translation>Systemforvalg</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.ui" line="287"/>
        <source>Set as a default browser</source>
        <translation>Velg som forvalgt nettleser</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.cpp" line="45"/>
        <source>Show windows and tabs from the last time</source>
        <translation>Vis vinduer og faner fra forrige gang</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.cpp" line="46"/>
        <source>Show startup dialog</source>
        <translation>Vis oppstartsdialogvindu</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.cpp" line="47"/>
        <source>Show home page</source>
        <translation>Vis oppstartside</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.cpp" line="48"/>
        <source>Show start page</source>
        <translation>Vis oppstartside</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesGeneralPageWidget.cpp" line="49"/>
        <source>Show empty page</source>
        <translation>Vis tom side</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesPrivacyPageWidget</name>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="23"/>
        <source>Tracking</source>
        <translation>Sporing</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="32"/>
        <source>Do Not Track:</source>
        <translation>Ikke spor meg:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="57"/>
        <source>History</source>
        <translation>Historikk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="64"/>
        <source>Private mode</source>
        <translation>Privat modus</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="107"/>
        <source>Remember browsing history</source>
        <translation>Husk surfehistorikk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="114"/>
        <source>Remember downloads history</source>
        <translation>Husk nedlastings-historikk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="124"/>
        <source>Remember search history</source>
        <translation>Husk søkehistorikk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="136"/>
        <source>Remember form history</source>
        <translation>Husk skjema-historikk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="159"/>
        <source>Template…</source>
        <translation>Mal…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="170"/>
        <source>Enable cookies</source>
        <translation>Skru på informasjonskapsler</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="215"/>
        <source>Accept cookies:</source>
        <translation>Tillat informasjonskapsler:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="228"/>
        <source>Keep until:</source>
        <translation>Behold til:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="241"/>
        <source>Accept third-party cookies:</source>
        <translation>Tillat tredjeparts informasjonskapsler:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="263"/>
        <source>Exceptions…</source>
        <translation>Unntak…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="279"/>
        <source>Clear history when application closes</source>
        <translation>Tøm historikk når programmet lukkes</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="299"/>
        <source>Settings…</source>
        <translation>Innstillinger…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="319"/>
        <source>Passwords</source>
        <translation>Passord</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="328"/>
        <source>Remember passwords</source>
        <translation>Husk passord</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="348"/>
        <source>Manage…</source>
        <translation>Behandle…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="362"/>
        <source>Use a master password</source>
        <translation>Bruk et hovedpassord</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.ui" line="385"/>
        <source>Change…</source>
        <translation>Endre…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="40"/>
        <source>Inform websites that I do not want to be tracked</source>
        <translation>Gi nettsteder beskjed om at jeg ikke ønsker å bli sporet</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="41"/>
        <source>Inform websites that I allow tracking</source>
        <translation>Gi nettsteder beskjed om at jeg tillater sporing</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="42"/>
        <source>Do not inform websites about my preference</source>
        <translation>Ikke gi nettsteder beskjed om min preferanse</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="53"/>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="67"/>
        <source>Always</source>
        <translation>Alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="54"/>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="68"/>
        <source>Only existing</source>
        <translation>Bare eksisterende</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="55"/>
        <source>Only read existing</source>
        <translation>Bare les eksisterende</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="60"/>
        <source>Expires</source>
        <translation>Utløper</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="61"/>
        <source>Current session is closed</source>
        <translation>Nåværende økt lukket</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="62"/>
        <source>Always ask</source>
        <translation>Alltid spør</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesPrivacyPageWidget.cpp" line="69"/>
        <source>Never</source>
        <translation>Aldri</translation>
    </message>
</context>
<context>
    <name>Otter::PreferencesSearchPageWidget</name>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="21"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="60"/>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="70"/>
        <source>Edit…</source>
        <translation>Rediger…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="80"/>
        <source>Update</source>
        <translation>Oppdater</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="90"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="115"/>
        <source>Move Up</source>
        <translation>Flytt opp</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="141"/>
        <source>Move Down</source>
        <translation>Flytt ned</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.ui" line="154"/>
        <source>Enable search suggestions</source>
        <translation>Skru på søkeforslag</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="98"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="163"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="98"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="163"/>
        <source>Keyword</source>
        <translation>Nøkkelord</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="127"/>
        <source>New…</source>
        <translation>Ny…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="128"/>
        <source>File…</source>
        <translation>Fil…</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="130"/>
        <source>Readd</source>
        <translation>Legg til igjen</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="178"/>
        <source>New Search Engine</source>
        <translation>Ny søkemotor</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="199"/>
        <source>Select File</source>
        <translation>Velg fil</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="199"/>
        <source>Open Search files (*.xml)</source>
        <translation>Åpne søkefiler (*.xml)</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="307"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="370"/>
        <source>Question</source>
        <translation>Spørsmål</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="308"/>
        <source>Do you really want to remove this search engine?</source>
        <translation>Ønsker du virkelig å fjerne denne søkemotoren?</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="317"/>
        <source>Delete search engine permanently</source>
        <translation>Slett søkemotor for godt</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="349"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="360"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="448"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="349"/>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="360"/>
        <source>Failed to open Open Search file.</source>
        <translation>Klarte ikke å åpne søkefil.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="371"/>
        <source>Keyword is already in use. Do you want to continue anyway?</source>
        <translation>Nøkkelord allerede i bruk. Ønsker du å fortsette uansett?</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="448"/>
        <source>Failed to update search engine.</source>
        <translation>Klarte ikke å oppdatere søkemotor.</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/PreferencesSearchPageWidget.cpp" line="511"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
</context>
<context>
    <name>Otter::PrivateWindowIndicatorWidget</name>
    <message>
        <location filename="../../src/modules/widgets/privateWindowIndicator/PrivateWindowIndicatorWidget.cpp" line="33"/>
        <location filename="../../src/modules/widgets/privateWindowIndicator/PrivateWindowIndicatorWidget.cpp" line="49"/>
        <source>Private Window</source>
        <translation>Privat vindu</translation>
    </message>
</context>
<context>
    <name>Otter::ProgressBarDelegate</name>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="57"/>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
</context>
<context>
    <name>Otter::ProgressInformationWidget</name>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="111"/>
        <source>Document: %p%</source>
        <translation>Dokument: %p%</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="111"/>
        <source>Document: ?</source>
        <translation>Dokument: ?</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="119"/>
        <source>Total: ?</source>
        <translation>Totalt: ?</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="119"/>
        <source>Total: %p%</source>
        <translation>Totalt: %p%</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="127"/>
        <source>Total: %1</source>
        <translation>Totalt: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="134"/>
        <source>Elements: %1/%2</source>
        <translation>Elementer: %1/%2</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="141"/>
        <source>Speed: %1</source>
        <translation>Fart: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/progressInformation/ProgressInformationWidget.cpp" line="150"/>
        <source>Time: %1</source>
        <translation>Tid: %1</translation>
    </message>
</context>
<context>
    <name>Otter::ProxyPropertiesDialog</name>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="19"/>
        <source>Title:</source>
        <translation>Tittel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="38"/>
        <source>General</source>
        <translation>Hovedinnstillinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="44"/>
        <source>Manual</source>
        <translation>Manuell</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="144"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="151"/>
        <source>Protocol</source>
        <translation>Protokoll</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="158"/>
        <source>Servers</source>
        <translation>Tjenere</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="165"/>
        <source>FTP</source>
        <translation>FTP</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="172"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="179"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="193"/>
        <source>HTTPS</source>
        <translation>HTTPS</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="207"/>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="229"/>
        <source>Automatic</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="273"/>
        <source>Path to PAC file:</source>
        <translation>Sti til PAC-fil:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="286"/>
        <source>Use system authentication</source>
        <translation>Bruk systemautentisering</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="301"/>
        <source>Exceptions</source>
        <translation>Unntak</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="307"/>
        <source>Do not use this proxy for:</source>
        <translation>Ikke bruk denne mellomtjeneren for:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="328"/>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="338"/>
        <source>Edit</source>
        <translation>Rediger</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="348"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.ui" line="372"/>
        <source>Example: domain.com, localhost, 127.0.0.1, 192.168.1.0/24</source>
        <translation>Eksempel: domene.no, lokalvert, 127.0.0.1, 192.168.1.0/24</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.cpp" line="93"/>
        <source>Edit Proxy</source>
        <translation>Rediger mellomtjener</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ProxyPropertiesDialog.cpp" line="93"/>
        <source>Add Proxy</source>
        <translation>Legg til mellomtjener</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebEnginePage</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="120"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="582"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="622"/>
        <source>JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="121"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="583"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="623"/>
        <source>Disable JavaScript popups</source>
        <translation>Skru av JavaScript-oppsprettsvinduer</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="476"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="489"/>
        <source>Question</source>
        <translation>Spørsmål</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="476"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="490"/>
        <source>Are you sure that you want to send form data again?</source>
        <translation>Er du sikker på at du vil sende skjemadata på ny?</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="476"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="491"/>
        <source>Do you want to resend data?</source>
        <translation>Ønsker du å gjensende data?</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="477"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="495"/>
        <source>Do not show this message again</source>
        <translation>Ikke vis denne meldingen igjen</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebEngineWebBackend</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebBackend.cpp" line="225"/>
        <source>Blink Backend (experimental)</source>
        <translation>Blink-bakende (eksperimentelt)</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebBackend.cpp" line="230"/>
        <source>Backend utilizing QtWebEngine module</source>
        <translation>Bakende som gjør bruk av QtWebEngine-modulen</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebEngineWebWidget</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebWidget.cpp" line="518"/>
        <source>file</source>
        <translation>fil</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebWidget.cpp" line="529"/>
        <source>Failed to save image: %1</source>
        <translation>Klarte ikke å lagre bilde: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebWidget.cpp" line="1420"/>
        <source>Blank Page</source>
        <translation>Blank side</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineWebWidget.cpp" line="1433"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitFtpListingNetworkReply</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="79"/>
        <source>Network error %1</source>
        <translation>Nettverksfeil %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="96"/>
        <source>Unknown command</source>
        <translation>Ukjent kommando</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="160"/>
        <source>Directory Contents</source>
        <translation>Mappeinnhold</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="163"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="164"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="165"/>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="166"/>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitInspector</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitInspector.cpp" line="42"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitNetworkManager</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="201"/>
        <source>Receiving data from %1…</source>
        <translation>Mottar data fra %1…</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="273"/>
        <source>Completed request to %1</source>
        <translation>Fullført forespørsel til %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="310"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="339"/>
        <source>Waiting for authentication…</source>
        <translation>Venter på gyldighetssjekk…</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="421"/>
        <source>Loading finished</source>
        <translation>Innlasting fullført</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="742"/>
        <source>Sending request to %1…</source>
        <translation>Sender forespørsel til %1…</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitPage</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="423"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="674"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="714"/>
        <source>JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="424"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="675"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="715"/>
        <source>Disable JavaScript popups</source>
        <translation>Skru av JavaScript-oppsprettsvinduer</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="614"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="627"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="948"/>
        <source>Question</source>
        <translation>Spørsmål</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="614"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="628"/>
        <source>Are you sure that you want to send form data again?</source>
        <translation>Er du sikker på at du vil sende skjemadata på ny?</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="614"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="629"/>
        <source>Do you want to resend data?</source>
        <translation>Ønsker du å gjensende data?</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="615"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="633"/>
        <source>Do not show this message again</source>
        <translation>Ikke vis denne meldingen igjen</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="787"/>
        <source>%1 error #%2: %3</source>
        <translation>%1 feil #%2: %3</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="859"/>
        <source>Request blocked by rule from profile %1:&lt;br&gt;
%2</source>
        <translation>Forespørsel blokkert av regel fra profil %1:&lt;br&gt;
%2</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="859"/>
        <source>(Unknown)</source>
        <translation>(Ukjent)</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="877"/>
        <source>WebKit error %1</source>
        <translation>WebKit-feil %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="881"/>
        <source>Network error %1</source>
        <translation>Nettverksfeil %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="948"/>
        <source>The script on this page appears to have a problem.</source>
        <translation>Skriptet på siden later til å ha et problem.</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="948"/>
        <source>Do you want to stop the script?</source>
        <translation>Vil du stoppe skriptet?</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitPluginWidget</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPluginWidget.cpp" line="34"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPluginWidget.cpp" line="43"/>
        <source>Click to load content (%1) handled by plugin from: %2</source>
        <translation>Klikk for å laste innhold (%1) behandlet av program-tillegg fra: %2</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitWebBackend</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebBackend.cpp" line="196"/>
        <source>WebKit Backend (legacy)</source>
        <translation>WebKit-bakstykke (foreldet)</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebBackend.cpp" line="198"/>
        <source>WebKit Backend</source>
        <translation>WebKit-bakstykke</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebBackend.cpp" line="204"/>
        <source>Backend utilizing QtWebKit module</source>
        <translation>Bakende som gjør bruk av QtWebKit-modulen</translation>
    </message>
</context>
<context>
    <name>Otter::QtWebKitWebWidget</name>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="421"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="421"/>
        <source>Failed to open file for writing.</source>
        <translation>Kunne ikke åpne fil for skriving.</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="441"/>
        <source>file</source>
        <translation>fil</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="449"/>
        <source>Failed to save image: %1</source>
        <translation>Klarte ikke å lagre bilde: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="583"/>
        <source>Print Preview</source>
        <translation>Forhåndsvisning av utskrift</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="1696"/>
        <source>PNG image (*.png)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="1696"/>
        <source>JPEG image (*.jpg *.jpeg)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="2127"/>
        <source>Blank Page</source>
        <translation>Blank side</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitWebWidget.cpp" line="2140"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
</context>
<context>
    <name>Otter::ReloadTimeDialog</name>
    <message>
        <location filename="../../src/ui/ReloadTimeDialog.ui" line="14"/>
        <source>Automatic Page Reload</source>
        <translation>Automatisk sidegjeninnlasting</translation>
    </message>
    <message>
        <location filename="../../src/ui/ReloadTimeDialog.ui" line="29"/>
        <source>minutes</source>
        <translation>minutter</translation>
    </message>
    <message>
        <location filename="../../src/ui/ReloadTimeDialog.ui" line="46"/>
        <source>seconds</source>
        <translation>sekunder</translation>
    </message>
</context>
<context>
    <name>Otter::ReportDialog</name>
    <message>
        <location filename="../../src/ui/ReportDialog.ui" line="14"/>
        <source>Diagnostic Report</source>
        <translation>Diagnostikkrapport</translation>
    </message>
    <message>
        <location filename="../../src/ui/ReportDialog.cpp" line="41"/>
        <source>Copy</source>
        <translation>Kopier</translation>
    </message>
</context>
<context>
    <name>Otter::RssFeedParser</name>
    <message>
        <location filename="../../src/core/FeedParser.cpp" line="376"/>
        <source>Failed to parse feed file: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/FeedParser.cpp" line="387"/>
        <source>Failed to parse feed: no valid entries found</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Otter::SaveSessionDialog</name>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.ui" line="14"/>
        <source>Save Session</source>
        <translation>Lagre økt</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.ui" line="22"/>
        <source>Session title:</source>
        <translation>Navn på økt:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.ui" line="32"/>
        <source>Session identifier:</source>
        <translation>Identifikator for økt:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.ui" line="50"/>
        <source>Store only current window</source>
        <translation>Behold bare gjeldende vindu</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.cpp" line="68"/>
        <source>Question</source>
        <translation>Spørsmål</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.cpp" line="68"/>
        <source>Session with specified indentifier already exists.
Do you want to overwrite it?</source>
        <translation>Økt med gitt identifikator finnes allerede.
Vil du overskrive den?</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.cpp" line="81"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/ui/SaveSessionDialog.cpp" line="81"/>
        <source>Failed to save session.</source>
        <translation>Klarte ikke å lagre økt</translation>
    </message>
</context>
<context>
    <name>Otter::SearchBarWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="35"/>
        <source>Find…</source>
        <translation>Finn…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="45"/>
        <source>Find Next</source>
        <translation>Finn neste forekomst</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="55"/>
        <source>Find Previous</source>
        <translation>Finn forrige</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="78"/>
        <source>Highlight</source>
        <translation>Fremheving</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="94"/>
        <source>Case Sensitive</source>
        <translation>Versalsensitiv</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SearchBarWidget.ui" line="107"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
</context>
<context>
    <name>Otter::SearchEnginePropertiesDialog</name>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="14"/>
        <source>Edit Search Engine</source>
        <translation>Rediger søkemotor</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="22"/>
        <source>Title:</source>
        <translation>Tittel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="49"/>
        <source>Change Icon…</source>
        <translation>Endre ikon…</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="58"/>
        <source>Description:</source>
        <translation>Beskrivelse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="71"/>
        <source>Keyword:</source>
        <translation>Nøkkelord:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="84"/>
        <source>Encoding:</source>
        <translation>Tegnkoding:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="101"/>
        <source>Form address:</source>
        <translation>Skjemaadresse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="117"/>
        <source>Update address:</source>
        <translation>Oppdater adresse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="133"/>
        <source>Results Query</source>
        <translation>Resultatspørring</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="141"/>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="249"/>
        <source>Address:</source>
        <translation>Adresse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="154"/>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="265"/>
        <source>Query:</source>
        <translation>Spørring:</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="169"/>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="277"/>
        <source>POST method</source>
        <translation>POST-metode</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="210"/>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="318"/>
        <source>Data encoding (enctype):</source>
        <translation>Datakoding (enctype):</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.ui" line="238"/>
        <source>Suggestions Query</source>
        <translation>Forslagsspørring</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.cpp" line="127"/>
        <source>Placeholders</source>
        <translation>Plassholdere</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.cpp" line="128"/>
        <source>Search Terms</source>
        <translation>Søkeord</translation>
    </message>
    <message>
        <location filename="../../src/ui/SearchEnginePropertiesDialog.cpp" line="129"/>
        <source>Language</source>
        <translation>Språk</translation>
    </message>
</context>
<context>
    <name>Otter::SearchEnginesManager</name>
    <message>
        <location filename="../../src/core/SearchEnginesManager.cpp" line="171"/>
        <source>Manage Search Engines…</source>
        <translation>Behandle søkemotorer…</translation>
    </message>
    <message>
        <location filename="../../src/core/SearchEnginesManager.cpp" line="192"/>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
</context>
<context>
    <name>Otter::SearchWidget</name>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="193"/>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="194"/>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="670"/>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="671"/>
        <source>Search using %1</source>
        <translation>Søk ved bruk av %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="311"/>
        <source>Add %1</source>
        <translation>Legg til %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="311"/>
        <source>(untitled)</source>
        <translation>(uten tittel)</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="438"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="438"/>
        <source>Failed to add search engine.</source>
        <translation>Klarte ikke å legge til søkemotor.</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="820"/>
        <source>Select Search Engine</source>
        <translation>Velg søkemotor</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="824"/>
        <source>Add Search Engine…</source>
        <translation>Legg til søkemotor…</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/search/SearchWidget.cpp" line="828"/>
        <source>Search</source>
        <translation>Søk</translation>
    </message>
</context>
<context>
    <name>Otter::SelectPasswordDialog</name>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.ui" line="14"/>
        <source>Select Password</source>
        <translation>Velg passord</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.ui" line="20"/>
        <source>Select set of credentials:</source>
        <translation>Velg sett med identitetsdetaljer:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.ui" line="41"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="38"/>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="79"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="38"/>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="79"/>
        <source>Value</source>
        <translation>Verdi</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="42"/>
        <source>Set #%1</source>
        <translation>Sett #%1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="87"/>
        <source>Question</source>
        <translation>Spørsmål</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/SelectPasswordDialog.cpp" line="87"/>
        <source>Do you really want to remove this credentials set?</source>
        <translation>Ønsker du virkelig å fjerne dette identitetssettet?</translation>
    </message>
</context>
<context>
    <name>Otter::SessionModel</name>
    <message>
        <location filename="../../src/core/SessionModel.cpp" line="247"/>
        <source>Session</source>
        <translation>Økt</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionModel.cpp" line="250"/>
        <source>Trash</source>
        <translation>Papirkurv</translation>
    </message>
</context>
<context>
    <name>Otter::SessionsManager</name>
    <message>
        <location filename="../../src/core/SessionsManager.cpp" line="222"/>
        <source>Default</source>
        <translation>Forvalg</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionsManager.cpp" line="222"/>
        <location filename="../../src/core/SessionsManager.cpp" line="368"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionsManager.h" line="109"/>
        <source>Start Page</source>
        <translation>Startside</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionsManager.h" line="112"/>
        <source>(Unknown)</source>
        <translation>(Ukjent)</translation>
    </message>
</context>
<context>
    <name>Otter::SessionsManagerDialog</name>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.ui" line="14"/>
        <source>Sessions Manager</source>
        <translation>Økt-behandler</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.ui" line="52"/>
        <source>Open</source>
        <translation>Åpne</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.ui" line="59"/>
        <source>Delete</source>
        <translation>Slett</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.ui" line="77"/>
        <source>Open session in current window</source>
        <translation>Åpne økt i gjeldende vindu</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="45"/>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="69"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="49"/>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="98"/>
        <source>Title</source>
        <translation>Tittel</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="49"/>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="98"/>
        <source>Identifier</source>
        <translation>Identifikator</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="49"/>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="98"/>
        <source>Windows</source>
        <translation>Vinduer</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="69"/>
        <source>%n window(s) (%1)</source>
        <translation><numerusform>Ett vindu (%1)</numerusform><numerusform>%n vinduer (%1)</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="69"/>
        <source>%n tab(s)</source>
        <translation><numerusform>én fane</numerusform><numerusform>%n faner</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="106"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="106"/>
        <source>This session was not saved correctly.
Are you sure that you want to restore this session anyway?</source>
        <translation>Lagringen av denne økta gikk ikke riktig for seg.
Er du sikker på at du vil gjenopprette den uansett?</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="123"/>
        <source>Confirm</source>
        <translation>Bekreft</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="123"/>
        <source>Are you sure that you want to delete session %1?</source>
        <translation>Er du sikker på at du vil slette økt %1?</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="131"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/ui/SessionsManagerDialog.cpp" line="131"/>
        <source>Failed to delete session.</source>
        <translation>Sletting av økt feilet.</translation>
    </message>
</context>
<context>
    <name>Otter::SettingsManager</name>
    <message>
        <location filename="../../src/core/SettingsManager.cpp" line="358"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../../src/core/SettingsManager.cpp" line="358"/>
        <source>No</source>
        <translation>Nei</translation>
    </message>
    <message>
        <location filename="../../src/core/SettingsManager.cpp" line="363"/>
        <source>Invalid</source>
        <translation>Ugyldig</translation>
    </message>
</context>
<context>
    <name>Otter::ShortcutWidget</name>
    <message>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="41"/>
        <location filename="../../src/ui/preferences/KeyboardProfileDialog.cpp" line="71"/>
        <source>Clear</source>
        <translation>Tøm</translation>
    </message>
</context>
<context>
    <name>Otter::SidebarWidget</name>
    <message>
        <location filename="../../src/ui/SidebarWidget.ui" line="69"/>
        <source>Panels</source>
        <translation>Paneler</translation>
    </message>
    <message>
        <location filename="../../src/ui/SidebarWidget.cpp" line="160"/>
        <source>Add web panel</source>
        <translation>Legg til nettpanel</translation>
    </message>
    <message>
        <location filename="../../src/ui/SidebarWidget.cpp" line="467"/>
        <source>Add Web Panel…</source>
        <translation>Legg til nettpanel…</translation>
    </message>
</context>
<context>
    <name>Otter::SourceViewerWebWidget</name>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="87"/>
        <source>Failed to save file: %1</source>
        <translation>Klarte ikke å lagre fil: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="89"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="89"/>
        <source>Failed to save file.</source>
        <translation>Klarte ikke å lagre fil.</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="115"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="115"/>
        <source>The document has been modified.
Do you want to save your changes or discard them?</source>
        <translation>Dokumentet har blitt endret.
Ønsker du å lagre dine endringer eller forkaste dem?</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="300"/>
        <source>Show Line Numbers</source>
        <translation>Vis linjenummer</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="425"/>
        <source>Source Viewer: %1</source>
        <translation>Kildekodeviser: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/SourceViewerWebWidget.cpp" line="425"/>
        <source>Source Viewer</source>
        <translation>Kildekodeviser</translation>
    </message>
</context>
<context>
    <name>Otter::StartPageModel</name>
    <message>
        <location filename="../../src/modules/windows/web/StartPageModel.cpp" line="100"/>
        <location filename="../../src/modules/windows/web/StartPageModel.cpp" line="101"/>
        <source>Add Tile…</source>
        <translation>Legg til flis…</translation>
    </message>
</context>
<context>
    <name>Otter::StartPagePreferencesDialog</name>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="14"/>
        <source>Start Page Preferences</source>
        <translation>Startsideinnstillinger</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="20"/>
        <source>Use custom background image</source>
        <translation>Bruk egendefinert bakgrunnsbilde</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="66"/>
        <source>Scaling mode:</source>
        <translation>Skaleringsmetode:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="79"/>
        <source>Image path:</source>
        <translation>Bildesti:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="89"/>
        <source>Color:</source>
        <translation>Farge:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="109"/>
        <source>Columns per row:</source>
        <translation>Kolonner per rad:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="119"/>
        <source>Automatic</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="126"/>
        <source>Zoom level:</source>
        <translation>Forstørrelsesnivå:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="136"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="154"/>
        <source>Show search field</source>
        <translation>Vis søkefelt</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.ui" line="161"/>
        <source>Show tile to add new entries</source>
        <translation>Vis flis for å legge til nye oppføringer</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.cpp" line="40"/>
        <source>Images (*.png *.jpg *.bmp *.gif *.svg *.svgz)</source>
        <translation>Bilder (*.png *.jpg *.bmp *.gif *.svg *.svgz)</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.cpp" line="41"/>
        <source>Best fit</source>
        <translation>Beste tilpasning</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.cpp" line="42"/>
        <source>Center</source>
        <translation>Sentrert</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.cpp" line="43"/>
        <source>Stretch</source>
        <translation>Strekt</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPagePreferencesDialog.cpp" line="44"/>
        <source>Tile</source>
        <translation>Flis</translation>
    </message>
</context>
<context>
    <name>Otter::StartPageWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="560"/>
        <source>Add Tile</source>
        <translation>Legg til flis</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="847"/>
        <source>Edit…</source>
        <translation>Rediger…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="851"/>
        <source>Reload</source>
        <translation>Gjeninnlast</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="859"/>
        <source>Delete</source>
        <translation>Slett</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="863"/>
        <source>Configure…</source>
        <translation>Sett opp…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="867"/>
        <source>Add Tile…</source>
        <translation>Legg til flis…</translation>
    </message>
</context>
<context>
    <name>Otter::StartupDialog</name>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="14"/>
        <location filename="../../src/ui/StartupDialog.ui" line="27"/>
        <source>Welcome to Otter</source>
        <translation>Velkommen til oteren</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="34"/>
        <source>Continue session</source>
        <translation>Fortsett økt</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="104"/>
        <source>Begin with home page</source>
        <translation>Begynn med oppstartsside</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="114"/>
        <source>Begin with start page</source>
        <translation>Begynn med oppstartsside</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="124"/>
        <source>Begin with blank page</source>
        <translation>Begynn med blanke ark</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.ui" line="134"/>
        <source>Enable plugins</source>
        <translation>Skru på programtillegg</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.cpp" line="55"/>
        <location filename="../../src/ui/StartupDialog.cpp" line="62"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.cpp" line="122"/>
        <source>Window %1</source>
        <translation>Vindu %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.cpp" line="132"/>
        <source>Title: %1
Address: %2</source>
        <translation>Tittel: %1
Adresse: %2</translation>
    </message>
    <message>
        <location filename="../../src/ui/StartupDialog.cpp" line="225"/>
        <source>Default</source>
        <translation>Forvalg</translation>
    </message>
</context>
<context>
    <name>Otter::TabBarToolBarWidget</name>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="1186"/>
        <source>Switch Tabs Using the Mouse Wheel</source>
        <translation>Bytt faner med musehjulet</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="1190"/>
        <source>Show Thumbnails in Tabs</source>
        <translation>Vis miniatyrbilder i faner</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="1209"/>
        <source>Arrange</source>
        <translation>Arranger</translation>
    </message>
</context>
<context>
    <name>Otter::TabBarWidget</name>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="808"/>
        <source>Arrange</source>
        <translation>Arranger</translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="820"/>
        <source>Switch Tabs Using the Mouse Wheel</source>
        <translation>Bytt faner med musehjulet</translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="824"/>
        <source>Show Thumbnails in Tabs</source>
        <translation>Vis miniatyrbilder i faner</translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="843"/>
        <source>Customize</source>
        <translation>Tilpass</translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="1086"/>
        <source>Question</source>
        <translation>Spørsmål</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/TabBarWidget.cpp" line="1087"/>
        <source>You are about to open %n URL(s).</source>
        <translation><numerusform>Du er i ferd med å åpne én nettadresse.</numerusform><numerusform>Du er i ferd med å åpne %n nettadresser.</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="1088"/>
        <source>Do you want to continue?</source>
        <translation>Vil du å fortsette?</translation>
    </message>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="1092"/>
        <source>Do not show this message again</source>
        <translation>Ikke vis denne meldingen igjen</translation>
    </message>
</context>
<context>
    <name>Otter::TabHandleWidget</name>
    <message>
        <location filename="../../src/ui/TabBarWidget.cpp" line="269"/>
        <source>Close Tab</source>
        <translation>Lukk fane</translation>
    </message>
</context>
<context>
    <name>Otter::TabHistoryContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation>Søk…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="156"/>
        <source>Tab History</source>
        <translation>Fanehistorikk</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="184"/>
        <source>Title: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="184"/>
        <source>Address: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="188"/>
        <source>Date: %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Otter::TextLabelWidget</name>
    <message>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="42"/>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="98"/>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="138"/>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="182"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;tom&gt;</translation>
    </message>
    <message>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="70"/>
        <source>Copy</source>
        <translation>Kopier</translation>
    </message>
    <message>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="76"/>
        <source>Copy Link Location</source>
        <translation>Kopier lenkeplassering</translation>
    </message>
    <message>
        <location filename="../../src/ui/TextLabelWidget.cpp" line="81"/>
        <source>Select All</source>
        <translation>Velg alle</translation>
    </message>
</context>
<context>
    <name>Otter::ToolBarDialog</name>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="14"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="64"/>
        <source>Edit Toolbar</source>
        <translation>Rediger verktøylinje</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="22"/>
        <source>Name:</source>
        <translation>Navn:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="45"/>
        <source>Entries</source>
        <translation>Oppføringer</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="106"/>
        <source>Edit…</source>
        <translation>Rediger…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="115"/>
        <source>Current entries:</source>
        <translation>Nåværende oppføringer:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="202"/>
        <source>Available entries:</source>
        <translation>Mulige oppføringer:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="209"/>
        <location filename="../../src/ui/ToolBarDialog.ui" line="219"/>
        <source>Filter…</source>
        <translation>Filtrer…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="256"/>
        <source>Add Bookmark</source>
        <translation>Legg til bokmerke</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="269"/>
        <source>Bookmarks folder:</source>
        <translation>Bokmerkemappe:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="291"/>
        <source>New…</source>
        <translation>Ny…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="331"/>
        <source>Options</source>
        <translation>Valg</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="339"/>
        <source>Visibility:</source>
        <translation>Synlighet:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="352"/>
        <source>Visibility in full screen mode:</source>
        <translation>Synlighet i fullskjermsmodus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="365"/>
        <source>Button style:</source>
        <translation>Knappe-stil:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="378"/>
        <source>Icon size:</source>
        <translation>Ikon-størrelse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="388"/>
        <source>Auto</source>
        <translation>Automatisk</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="391"/>
        <location filename="../../src/ui/ToolBarDialog.ui" line="417"/>
        <source> px</source>
        <translation>piksler</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="404"/>
        <source>Maximum size of item:</source>
        <translation>Maksimal størrelse for element:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="414"/>
        <source>No limit</source>
        <translation>Ingen grense</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.ui" line="429"/>
        <source>Display toggle button</source>
        <translation>Knapp for veksling av visning</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="46"/>
        <source>Edit Bookmarks Bar</source>
        <translation>Rediger bokmerkelinje</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="50"/>
        <source>Bookmarks Bar</source>
        <translation>Bokmerkelinje</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="55"/>
        <source>Edit Sidebar</source>
        <translation>Rediger sidestolpe</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="59"/>
        <source>Sidebar</source>
        <translation>Sidestolpe</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="68"/>
        <source>Toolbar</source>
        <translation>Verktøylinje</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="78"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="85"/>
        <source>Always visible</source>
        <translation>Alltid synlig</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="79"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="86"/>
        <source>Always hidden</source>
        <translation>Alltid skjult</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="80"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="87"/>
        <source>Visible only when needed</source>
        <translation>Synlig bare ved behov</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="88"/>
        <source>Visible only when cursor is close to screen edge</source>
        <translation>Synlig bare når pekeren er nær skjermkanten</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="93"/>
        <source>Follow style</source>
        <translation>Følg stil</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="94"/>
        <source>Icon only</source>
        <translation>Bare ikon</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="95"/>
        <source>Text only</source>
        <translation>Bare tekst</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="96"/>
        <source>Text beside icon</source>
        <translation>Tekst ved siden av ikon</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="97"/>
        <source>Text under icon</source>
        <translation>Tekst under ikon</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="339"/>
        <source>Edit Entry</source>
        <translation>Rediger oppføring</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="356"/>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="363"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="629"/>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="373"/>
        <source>Show search engine:</source>
        <translation>Vis søkemotor:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="374"/>
        <source>Show search button:</source>
        <translation>Vis søkeknapp:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="389"/>
        <source>Global</source>
        <translation>For hele programmet</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="389"/>
        <source>Tab</source>
        <translation>Fane</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="393"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="463"/>
        <source>Text:</source>
        <translation>Tekst:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="394"/>
        <source>Option:</source>
        <translation>Valg:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="395"/>
        <source>Scope:</source>
        <translation>Rekkevidde:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="424"/>
        <source>Blocked Elements: {amount}</source>
        <translation>Blokkerte elementer: {amount}</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="429"/>
        <source>Menu</source>
        <translation>Meny</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="434"/>
        <source>Downloads</source>
        <translation>Nedlastinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="462"/>
        <source>Icon:</source>
        <translation>Ikon:</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="532"/>
        <source>--- separator ---</source>
        <translation>-- inndeling --</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="536"/>
        <source>--- spacer ---</source>
        <translation>-- mellomrom --</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="540"/>
        <source>Arbitrary List of Actions</source>
        <translation>Uvilkårlig liste over handlinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="548"/>
        <source>List of Closed Tabs and Windows</source>
        <translation>Liste over lukkede faner og vinduer</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="553"/>
        <source>Address Field</source>
        <translation>Adressefelt</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="562"/>
        <source>Configuration Widget (%1)</source>
        <translation>Oppsetts-miniprogram (%1)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="566"/>
        <source>Configuration Widget</source>
        <translation>Oppsetts-miniprogram</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="572"/>
        <source>Content Blocking Details</source>
        <translation>Innholdsblokkeringsdetaljer</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="577"/>
        <source>Error Console</source>
        <translation>Feil-konsoll</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="581"/>
        <source>Menu Bar</source>
        <translation>Menylinje</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="586"/>
        <source>Menu Button</source>
        <translation>Menyknapp</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="590"/>
        <source>Sidebar Panel Chooser</source>
        <translation>Sidestolpepanel-velger</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="594"/>
        <source>Private Window Indicator</source>
        <translation>Indikator for privat vindu</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="599"/>
        <source>Progress Information (Document Progress)</source>
        <translation>Framdriftsinformasjon (dokumentframdrift)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="603"/>
        <source>Progress Information (Total Progress)</source>
        <translation>Framdriftsinformasjon (total framdrift)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="607"/>
        <source>Progress Information (Loaded Elements)</source>
        <translation>Framdriftsinformasjon (lastede elementer)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="611"/>
        <source>Progress Information (Loading Speed)</source>
        <translation>Framdriftsinformasjon (innlastingshastighet)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="615"/>
        <source>Progress Information (Elapsed Time)</source>
        <translation>Framdriftsinformasjon (tidsforløp)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="619"/>
        <source>Progress Information (Status Message)</source>
        <translation>Framdriftsinformasjon (statusmelding)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="629"/>
        <source>Search Field (%1)</source>
        <translation>Søkefelt (%1)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="634"/>
        <source>Search Field</source>
        <translation>Søkefelt</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="640"/>
        <source>Window Resize Handle</source>
        <translation>Håndtak for endring av vindusstørrelse</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="644"/>
        <source>Status Message Field</source>
        <translation>Status for meldingsfelt</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="648"/>
        <source>Tab Bar</source>
        <translation>Fanelinje</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="652"/>
        <source>Downloads Progress Information</source>
        <translation>Framdriftsinformasjon for nedlastinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="657"/>
        <source>Zoom Slider</source>
        <translation>Glidejustering av forstørrelsesnivå</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="677"/>
        <source>Invalid Bookmark</source>
        <translation>Ugyldig bokmerke</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="686"/>
        <location filename="../../src/ui/ToolBarDialog.cpp" line="703"/>
        <source>Invalid Entry</source>
        <translation>Ugyldig oppføring</translation>
    </message>
</context>
<context>
    <name>Otter::ToolBarWidget</name>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="133"/>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="849"/>
        <source>Toggle Visibility</source>
        <translation>Veksle synlighet</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="905"/>
        <source>Customize</source>
        <translation>Tilpass</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="907"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="908"/>
        <source>Configure…</source>
        <translation>Sett opp…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="911"/>
        <source>Reset to Defaults…</source>
        <translation>Tilbakestill til forvalg…</translation>
    </message>
    <message>
        <location filename="../../src/ui/ToolBarWidget.cpp" line="928"/>
        <source>Remove…</source>
        <translation>Fjern…</translation>
    </message>
</context>
<context>
    <name>Otter::ToolBarsManager</name>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="365"/>
        <source>Reset Toolbar</source>
        <translation>Fjern verktøylinje</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="365"/>
        <source>Do you really want to reset this toolbar to default configuration?</source>
        <translation>Ønsker du virkelig å stille verktøylinjen tilbake til systemforvalg?</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="373"/>
        <source>Remove Toolbar</source>
        <translation>Fjern verktøyslinje</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="373"/>
        <source>Do you really want to remove this toolbar?</source>
        <translation>Ønsker du å fjerne denne verktøyslinjen?</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="387"/>
        <source>Reset Toolbars</source>
        <translation>Tilbakestill verktøyslinjer</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="387"/>
        <source>Do you really want to reset all toolbars to default configuration?</source>
        <translation>Ønsker du virkelig å stille alle verktøylinjer tilbake til systemforvalg?</translation>
    </message>
</context>
<context>
    <name>Otter::ToolButtonWidget</name>
    <message>
        <location filename="../../src/ui/ToolButtonWidget.cpp" line="130"/>
        <source>Menu</source>
        <translation>Meny</translation>
    </message>
</context>
<context>
    <name>Otter::Transfer</name>
    <message>
        <location filename="../../src/core/TransfersManager.cpp" line="670"/>
        <location filename="../../src/core/TransfersManager.cpp" line="703"/>
        <source>file</source>
        <translation>fil</translation>
    </message>
    <message>
        <location filename="../../src/core/TransfersManager.cpp" line="888"/>
        <source>Question</source>
        <translation>Spørsmål</translation>
    </message>
    <message>
        <location filename="../../src/core/TransfersManager.cpp" line="888"/>
        <source>File with the same name already exists.
Do you want to overwrite it?

%1</source>
        <translation>Ei fil med samme navn eksisterer allerede.
Vil du overskrive den?

%1</translation>
    </message>
</context>
<context>
    <name>Otter::TransferActionWidget</name>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="234"/>
        <source>From:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="240"/>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="244"/>
        <source>Size:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="240"/>
        <source>%1 (download completed)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="244"/>
        <source>%1 (%2% downloaded)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="263"/>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="297"/>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="270"/>
        <source>Redownload</source>
        <translation>Last ned på ny</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="275"/>
        <source>Open Folder</source>
        <translation>Åpne mappe</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="280"/>
        <source>Stop</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="297"/>
        <source>&lt;div style=&quot;white-space:pre;&quot;&gt;Source: %1
Target: %2
Size: %3
Downloaded: %4
Progress: %5&lt;/div&gt;</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>Otter::TransferDialog</name>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="14"/>
        <source>Opening unknown file</source>
        <translation>Åpner ukjent fil</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="22"/>
        <source>Name:</source>
        <translation>Navn:</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="29"/>
        <source>Type:</source>
        <translation>Type:</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="36"/>
        <source>Size:</source>
        <translation>Størrelse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="43"/>
        <source>From:</source>
        <translation>Fra:</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="50"/>
        <source>Open with:</source>
        <translation>Åpne med:</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.ui" line="104"/>
        <source>Remember choice for this file type</source>
        <translation>Husk valg for denne filtypen</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.cpp" line="45"/>
        <source>unknown file</source>
        <translation>ukjent fil</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.cpp" line="65"/>
        <source>Opening %1</source>
        <translation>Åpner %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.cpp" line="171"/>
        <source>unknown</source>
        <translation>ukjent</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.cpp" line="175"/>
        <source>%1 (download completed)</source>
        <translation>%1 (nedlasting fullført)</translation>
    </message>
    <message>
        <location filename="../../src/ui/TransferDialog.cpp" line="179"/>
        <source>%1 (%2% downloaded)</source>
        <translation>%1 (%2% nedlastet)</translation>
    </message>
</context>
<context>
    <name>Otter::TransfersContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="31"/>
        <source>Quick Download…</source>
        <translation>Rask nedlasting…</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="120"/>
        <source>Source:</source>
        <translation>Kildekode:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="130"/>
        <source>Target:</source>
        <translation>Mål:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="140"/>
        <source>Size:</source>
        <translation>Størrelse:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="150"/>
        <source>Downloaded:</source>
        <translation>Nedlastet:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="157"/>
        <source>Progress:</source>
        <translation>Framdrift:</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="190"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="405"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="452"/>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.ui" line="200"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="408"/>
        <source>Redownload</source>
        <translation>Last ned på ny</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Filename</source>
        <translation>Filnavn</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Progress</source>
        <translation>Fremdrift</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Time</source>
        <translation>Tid</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Speed</source>
        <translation>Fart</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Started</source>
        <translation>Startet</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="80"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="133"/>
        <source>Finished</source>
        <translation>Sluttført</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="145"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="145"/>
        <source>This file is still being downloaded.
Do you really want to remove it?</source>
        <translation>Overføringen er fremdeles i gang.
Vil du virkelig fjerne den?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="277"/>
        <source>&lt;div style=&quot;white-space:pre;&quot;&gt;Source: %1
Target: %2
Size: %3
Downloaded: %4
Progress: %5&lt;/div&gt;</source>
        <translation>&lt;pre style=&apos;white-space:pre;&apos;&gt;Kilde: %1
Mål: %2
Størrelse: %3
Nedlastet: %4
Framdrift: %5&lt;/div&gt;</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="277"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="467"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="469"/>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="400"/>
        <source>Open Folder</source>
        <translation>Åpne mappe</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="405"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="447"/>
        <source>Resume</source>
        <translation>Gjenoppta</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="412"/>
        <source>Copy Transfer Information</source>
        <translation>Kopier overføringsinformasjon</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="416"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="433"/>
        <source>Clear Finished Transfers</source>
        <translation>Tøm overføringslogg</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="546"/>
        <source>Downloads</source>
        <translation>Nedlastinger</translation>
    </message>
</context>
<context>
    <name>Otter::TransfersManager</name>
    <message>
        <location filename="../../src/core/TransfersManager.cpp" line="1126"/>
        <source>Download completed:
%1</source>
        <translation>Nedlasting fullført:
%1</translation>
    </message>
</context>
<context>
    <name>Otter::TransfersWidget</name>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="47"/>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="101"/>
        <source>Downloads</source>
        <translation>Nedlastinger</translation>
    </message>
    <message>
        <location filename="../../src/modules/widgets/transfers/TransfersWidget.cpp" line="123"/>
        <source>Show all Downloads</source>
        <translation>Vis alle nedlastinger</translation>
    </message>
</context>
<context>
    <name>Otter::TrayIcon</name>
    <message>
        <location filename="../../src/ui/TrayIcon.cpp" line="41"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="148"/>
        <source>Show Windows</source>
        <translation>Vis vinduer</translation>
    </message>
    <message>
        <location filename="../../src/ui/TrayIcon.cpp" line="79"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="176"/>
        <source>Otter Browser</source>
        <translation>Oter-nettleser</translation>
    </message>
    <message>
        <location filename="../../src/ui/TrayIcon.cpp" line="148"/>
        <source>Hide Windows</source>
        <translation>Gjem vinduer</translation>
    </message>
</context>
<context>
    <name>Otter::UpdateCheckerDialog</name>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.ui" line="14"/>
        <source>Check for Updates</source>
        <translation>Se etter oppdateringer</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.ui" line="20"/>
        <source>Checking for update…</source>
        <translation>Ser etter oppdatering…</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="50"/>
        <source>Checking for updates…</source>
        <translation>Ser etter oppdateringer…</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="91"/>
        <source>There are no new updates.</source>
        <translation>Ingen nye oppdateringer.</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="97"/>
        <source>Available updates:</source>
        <translation>Tilgjengelige oppdateringer:</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="101"/>
        <source>Details…</source>
        <translation>Detaljer…</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="104"/>
        <source>Download</source>
        <translation>Last ned</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="117"/>
        <source>Version %1 from %2 channel</source>
        <translation>Versjon %1 fra %2 kanal</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="127"/>
        <source>Some of the updates do not contain packages for your platform. Try to check for updates later or visit details page for more info.</source>
        <translation>Noen av oppdateringene inneholder ikke pakker for din plattform. Prøv å se etter oppdateringer senere, eller besøk detaljsiden for mer informasjon.</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="151"/>
        <source>Downloading:</source>
        <translation>Laster ned:</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="166"/>
        <source>Download finished!</source>
        <translation>Nedlasting fullført!</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="167"/>
        <source>Install</source>
        <translation>Installer</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="169"/>
        <source>New version of Otter Browser is ready to install.
Click Install button to restart browser and install the update or close this dialog to install the update during next browser restart.</source>
        <translation>Ny versjon av Oter-nettleseren klar til installasjon.
Klikk Installer-knappen for å starte nettleseren på nytt og oppdatere oppgraderingen, eller lukk dette dialogvinduet for å installere oppgraderingen under neste omstart av nettlesren.</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="191"/>
        <source>Download failed!</source>
        <translation>Nedlasting mislyktes!</translation>
    </message>
    <message>
        <location filename="../../src/ui/UpdateCheckerDialog.cpp" line="193"/>
        <source>Check Error Console for more information.</source>
        <translation>Sjekk feil-konsoll for mer informasjon</translation>
    </message>
</context>
<context>
    <name>Otter::UserAgentPropertiesDialog</name>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.ui" line="19"/>
        <source>Title:</source>
        <translation>Tittel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.ui" line="29"/>
        <source>Value:</source>
        <translation>Verdi:</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.ui" line="47"/>
        <source>Preview</source>
        <translation>Forhåndsvis</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="52"/>
        <source>Edit User Agent</source>
        <translation>Rediger brukeragent</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="52"/>
        <source>Add User Agent</source>
        <translation>Legg til brukeragent</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="105"/>
        <source>Placeholders</source>
        <translation>Plassholdere</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="106"/>
        <source>Platform</source>
        <translation>Plattform</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="107"/>
        <source>Engine Version</source>
        <translation>Motorversjon</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/UserAgentPropertiesDialog.cpp" line="108"/>
        <source>Application Version</source>
        <translation>Programversjon</translation>
    </message>
</context>
<context>
    <name>Otter::WebContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="993"/>
        <source>Question</source>
        <translation>Spørsmål</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="993"/>
        <source>This tab has crashed.</source>
        <translation>Denne fanen har kræsjet</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="993"/>
        <source>Do you want to try to reload it?</source>
        <translation>Ønsker du å gjeninnlaste den?</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="994"/>
        <source>Do not show this message again</source>
        <translation>Ikke vis denne meldingen igjen</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="1160"/>
        <source>Failed to load requested web backend: %1</source>
        <translation>Klarte ikke å laste forespurt vev-bakende: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="1242"/>
        <source>Select User Agent</source>
        <translation>Velg brukeragent</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="1242"/>
        <source>Enter User Agent:</source>
        <translation>Skriv inn brukeragent</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/web/WebContentsWidget.cpp" line="1399"/>
        <source>Start Page</source>
        <translation>Startside</translation>
    </message>
</context>
<context>
    <name>Otter::WebWidget</name>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="267"/>
        <source>Title: %1</source>
        <translation>Tittel: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="267"/>
        <source>Address: %1</source>
        <translation>Adresse: %1</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="313"/>
        <source>JavaScript</source>
        <translation>JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="313"/>
        <source>Webpage wants to close this tab, do you want to allow to close it?</source>
        <translation>Nettsiden ønsker å lukke denne fanen, ønsker du å tillate lukking?</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="314"/>
        <source>Do not show this message again</source>
        <translation>Ikke vis denne meldingen igjen</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="729"/>
        <source>HTML file (*.html *.htm)</source>
        <translation>HTML-fil (*.html *.htm)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="729"/>
        <source>HTML file with all resources (*.html *.htm)</source>
        <translation>HTML-fil inneholdende alle ressurser (*.html *.htm)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="729"/>
        <source>Web archive (*.mht)</source>
        <translation>Nettarkiv (*.mht)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="729"/>
        <source>PDF document (*.pdf)</source>
        <translation>PDF-dokument: (*.pdf)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1031"/>
        <source>Open Image in New Background Tab (%1)</source>
        <translation>Åpne bilde i ny bakgrunnsfane (%1)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1035"/>
        <source>Open Image in New Tab (%1)</source>
        <translation>Åpne bilde i ny fane (%1)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1091"/>
        <source>Playback Rate: %1x</source>
        <translation>Avspillingshastighet: %1x</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1175"/>
        <source>Page Default</source>
        <translation>Sideforvalg</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1183"/>
        <source>Never Reload</source>
        <translation>Aldri gjeninnlast</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/WebWidget.cpp" line="1187"/>
        <source>Reload Every: %n second(s)</source>
        <translation><numerusform>Gjeninnlast hvert: %n sekund</numerusform><numerusform>Gjeninnlast hvert: %n sekund</numerusform></translation>
    </message>
</context>
<context>
    <name>Otter::WebsiteInformationDialog</name>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="57"/>
        <source>General</source>
        <translation>Hovedinnstillinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="69"/>
        <source>Information</source>
        <translation>Informasjon</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="76"/>
        <source>Address:</source>
        <translation>Adresse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="83"/>
        <source>Encoding:</source>
        <translation>Tegnkoding:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="90"/>
        <source>Size:</source>
        <translation>Størrelse:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="97"/>
        <source>Elements:</source>
        <translation>Elementer:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="104"/>
        <source>Download date:</source>
        <translation>Nedlastingsdato:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="126"/>
        <source>Title:</source>
        <translation>Tittel:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="137"/>
        <source>Permissions</source>
        <translation>Tilganger</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="149"/>
        <source>Preferences</source>
        <translation>Innstillinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="171"/>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="307"/>
        <source>Details…</source>
        <translation>Detaljer…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="180"/>
        <source>Set cookies:</source>
        <translation>Sett kaker</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="187"/>
        <source>Set third-party cookies:</source>
        <translation>Sett tredjepartskaker:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="194"/>
        <source>Show notifications:</source>
        <translation>Vis merknader:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="201"/>
        <source>Access your location:</source>
        <translation>Tilgang til din plassering:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="208"/>
        <source>Load plugins:</source>
        <translation>Last inn programtillegg:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="215"/>
        <source>Load images:</source>
        <translation>Last inn bilder:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="222"/>
        <source>Use JavaScript:</source>
        <translation>Bruk JavaScript:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="250"/>
        <source>Show pop-up windows:</source>
        <translation>Vis oppsprettsvinduer:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="260"/>
        <source>Enter full screen mode:</source>
        <translation>Gå inn i fullskjermsmodus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="271"/>
        <source>Security</source>
        <translation>Sikerhet</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="285"/>
        <source>Certificate</source>
        <translation>Sertifikat</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="316"/>
        <source>Issued to:</source>
        <translation>Utstedt til:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="323"/>
        <source>Issued by:</source>
        <translation>Utstedt av:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="330"/>
        <source>Issued on:</source>
        <translation>Utstedt:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="337"/>
        <source>Expires on:</source>
        <translation>Utløper:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="350"/>
        <source>Cipher</source>
        <translation>Krypteringsalgoritme</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="357"/>
        <source>Protocol:</source>
        <translation>Protokoll:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="364"/>
        <source>Authentication method:</source>
        <translation>Autentiseringsmetode:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="371"/>
        <source>Encryption method:</source>
        <translation>Krypteringsmetode:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="378"/>
        <source>Key exchange method:</source>
        <translation>Nøkkelutvekslingsmetode:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.ui" line="417"/>
        <source>SSL Errors</source>
        <translation>SSL-feil</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="43"/>
        <source>(unknown)</source>
        <translation>(ukjent)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="48"/>
        <source>This website was marked as fraud.</source>
        <translation>Denne nettsiden ble markert som svindel.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="53"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="63"/>
        <source>Your connection with this website is not private.</source>
        <translation>Din tilkobling til denne nettsiden er ikke privat.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="58"/>
        <source>Your connection with this website is private.</source>
        <translation>Din tilkobling til denne nettsiden er privat.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="68"/>
        <source>You are viewing content from your local filesystem.</source>
        <translation>Du viser innhold fra ditt lokale filsystem.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="73"/>
        <source>You are viewing safe page from Otter Browser.</source>
        <translation>Du ser en infoside fra Oter-nettlesren.</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="78"/>
        <source>No information.</source>
        <translation>Ingen informasjon</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="85"/>
        <source>unknown</source>
        <translation>ukjent</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="87"/>
        <source>%1 (%n blocked)</source>
        <translation><numerusform>%1 (%n blokkert)</numerusform><numerusform>%1 (%n blokkert)</numerusform></translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="94"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="113"/>
        <source>Only existing</source>
        <translation>Bare eksisterende</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="98"/>
        <source>Only read existing</source>
        <translation>Bare les eksisterende</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="102"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="117"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="132"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="147"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="154"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="164"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="179"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="194"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="213"/>
        <source>Never</source>
        <translation>Aldri</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="106"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="121"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="128"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="151"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="154"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="160"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="175"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="190"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="205"/>
        <source>Always</source>
        <translation>Alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="136"/>
        <source>On demand</source>
        <translation>Ved behov</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="143"/>
        <source>Only cached</source>
        <translation>Kun hurtiglagret</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="168"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="183"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="198"/>
        <source>Always ask</source>
        <translation>Alltid spør</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="209"/>
        <source>Always (open in backgound)</source>
        <translation>Alltid (åpne i bakgrunnen)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="217"/>
        <source>Ask</source>
        <translation>Spør</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="246"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="291"/>
        <source>Error Message</source>
        <translation>Feilmelding</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="246"/>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="291"/>
        <source>URL</source>
        <translation>Nettadresse</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsiteInformationDialog.cpp" line="262"/>
        <source>Information for %1</source>
        <translation>Informasjon i %1</translation>
    </message>
</context>
<context>
    <name>Otter::WebsitePreferencesDialog</name>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="14"/>
        <source>Website Preferences</source>
        <translation>Nettsideinnstillinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="25"/>
        <source>Website:</source>
        <translation>Nettside:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="44"/>
        <source>Content</source>
        <translation>Innhold</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="56"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="262"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="646"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="794"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="858"/>
        <source>Override</source>
        <translation>Overstyr</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="73"/>
        <source>Plugins:</source>
        <translation>Program-tillegg:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="90"/>
        <source>Encoding:</source>
        <translation>Tegnkoding</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="110"/>
        <source>User style sheet:</source>
        <translation>Brukerstyrt stilsett:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="153"/>
        <source>Images:</source>
        <translation>Bilder:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="170"/>
        <source>Pop-ups:</source>
        <translation>Oppsprettsvinduer:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="181"/>
        <source>Privacy</source>
        <translation>Personvern</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="205"/>
        <source>Keep until:</source>
        <translation>Behold til:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="248"/>
        <source>Remember browsing history</source>
        <translation>Husk surfehistorikk</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="269"/>
        <source>Enable cookies</source>
        <translation>Skru på informasjonskapsler</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="294"/>
        <source>Accept cookies:</source>
        <translation>Godta informasjonskapsler:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="303"/>
        <source>Do Not Track:</source>
        <translation>Ikke spor meg:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="323"/>
        <source>Cookies:</source>
        <translation>Kaker:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="350"/>
        <source>Add…</source>
        <translation>Legg til…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="360"/>
        <source>Properties…</source>
        <translation>Egenskaper…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="370"/>
        <source>Delete</source>
        <translation>Slett</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="412"/>
        <source>Accept third-party cookies:</source>
        <translation>Tillat tredjeparts informasjonskapsler:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="448"/>
        <source>Scripting</source>
        <translation>Skripting</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="486"/>
        <source>Allow to receive right mouse button clicks</source>
        <translation>Tillat å motta høyreklikk</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="520"/>
        <source>Allow changing of status field</source>
        <translation>Tillat endring av statusfelt</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="567"/>
        <source>Allow to close windows:</source>
        <translation>Tillat å lukke vinduer:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="600"/>
        <source>Allow script to hide address bar</source>
        <translation>Tillat skript å gjemme adressefelt</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="627"/>
        <source>Allow moving and resizing of windows</source>
        <translation>Tillat flytting og endring av størrelse på vinduer</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="660"/>
        <source>Enable JavaScript</source>
        <translation>Skru på JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="698"/>
        <source>Allow access to clipboard</source>
        <translation>Tillat tilgang til utklippstavle</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="745"/>
        <source>Allow to enter full screen mode:</source>
        <translation>Tillat å gå inn i fullskjermsmodus:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="758"/>
        <source>Network</source>
        <translation>Nettverk</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="787"/>
        <source>Send referrer information</source>
        <translation>Send HTTP-henvendelsesinformasjon (referent) til lenket side (informasjon om nettadresse til kilde)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="801"/>
        <source>Proxy:</source>
        <translation>Mellomtjener:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="811"/>
        <source>User Agent:</source>
        <translation>Brukeragent:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="852"/>
        <source>Content Blocking</source>
        <translation>Innholdsblokkering</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="865"/>
        <source>Profiles:</source>
        <translation>Profiler:</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.ui" line="895"/>
        <source>Enable custom rules</source>
        <translation>Skru på egendefinerte regler</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="66"/>
        <source>Auto Detect</source>
        <translation>Automatisk oppdaging</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="82"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="95"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="99"/>
        <source>Ask</source>
        <translation>Spør</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="83"/>
        <source>Block all</source>
        <translation>Blokker alle</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="84"/>
        <source>Open all</source>
        <translation>Åpne alle</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="85"/>
        <source>Open all in background</source>
        <translation>Åpne alle i bakgrunn</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="87"/>
        <source>All images</source>
        <translation>Alle bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="88"/>
        <source>Cached images</source>
        <translation>Hurtiglagrede bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="89"/>
        <source>No images</source>
        <translation>Ingen bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="91"/>
        <source>Enabled</source>
        <translation>Påskrudd</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="92"/>
        <source>On demand</source>
        <translation>Ved behov</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="93"/>
        <source>Disabled</source>
        <translation>Avskrudd</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="96"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="100"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="107"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="115"/>
        <source>Always</source>
        <translation>Alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="97"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="101"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="117"/>
        <source>Never</source>
        <translation>Aldri</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="103"/>
        <source>Inform websites that I do not want to be tracked</source>
        <translation>Gi nettsteder beskjed om at jeg ikke ønsker å bli sporet</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="104"/>
        <source>Inform websites that I allow tracking</source>
        <translation>Gi nettsteder beskjed om at jeg tillater sporing</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="105"/>
        <source>Do not inform websites about my preference</source>
        <translation>Ikke gi nettsteder beskjed om min preferanse</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="108"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="116"/>
        <source>Only existing</source>
        <translation>Bare eksisterende</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="109"/>
        <source>Only read existing</source>
        <translation>Bare les eksisterende</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="111"/>
        <source>Expires</source>
        <translation>Utløper</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="112"/>
        <source>Current session is closed</source>
        <translation>Nåværende økt lukket</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="113"/>
        <source>Always ask</source>
        <translation>Spør alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="120"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="200"/>
        <source>Domain</source>
        <translation>Domene</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="120"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="200"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="120"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="200"/>
        <source>Path</source>
        <translation>Sti</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="120"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="200"/>
        <source>Value</source>
        <translation>Verdi</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="120"/>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="200"/>
        <source>Expiration Date</source>
        <translation>Utløpsdato</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="206"/>
        <source>this session only</source>
        <translation>kun for denne økta</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebsitePreferencesDialog.cpp" line="453"/>
        <source>Style sheets (*.css)</source>
        <translation>Stilsett (*.css)</translation>
    </message>
</context>
<context>
    <name>Otter::WindowsContentsWidget</name>
    <message>
        <location filename="../../src/modules/windows/windows/WindowsContentsWidget.ui" line="29"/>
        <source>Search…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/windows/WindowsContentsWidget.cpp" line="267"/>
        <source>Windows and Tabs</source>
        <translation>Vinduer og faner</translation>
    </message>
</context>
<context>
    <name>Otter::WindowsPlatformIntegration</name>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="73"/>
        <source>New tab</source>
        <translation>Ny fane</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="74"/>
        <source>New private tab</source>
        <translation>Ny privat fane</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="75"/>
        <source>New window</source>
        <translation>Nytt vindu</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="76"/>
        <source>New private window</source>
        <translation>Nytt privat vindu</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="177"/>
        <source>Failed to run command &quot;%1&quot;, file is not executable</source>
        <translation>Kunne ikke kjøre kommandoen &quot;%1&quot;, fila er ikke kjørbar</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="204"/>
        <source>Failed to run command &quot;%1&quot; (arguments: &quot;%2&quot;)</source>
        <translation>Kunne ikke kjøre kommandoen &quot;%1&quot; (argumenter: &quot;%2&quot;)</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="291"/>
        <source>No valid suffix for given MIME type: %1</source>
        <translation>Ingen gyldig filendelse for gitt MIME-type: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="358"/>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="408"/>
        <source>Failed to load a valid application path for MIME type %1: %2</source>
        <translation>Klarte ikke å laste gyldig programsti for MIMEtype %1: %2</translation>
    </message>
</context>
<context>
    <name>Otter::WorkspaceWidget</name>
    <message>
        <location filename="../../src/ui/WorkspaceWidget.cpp" line="550"/>
        <location filename="../../src/ui/WorkspaceWidget.cpp" line="645"/>
        <source>Arrange</source>
        <translation>Arranger</translation>
    </message>
</context>
<context>
    <name>Otter::ZoomWidget</name>
    <message>
        <location filename="../../src/modules/widgets/zoom/ZoomWidget.cpp" line="132"/>
        <location filename="../../src/modules/widgets/zoom/ZoomWidget.cpp" line="133"/>
        <source>Zoom %1%</source>
        <translation>Forstørrelsesnivå %1%</translation>
    </message>
</context>
<context>
    <name>actions</name>
    <message>
        <source>Reload Every</source>
        <translation>Gjeninnlast hver(-t)</translation>
    </message>
    <message>
        <source>1 Minute</source>
        <translation>ett minutt</translation>
    </message>
    <message>
        <source>30 Minutes</source>
        <translation>en halvtime</translation>
    </message>
    <message>
        <source>1 Hour</source>
        <translation>en time</translation>
    </message>
    <message>
        <source>2 Hours</source>
        <translation>to timer</translation>
    </message>
    <message>
        <source>6 Hours</source>
        <translation>seks timer</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>aldri</translation>
    </message>
    <message>
        <source>Custom…</source>
        <translation>Egentilpasset…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="286"/>
        <source>Run Macro</source>
        <translation>Kjør makro</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="286"/>
        <source>Run Arbitrary List of Actions</source>
        <translation>Kjør uvilkårlig liste over handlinger</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="287"/>
        <source>Set Option</source>
        <translation>Sett valg</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="287"/>
        <source>Set, Reset or Toggle Option</source>
        <translation>Sett, tilbakestill eller veksle valg</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="288"/>
        <source>New Tab</source>
        <translation>Ny fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="289"/>
        <source>New Private Tab</source>
        <translation>Ny privat fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="290"/>
        <source>New Window</source>
        <translation>Nytt vindu</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="291"/>
        <source>New Private Window</source>
        <translation>Nytt privat vindu</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="292"/>
        <source>Open…</source>
        <translation>Åpne…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="293"/>
        <source>Save…</source>
        <translation>Lagre…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="294"/>
        <source>Clone Tab</source>
        <translation>Klon fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="295"/>
        <source>Peek Tab</source>
        <translation>Forhåndsvis fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="296"/>
        <location filename="../../src/ui/Window.cpp" line="656"/>
        <source>Pin Tab</source>
        <translation>Fest fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="297"/>
        <source>Detach Tab</source>
        <translation>Løsne fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="298"/>
        <source>Maximize</source>
        <translation>Maksimer</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="298"/>
        <source>Maximize Tab</source>
        <translation>Maksimer fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="299"/>
        <source>Minimize</source>
        <translation>Minimer</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="299"/>
        <source>Minimize Tab</source>
        <translation>Minimer fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="300"/>
        <source>Restore</source>
        <translation>Gjenopprett</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="300"/>
        <source>Restore Tab</source>
        <translation>Gjenopprett fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="301"/>
        <source>Stay on Top</source>
        <translation>Behold i forgrunnen</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="302"/>
        <source>Clear Tab History</source>
        <translation>Tøm fanehistorikk</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="302"/>
        <source>Remove Local Tab History</source>
        <translation>Fjern lokal fanehistorikk</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="303"/>
        <location filename="../../src/modules/widgets/action/ActionWidget.cpp" line="267"/>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="150"/>
        <location filename="../../src/ui/WebWidget.cpp" line="918"/>
        <source>Purge Tab History</source>
        <translation>Slett fanehistorikk</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="303"/>
        <source>Remove Local and Global Tab History</source>
        <translation>Fjern navigasjons- og surfe -historikk</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="304"/>
        <location filename="../../src/ui/WebWidget.cpp" line="1103"/>
        <source>Mute Tab Media</source>
        <translation>Demp fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="305"/>
        <source>Suspend Tab</source>
        <translation>Gjør fane passiv</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="306"/>
        <source>Close Tab</source>
        <translation>Lukk fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="307"/>
        <source>Close Other Tabs</source>
        <translation>Lukk andre faner</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="308"/>
        <source>Close All Private Tabs</source>
        <translation>Lukk alle private faner</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="308"/>
        <source>Close All Private Tabs in Current Window</source>
        <translation>Lukk alle private faner i gjeldende vindu</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="309"/>
        <source>Close Private Tabs and Windows</source>
        <translation>Lukk private faner og vinduer</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="310"/>
        <source>Reopen Previously Closed Tab</source>
        <translation>Gjenåpne tidligere lukket fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="311"/>
        <source>Maximize All</source>
        <translation>Maksimer alle</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="312"/>
        <source>Minimize All</source>
        <translation>Minimer alle</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="313"/>
        <source>Restore All</source>
        <translation>Gjenopprett alle</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="314"/>
        <source>Cascade</source>
        <translation>Utfoldende</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="315"/>
        <source>Tile</source>
        <translation>Flis</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="316"/>
        <source>Close Window</source>
        <translation>Lukk vindu</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="317"/>
        <source>Reopen Previously Closed Window</source>
        <translation>Gjenåpne tidligere lukket vindu</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="318"/>
        <source>Manage Sessions…</source>
        <translation>Behandle økter…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="319"/>
        <source>Save Current Session…</source>
        <translation>Lagre nåværende økt…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="320"/>
        <source>Open URL</source>
        <translation>Åpne nettadresse</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="321"/>
        <location filename="../../src/core/ActionsManager.cpp" line="336"/>
        <location filename="../../src/core/ActionsManager.cpp" line="337"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="177"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="350"/>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="404"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="370"/>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="222"/>
        <location filename="../../src/modules/windows/transfers/TransfersContentsWidget.cpp" line="389"/>
        <location filename="../../src/modules/windows/web/StartPageWidget.cpp" line="843"/>
        <location filename="../../src/ui/Menu.cpp" line="326"/>
        <location filename="../../src/ui/WebWidget.cpp" line="797"/>
        <source>Open</source>
        <translation>Åpne</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="322"/>
        <location filename="../../src/ui/WebWidget.cpp" line="754"/>
        <source>Open in This Tab</source>
        <translation>Åpne i denne fanen</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="323"/>
        <location filename="../../src/core/ActionsManager.cpp" line="338"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="179"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="352"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="372"/>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="224"/>
        <location filename="../../src/ui/Menu.cpp" line="327"/>
        <location filename="../../src/ui/WebWidget.cpp" line="759"/>
        <source>Open in New Tab</source>
        <translation>Åpne i ny fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="324"/>
        <location filename="../../src/core/ActionsManager.cpp" line="339"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="182"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="355"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="375"/>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="227"/>
        <location filename="../../src/ui/Menu.cpp" line="328"/>
        <location filename="../../src/ui/WebWidget.cpp" line="764"/>
        <source>Open in New Background Tab</source>
        <translation>Åpne i bakgrunnsfane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="325"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="187"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="360"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="380"/>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="232"/>
        <location filename="../../src/ui/Menu.cpp" line="330"/>
        <location filename="../../src/ui/WebWidget.cpp" line="769"/>
        <source>Open in New Window</source>
        <translation>Åpne i nytt vindu</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="326"/>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="190"/>
        <location filename="../../src/modules/windows/cache/CacheContentsWidget.cpp" line="363"/>
        <location filename="../../src/modules/windows/history/HistoryContentsWidget.cpp" line="383"/>
        <location filename="../../src/modules/windows/links/LinksContentsWidget.cpp" line="235"/>
        <location filename="../../src/ui/Menu.cpp" line="331"/>
        <location filename="../../src/ui/WebWidget.cpp" line="774"/>
        <source>Open in New Background Window</source>
        <translation>Åpne i nytt bakgrunnsvindu</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="327"/>
        <location filename="../../src/ui/WebWidget.cpp" line="779"/>
        <source>Open in New Private Tab</source>
        <translation>Åpne i ny privat fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="328"/>
        <location filename="../../src/ui/WebWidget.cpp" line="784"/>
        <source>Open in New Private Background Tab</source>
        <translation>Åpne i ny privat bakgrunnsfane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="329"/>
        <location filename="../../src/ui/WebWidget.cpp" line="789"/>
        <source>Open in New Private Window</source>
        <translation>Åpne i nytt privat vindu</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="330"/>
        <location filename="../../src/ui/WebWidget.cpp" line="794"/>
        <source>Open in New Private Background Window</source>
        <translation>Åpne i nytt privat bakgrunnsvindu</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="331"/>
        <source>Copy Link to Clipboard</source>
        <translation>Kopier lenke til utklippstavle</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="332"/>
        <location filename="../../src/ui/WebWidget.cpp" line="955"/>
        <source>Bookmark Link…</source>
        <translation>Bokmerk lenke…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="333"/>
        <source>Save Link Target As…</source>
        <translation>Lagre lenkemål som…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="334"/>
        <source>Save to Downloads</source>
        <translation>Lagre til Nedlastinger</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="335"/>
        <source>Go to This Address</source>
        <translation>Gå til denne adressen</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="336"/>
        <source>Open Frame</source>
        <translation>Åpne ramme</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="337"/>
        <source>Open Frame in This Tab</source>
        <translation>Åpne ramme i denne fanen</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="338"/>
        <source>Open Frame in New Tab</source>
        <translation>Åpne ramme i ny fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="339"/>
        <source>Open Frame in New Background Tab</source>
        <translation>Åpne ramme i ny bakgrunnsfane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="340"/>
        <source>Copy Frame Link to Clipboard</source>
        <translation>Kopier rammelenke til utklippstavle</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="341"/>
        <location filename="../../src/core/ActionsManager.cpp" line="372"/>
        <location filename="../../src/core/ActionsManager.cpp" line="373"/>
        <source>Reload</source>
        <translation>Gjeninnlast</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="341"/>
        <source>Reload Frame</source>
        <translation>Gjeninnlast ramme</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="342"/>
        <source>View Frame Source</source>
        <translation>Vis ramme-kilde</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="343"/>
        <source>Open Image</source>
        <translation>Åpne bilde</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="344"/>
        <source>Open Image In New Tab</source>
        <translation>Åpne bilde i ny fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="345"/>
        <location filename="../../src/ui/WebWidget.cpp" line="995"/>
        <source>Open Image in New Background Tab</source>
        <translation>Åpne bilde i ny bakgrunnsfane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="346"/>
        <source>Save Image…</source>
        <translation>Lagre bilde…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="347"/>
        <source>Copy Image to Clipboard</source>
        <translation>Kopier bilde til utklippstavle</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="348"/>
        <source>Copy Image Link to Clipboard</source>
        <translation>Kopier billedlenke til utklippstavle</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="349"/>
        <source>Reload Image</source>
        <translation>Gjeninnlast bilde</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="350"/>
        <source>Image Properties…</source>
        <translation>Bildeegenskaper…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="351"/>
        <source>Save Media…</source>
        <translation>Lagre media…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="352"/>
        <source>Copy Media Link to Clipboard</source>
        <translation>Kopier medialenke til utklippstavle</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="353"/>
        <source>Show Controls</source>
        <translation>Vis skruknotter</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="353"/>
        <source>Show Media Controls</source>
        <translation>Vis mediaskruknotter</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="354"/>
        <source>Looping</source>
        <translation>Gjentagning</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="354"/>
        <source>Playback Looping</source>
        <translation>Avspillingsgjentagelse</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="355"/>
        <location filename="../../src/ui/WebWidget.cpp" line="1076"/>
        <source>Play</source>
        <translation>Spill</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="355"/>
        <source>Play Media</source>
        <translation>Spill media</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="356"/>
        <location filename="../../src/ui/WebWidget.cpp" line="1082"/>
        <source>Mute</source>
        <translation>Steng av lyd</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="356"/>
        <source>Mute Media</source>
        <translation>Demp media</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="357"/>
        <source>Playback Rate</source>
        <translation>Avspillingshastighet</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="358"/>
        <source>Log In</source>
        <translation>Logg inn</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="359"/>
        <source>Go</source>
        <translation>Gå</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="359"/>
        <source>Go to URL</source>
        <translation>Gå til nettadresse</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="360"/>
        <source>Back</source>
        <translation>Tilbake</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="360"/>
        <source>Go Back</source>
        <translation>Gå tilbake</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="361"/>
        <source>Forward</source>
        <translation>Frem</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="361"/>
        <source>Go Forward</source>
        <translation>Gå fremover</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="362"/>
        <location filename="../../src/modules/windows/tabHistory/TabHistoryContentsWidget.cpp" line="142"/>
        <source>Go to History Entry</source>
        <translation>Gå til historikkoppføring</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="363"/>
        <source>Go to Page or Search</source>
        <translation>Gå til siden eller søk</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="364"/>
        <source>Go to Home Page</source>
        <translation>Gå til oppstartsside</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="365"/>
        <source>Go to Parent Directory</source>
        <translation>Gå til overnevnt mappe</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="366"/>
        <source>Rewind</source>
        <translation>Spol tilbake</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="366"/>
        <source>Rewind History</source>
        <translation>Spol tilbake historikk</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="367"/>
        <source>Fast Forward</source>
        <translation>Spol raskt forover</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="368"/>
        <source>Remove History Entry</source>
        <translation>Fjern historikkoppføring</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="369"/>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="370"/>
        <source>Stop Scheduled Page Reload</source>
        <translation>Stopp planlagt sidegjeninnlasting</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="371"/>
        <source>Stop All Pages</source>
        <translation>Stopp alle sider</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="373"/>
        <source>Reload or Stop</source>
        <translation>Gjeninnlast eller stopp</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="374"/>
        <source>Reload and Bypass Cache</source>
        <translation>Gjeninnlast og ikke hent fra hurtiglager</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="375"/>
        <source>Reload All Tabs</source>
        <translation>Gjeninnlast alle faner</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="376"/>
        <source>Schedule Page Reload</source>
        <translation>Planlegg sidegjeninnlasting</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="377"/>
        <source>Show Context Menu</source>
        <translation>Vis kontekstmeny</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="378"/>
        <source>Undo</source>
        <translation>Angre</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="379"/>
        <source>Redo</source>
        <translation>Gjenta</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="380"/>
        <source>Cut</source>
        <translation>Klipp ut</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="381"/>
        <source>Copy</source>
        <translation>Kopier</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="382"/>
        <source>Copy as Plain Text</source>
        <translation>Kopier som vanlig tekst</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="383"/>
        <source>Copy Address</source>
        <translation>Kopier adresse</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="384"/>
        <source>Copy to Note</source>
        <translation>Kopier til notat</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="385"/>
        <source>Paste</source>
        <translation>Lim inn</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="386"/>
        <source>Paste and Go</source>
        <translation>Lim inn og åpne</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="387"/>
        <source>Delete</source>
        <translation>Slett</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="388"/>
        <source>Select All</source>
        <translation>Velg alt</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="389"/>
        <source>Deselect</source>
        <translation>Fravelg</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="390"/>
        <source>Clear All</source>
        <translation>Tøm alt</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="391"/>
        <source>Check Spelling</source>
        <translation>Sjekk staving</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="392"/>
        <source>Find…</source>
        <translation>Finn…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="393"/>
        <source>Find Next</source>
        <translation>Finn neste forekomst</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="394"/>
        <source>Find Previous</source>
        <translation>Finn forrige forekomst</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="395"/>
        <source>Quick Find</source>
        <translation>Raskt søk</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="396"/>
        <location filename="../../src/ui/WebWidget.cpp" line="1266"/>
        <source>Search</source>
        <translation>Søk</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="397"/>
        <source>Create Search…</source>
        <translation>Opprett søk…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="398"/>
        <source>Zoom In</source>
        <translation>Forstørr</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="399"/>
        <source>Zoom Out</source>
        <translation>Forminsk</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="400"/>
        <source>Zoom Original</source>
        <translation>Opprinnelig forstørrelsesnivå</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="401"/>
        <source>Go to Start of the Page</source>
        <translation>Gå til starten på siden</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="402"/>
        <source>Go to the End of the Page</source>
        <translation>Gå til slutten på siden</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="403"/>
        <source>Page Up</source>
        <translation>Page Up</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="404"/>
        <source>Page Down</source>
        <translation>Page Down</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="405"/>
        <source>Page Left</source>
        <translation>Page Left</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="406"/>
        <source>Page Right</source>
        <translation>Page Right</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="407"/>
        <source>Enter Drag Scroll Mode</source>
        <translation>Gå inn i dra-skrollings-modus</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="408"/>
        <source>Enter Move Scroll Mode</source>
        <translation>Gå inn i flytt-skrollings-modus</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="409"/>
        <source>Exit Scroll Mode</source>
        <translation>Gå ut av skrollings-modus</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="410"/>
        <source>Print…</source>
        <translation>Skriv ut…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="411"/>
        <source>Print Preview</source>
        <translation>Forhåndsvisning av utskrift</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="412"/>
        <source>Take Screenshot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="413"/>
        <source>Activate Address Field</source>
        <translation>Aktiver adressefelt</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="414"/>
        <source>Activate Search Field</source>
        <translation>Aktiver søkefelt</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="415"/>
        <source>Activate Content</source>
        <translation>Aktiver innhold</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="416"/>
        <source>Go to Previously Used Tab</source>
        <translation>Gå til tidligere brukt fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="417"/>
        <source>Go to Least Recently Used Tab</source>
        <translation>Gå til sist nylig brukte fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="418"/>
        <source>Activate Tab</source>
        <translation>Aktiver fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="419"/>
        <source>Go to Tab on Left</source>
        <translation>Gå til fane på venstre side</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="420"/>
        <source>Go to Tab on Right</source>
        <translation>Gå til fane på høyre side</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="421"/>
        <source>Activate Window</source>
        <translation>Aktiver vindu</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="422"/>
        <source>Manage Bookmarks</source>
        <translation>Behandle bokmerker</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="423"/>
        <source>Bookmark Page…</source>
        <translation>Bokmerk side…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="424"/>
        <source>Bookmark All Open Pages</source>
        <translation>Bokmerk alle åpne sider</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="425"/>
        <source>Open Bookmark</source>
        <translation>Åpne bokmerke</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="426"/>
        <source>Quick Bookmark Access</source>
        <translation>Rask bokmerketilgang</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="427"/>
        <source>Cookies</source>
        <translation>Informasjonskapsler</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="428"/>
        <source>Load All Plugins on the Page</source>
        <translation>Last inn alle programtillegg på siden</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="429"/>
        <source>Enable JavaScript</source>
        <translation>Skru på JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="430"/>
        <source>Enable Referrer</source>
        <translation>Skru på henvisningsinformasjon (referent)</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="431"/>
        <source>View Source</source>
        <translation>Se kildekode</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="432"/>
        <source>Inspect Page</source>
        <translation>Ta side i nærmere øyesyn</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="433"/>
        <source>Inspect Element…</source>
        <translation>Inspiser element…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="434"/>
        <source>Work Offline</source>
        <translation>Arbeid frakoblet</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="435"/>
        <location filename="../../src/ui/Menu.cpp" line="416"/>
        <source>Full Screen</source>
        <translation>Fullskjerm</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="436"/>
        <source>Show Tab Switcher</source>
        <translation>Vis fanebytter</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="437"/>
        <source>Show Toolbar</source>
        <translation>Vis verktøylinje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="438"/>
        <source>Show Menubar</source>
        <translation>Vis menylinje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="439"/>
        <source>Show Tabbar</source>
        <translation>Vis fanelinje</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="440"/>
        <source>Show Sidebar</source>
        <translation>Vis sidestolpe</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="441"/>
        <source>Show Error Console</source>
        <translation>Vis feil-konsoll</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="442"/>
        <source>Lock Toolbars</source>
        <translation>Lås verktøylinjer</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="443"/>
        <source>Reset to Defaults…</source>
        <translation>Tilbakestill til forvalg…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="443"/>
        <source>Reset Toolbars to Defaults…</source>
        <translation>Tilbakestill verktøyslinjer til forvalg…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="444"/>
        <source>Show Panel</source>
        <translation>Vis panel</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="444"/>
        <source>Show Specified Panel in Sidebar</source>
        <translation>Vis angitt panel i sidestolpe</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="445"/>
        <source>Open Panel as Tab</source>
        <translation>Åpne panel som fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="445"/>
        <source>Open Curent Sidebar Panel as Tab</source>
        <translation>Åpne nåværende sidestolpepanel som fane</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="446"/>
        <source>Content Blocking…</source>
        <translation>Innholdsblokkering…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="447"/>
        <source>View History</source>
        <translation>Se historikk</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="448"/>
        <source>Clear History…</source>
        <translation>Tøm historikk…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="449"/>
        <source>Addons</source>
        <translation>Programtillegg</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="450"/>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="210"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="66"/>
        <source>Notes</source>
        <translation>Notater</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="451"/>
        <source>Passwords</source>
        <translation>Passord</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="452"/>
        <source>Downloads</source>
        <translation>Nedlastinger</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="453"/>
        <source>Preferences…</source>
        <translation>Innstillinger…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="454"/>
        <source>Website Preferences…</source>
        <translation>Nettsideinnstillinger…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="455"/>
        <source>Quick Preferences</source>
        <translation>Hurtiginnstillinger</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="456"/>
        <source>Reset Options</source>
        <translation>Tilbakestill valg</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="457"/>
        <source>Website Information…</source>
        <translation>Nettsideinformasjon…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="458"/>
        <source>Website Certificate Information…</source>
        <translation>Sertifikatinformasjon for nettside…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="459"/>
        <source>Switch Application Language…</source>
        <translation>Bytt programspråk…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="460"/>
        <source>Check for Updates…</source>
        <translation>Se etter oppdateringer…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="461"/>
        <source>Diagnostic Report…</source>
        <translation>Diagnostikkrapport…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="462"/>
        <source>About Otter…</source>
        <translation>Om Oteren…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="463"/>
        <source>About Qt…</source>
        <translation>Om Qt…</translation>
    </message>
    <message>
        <location filename="../../src/core/ActionsManager.cpp" line="464"/>
        <source>Exit</source>
        <translation>Avslutt</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1532"/>
        <source>Set %1</source>
        <translation>Sett %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1536"/>
        <source>Set %1 for %2</source>
        <translation>Sett %1 for %2</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1543"/>
        <source>Reset %1</source>
        <translation>Tilbakestill %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1547"/>
        <source>Reset %1 for %2</source>
        <translation>Tilbakestill %1 for %2</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1556"/>
        <source>Toggle %1</source>
        <translation>Veksle %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="1560"/>
        <source>Toggle %1 for %2</source>
        <translation>Veksle %1 for %2</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="46"/>
        <source>Menu Bar</source>
        <translation>Menylinje</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="47"/>
        <source>Bookmarks Bar</source>
        <translation>Bokmerkelinje</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="48"/>
        <source>Tab Bar</source>
        <translation>Fanelinje</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="49"/>
        <source>Address Bar</source>
        <translation>Adresselinje</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="50"/>
        <source>Navigation Bar</source>
        <translation>Navigasjonslinje</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="51"/>
        <source>Progress Bar</source>
        <translation>Framdriftslinje</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="52"/>
        <source>Sidebar</source>
        <translation>Sidestolpe</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="53"/>
        <source>Status Bar</source>
        <translation>Statuslinje</translation>
    </message>
    <message>
        <location filename="../../src/core/ToolBarsManager.cpp" line="54"/>
        <source>Error Console</source>
        <translation>Feil-konsoll</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="198"/>
        <location filename="../../src/ui/Menu.cpp" line="73"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="54"/>
        <source>Bookmarks</source>
        <translation>Bokmerker</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="202"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="58"/>
        <source>Transfers</source>
        <translation>Overføringer</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/mac/MacPlatformIntegration.mm" line="206"/>
        <location filename="../../src/ui/Menu.cpp" line="60"/>
        <location filename="../../src/ui/TrayIcon.cpp" line="62"/>
        <source>History</source>
        <translation>Historikk</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/bookmarks/BookmarksContentsWidget.cpp" line="366"/>
        <source>Remove Bookmark</source>
        <translation>Fjern bokmerke</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/cookies/CookiesContentsWidget.cpp" line="479"/>
        <source>Remove Cookie</source>
        <translation>Fjern kake</translation>
    </message>
    <message>
        <location filename="../../src/modules/windows/feeds/FeedsContentsWidget.cpp" line="400"/>
        <source>Update</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/modules/windows/notes/NotesContentsWidget.cpp" line="365"/>
        <source>Copy address of source page</source>
        <translation>Kopier adressen til kildekodesiden</translation>
    </message>
    <message>
        <location filename="../../src/ui/MainWindow.cpp" line="2338"/>
        <source>Close Panel</source>
        <translation>Lukk panel</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="57"/>
        <source>File</source>
        <translation>Fil</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="58"/>
        <source>Edit</source>
        <translation>Rediger</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="59"/>
        <source>View</source>
        <translation>Vis</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="61"/>
        <source>Tools</source>
        <translation>Verktøy</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="62"/>
        <source>Help</source>
        <translation>Hjelp</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="63"/>
        <source>Page</source>
        <translation>Side</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="64"/>
        <source>Print</source>
        <translation>Skriv ut</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="65"/>
        <source>Settings</source>
        <translation>Innstillinger</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="66"/>
        <source>Frame</source>
        <translation>Ramme</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="95"/>
        <source>Character Encoding</source>
        <translation>Tegnkoding</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="105"/>
        <source>Closed Tabs and Windows</source>
        <translation>Lukkede faner og vinduer</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="123"/>
        <source>Dictionaries</source>
        <translation>Ordbøker</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="129"/>
        <source>Import and Export</source>
        <translation>Importering og eksportering</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="130"/>
        <source>Import Opera Bookmarks…</source>
        <translation>Importer bokmerker fra Opera…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="131"/>
        <source>Import HTML Bookmarks…</source>
        <translation>Importer HTML-bokmerker…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="133"/>
        <source>Import OPML Feeds…</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="135"/>
        <source>Import Opera Notes…</source>
        <translation>Importer Opera-notater…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="137"/>
        <source>Import Opera Search Engines…</source>
        <translation>Importer søkemotorer fra Opera…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="139"/>
        <source>Import Opera Session…</source>
        <translation>Importer Opera-økt…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="152"/>
        <source>Insert Note</source>
        <translation>Legg til notat</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="166"/>
        <source>Open with</source>
        <translation>Åpne med</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="172"/>
        <source>Proxy</source>
        <translation>Mellomtjener</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="181"/>
        <source>Search Using</source>
        <translation>Søk ved bruk av</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="187"/>
        <source>Sessions</source>
        <translation>Økter</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="200"/>
        <source>Style</source>
        <translation>Stil</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="220"/>
        <source>Toolbars</source>
        <translation>Verktøylinjer</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="226"/>
        <source>User Agent</source>
        <translation>Brukeragent</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="235"/>
        <source>Validate Using</source>
        <translation>Sjekk gyldighet med</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="241"/>
        <source>Tabs and Windows</source>
        <translation>Faner og vinduer</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="404"/>
        <source>Keep Cookie Until</source>
        <translation>Behold kake til</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="408"/>
        <source>Accept Cookies</source>
        <translation>Godta kaker</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="412"/>
        <source>Accept Third-party Cookies</source>
        <translation>Godta tredjepartskaker</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="420"/>
        <source>Geolocation</source>
        <translation>Geografisk plassering</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="424"/>
        <source>Images</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="428"/>
        <source>Capture Audio</source>
        <translation>Ta opp lyd</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="432"/>
        <source>Capture Video</source>
        <translation>Ta opp video</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="436"/>
        <source>Playback Audio</source>
        <translation>Spill av lyd</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="440"/>
        <source>Notifications</source>
        <translation>Merknader</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="444"/>
        <source>Plugins</source>
        <translation>Program-tillegg</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="448"/>
        <source>Pointer Lock</source>
        <translation>Pekerlås</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="452"/>
        <source>Closing Windows by JavaScript</source>
        <translation>Lukker Windows ved bruk av JavaScript</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="456"/>
        <source>Pop-Ups</source>
        <translation>Oppsprettsvinduer</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="624"/>
        <location filename="../../src/ui/Menu.cpp" line="791"/>
        <source>Open All</source>
        <translation>Åpne alle</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="677"/>
        <source>This Folder</source>
        <translation>Denne mappa</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="755"/>
        <source>Ask What to Do</source>
        <translation>Spør hva som skal gjøres</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="759"/>
        <source>Always Allow</source>
        <translation>Alltid tillat</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="763"/>
        <source>Always Deny</source>
        <translation>Alltid nekt</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="767"/>
        <source>Expires</source>
        <translation>Utløper</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="771"/>
        <source>Current Session is Closed</source>
        <translation>Nåværende økt lukket</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="775"/>
        <source>Always</source>
        <translation>Alltid</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="779"/>
        <source>Only Existing</source>
        <translation>Bare eksisterende</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="783"/>
        <source>Only Read Existing</source>
        <translation>Bare les eksisterende</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="787"/>
        <source>Ignore</source>
        <translation>Ignorer</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="795"/>
        <source>Open in Background</source>
        <translation>Åpne i bakgrunnen</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="799"/>
        <source>Block All</source>
        <translation>Blokker alle</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="803"/>
        <source>Only Cached</source>
        <translation>Kun hurtiglagret</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="807"/>
        <source>Enabled</source>
        <translation>Påskrudd</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="811"/>
        <source>On Demand</source>
        <translation>Ved behov</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="815"/>
        <source>Disabled</source>
        <translation>Avskrudd</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="842"/>
        <source>Auto Detect</source>
        <translation>Automatisk oppdaging</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="895"/>
        <source>Clear</source>
        <translation>Tøm</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1053"/>
        <source>Default Application</source>
        <translation>Forvalgt program</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1061"/>
        <source>Unknown</source>
        <translation>Ukjent</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1202"/>
        <source>Default Style</source>
        <translation>Forvalgt stil</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1256"/>
        <source>Add New</source>
        <translation>Legg til ny</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1259"/>
        <source>Add Toolbar…</source>
        <translation>Legg til verktøylinje…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1260"/>
        <source>Add Bookmarks Bar…</source>
        <translation>Legg til bokmerkelinje…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1261"/>
        <source>Add Sidebar…</source>
        <translation>Legg til sidestolpe…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1343"/>
        <source>Custom User Agent…</source>
        <translation>Egentilpasset brukeragent…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Menu.cpp" line="1387"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="955"/>
        <source>Edit Link Bookmark…</source>
        <translation>Rediger lenkens bokmerke…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="987"/>
        <source>Open Image in This Tab</source>
        <translation>Åpne bilde i denne fanen</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="991"/>
        <source>Open Image in New Tab</source>
        <translation>Åpne bilde i ny fane</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="999"/>
        <source>Open Image in New Window</source>
        <translation>Åpne bilde i nytt vindu</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1003"/>
        <source>Open Image in New Background Window</source>
        <translation>Åpne bilde i nytt bakgrunnsvindu</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1007"/>
        <source>Open Image in New Private Tab</source>
        <translation>Åpne bilde i ny privat fane</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1011"/>
        <source>Open Image in New Private Background Tab</source>
        <translation>Åpne bilde i ny privat bakgrunnsfane</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1015"/>
        <source>Open Image in New Private Window</source>
        <translation>Åpne bilde i nytt privat vindu</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1019"/>
        <source>Open Image in New Private Background Window</source>
        <translation>Åpne bilde i nytt privat bakgrunnsvindu</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1056"/>
        <source>Save Video…</source>
        <translation>Lagre video…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1056"/>
        <source>Save Audio…</source>
        <translation>Lagre lyd…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1061"/>
        <source>Copy Video Link to Clipboard</source>
        <translation>Kopier videolenke til utklippstavle</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1061"/>
        <source>Copy Audio Link to Clipboard</source>
        <translation>Kopier lyd-lenke til utklippstavle</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1076"/>
        <source>Pause</source>
        <translation>Pause</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1082"/>
        <source>Unmute</source>
        <translation>Skru på lyd</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1103"/>
        <source>Unmute Tab Media</source>
        <translation>Fjern demping av fane</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1137"/>
        <source>Purge History Entry</source>
        <translation>Tøm historikkoppføring</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1281"/>
        <source>Edit Bookmark…</source>
        <translation>Rediger bokmerke…</translation>
    </message>
    <message>
        <location filename="../../src/ui/WebWidget.cpp" line="1281"/>
        <source>Add Bookmark…</source>
        <translation>Legg til bokmerke…</translation>
    </message>
    <message>
        <location filename="../../src/ui/Window.cpp" line="656"/>
        <source>Unpin Tab</source>
        <translation>Løsne fane</translation>
    </message>
    <message>
        <location filename="../../src/ui/WorkspaceWidget.cpp" line="543"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
</context>
<context>
    <name>addons</name>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="123"/>
        <source>Addons</source>
        <translation>Programtillegg</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="124"/>
        <source>Bookmarks</source>
        <translation>Bokmerker</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="125"/>
        <source>Cache</source>
        <translation>Hurtiglager</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="126"/>
        <source>Advanced Configuration</source>
        <translation>Avansert oppsett</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="127"/>
        <source>Cookies</source>
        <translation>Kaker</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="128"/>
        <source>Feeds</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="129"/>
        <source>History</source>
        <translation>Historikk</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="130"/>
        <source>Links</source>
        <translation>Lenker</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="131"/>
        <source>Notes</source>
        <translation>Notater</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="132"/>
        <source>Page Information</source>
        <translation>Sideinformasjon</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="133"/>
        <source>Passwords</source>
        <translation>Passord</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="134"/>
        <source>Tab History</source>
        <translation>Fanehistorikk</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="135"/>
        <source>Downloads</source>
        <translation>Nedlastinger</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="136"/>
        <source>Windows and Tabs</source>
        <translation>Vinduer og faner</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="105"/>
        <source>Failed to open content blocking profile file: %1</source>
        <translation>Klarte ikke å åpne fil for innholdsblokkeringsprofil: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="604"/>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="632"/>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="645"/>
        <source>Failed to update content blocking profile: %1</source>
        <translation>Klarte ikke å oppdatere innholdsblokkeringsprofil: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="618"/>
        <source>Failed to update content blocking profile: checksum mismatch</source>
        <translation>Klarte ikke å oppdatere innholdsblokkeringsprofil: Sjekksum samsvarer ikke</translation>
    </message>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="885"/>
        <source>Failed to update content blocking profile, update URL is empty</source>
        <translation>Klarte ikke å oppdatere innholdsblokkeringsprofil, oppdateringsnettadressen er tom</translation>
    </message>
    <message>
        <location filename="../../src/core/AdblockContentFiltersProfile.cpp" line="889"/>
        <source>Failed to update content blocking profile, update URL (%1) is invalid</source>
        <translation>Klarte ikke å oppdatere innholdsblokkeringsprofil, oppdateringsnettadressen (%1) er ugyldig</translation>
    </message>
    <message>
        <location filename="../../src/core/AddonsManager.cpp" line="200"/>
        <source>Failed to find User Script file: %1</source>
        <translation>Klarte ikke å åpne brukerskriptfil: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="125"/>
        <source>URL to open</source>
        <translation>Nettadresse å åpne</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="126"/>
        <source>Uses &lt;path&gt; as cache directory</source>
        <translation>Bruker &lt;path&gt; som hurtiglager</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="127"/>
        <source>Uses &lt;path&gt; as profile directory</source>
        <translation>Bruker &lt;path&gt; som profilmappe</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="128"/>
        <source>Restores session &lt;session&gt; if it exists</source>
        <translation>Gjenoppretter økt &lt;session&gt; hvis den finnes</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="129"/>
        <source>Starts private session</source>
        <translation>Starter en privat økt</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="130"/>
        <source>Forces session chooser dialog</source>
        <translation>Påtvinger øktvalgsdialog</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="131"/>
        <source>Sets profile and cache paths to directories inside the same directory as that of application binary</source>
        <translation>Profiler og mellomlager i samme mappe som binærfila til programmet</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="132"/>
        <source>Loads URL in new tab</source>
        <translation>Laster nettadresser i ny fane</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="133"/>
        <source>Loads URL in new private tab</source>
        <translation>Laster nettadresser i ny privat fane</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="134"/>
        <source>Loads URL in new window</source>
        <translation>Laster nettadresser i nytt vindu</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="135"/>
        <source>Loads URL in new private window</source>
        <translation>Laster nettadresser i nytt privat vindu</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="136"/>
        <source>Tells application to avoid writing data to disk</source>
        <translation>Forteller programmet at det skal unngå å skrive data til disk</translation>
    </message>
    <message>
        <location filename="../../src/core/Application.cpp" line="137"/>
        <source>Prints out diagnostic report and exits application</source>
        <translation>Skriver ut diagnostikkrapport og avslutter programmet</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkAutomaticProxy.cpp" line="414"/>
        <source>Failed to parse entry of proxy auto-config (PAC): %1</source>
        <translation>Klarte ikke å tolke oppføring for automatisk oppsett for mellomtjener (PAC): %1</translation>
    </message>
    <message>
        <location filename="../../src/core/PlatformIntegration.cpp" line="135"/>
        <source>Failed to install update
Updater: %1
Script: %2</source>
        <translation>Klarte ikke å installere oppdatering
Oppdaterer: %1
Skript: %2</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionsManager.h" line="161"/>
        <source>Start Page</source>
        <translation>Startside</translation>
    </message>
    <message>
        <location filename="../../src/core/SessionsManager.h" line="165"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
    <message>
        <location filename="../../src/core/UpdateChecker.cpp" line="44"/>
        <source>Unable to check for updates. Invalid URL: %1</source>
        <translation>Klarte ikke å se etter oppdateringer. Ugyldig nettadresse: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/UpdateChecker.cpp" line="62"/>
        <source>Unable to check for updates: %1</source>
        <translation>Klarte ikke å se etter oppdateringer: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/UpdateChecker.cpp" line="95"/>
        <source>Unable to parse version number: %1</source>
        <translation>Klarte ikke å tolke versjonsnummer: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Updater.cpp" line="84"/>
        <source>Downloaded update script is not valid: %1</source>
        <translation>Nedlastet oppdateringsskript er ikke gyldig: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Updater.cpp" line="104"/>
        <source>Unable to download update: %1</source>
        <translation>Kunne ikke laste ned oppdatering: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/UserScript.cpp" line="65"/>
        <source>Failed to open User Script file: %1</source>
        <translation>Klarte ikke å åpne brukerskriptfil: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/UserScript.cpp" line="151"/>
        <source>Invalid match rule for User Script: %1</source>
        <translation>Ugyldig jamføringsregel for brukerskript: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/UserScript.cpp" line="228"/>
        <source>Failed to locate header of User Script file</source>
        <translation>Klarte ikke å finne hode i brukerskriptfil</translation>
    </message>
    <message>
        <location filename="../../src/main.cpp" line="163"/>
        <source>Default</source>
        <translation>Forvalg</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEnginePage.cpp" line="80"/>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineUrlRequestInterceptor.cpp" line="157"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="691"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="249"/>
        <source>Request blocked by rule from profile %1:
%2</source>
        <translation>Forespørsel blokkert av regel fra profil %1:
%2</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebengine/QtWebEngineUrlRequestInterceptor.cpp" line="157"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitNetworkManager.cpp" line="691"/>
        <source>(Unknown)</source>
        <translation>(Ukjent)</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="503"/>
        <source>Failed to run File Associations Manager, error code: %1
Application ID: %2</source>
        <translation>Kunne ikke kjøre filassosiasjonsbehandler, feilkode: %1
Program-ID: %2</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="522"/>
        <source>Failed to run File Associations Manager, error code: %1</source>
        <translation>Kunne ikke kjøre filassosiasjonsbehandler, feilkode: %1</translation>
    </message>
    <message>
        <location filename="../../src/modules/platforms/windows/WindowsPlatformIntegration.cpp" line="577"/>
        <source>Failed to register application to system registry: %1, %2</source>
        <translation>Klarte ikke å registrere program til systemregister: %1, %2</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="211"/>
        <source>Failed to load custom rules: invalid adblock header</source>
        <translation>Klarte ikke å laste egendefinerte regler: Ugyldig reklameblokkeringshode</translation>
    </message>
    <message>
        <location filename="../../src/ui/preferences/ContentBlockingDialog.cpp" line="519"/>
        <source>Failed to create a file with custom rules: %1</source>
        <translation>Klarte ikke å opprette fil med egendefinerte regler: %1</translation>
    </message>
</context>
<context>
    <name>migrations</name>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="193"/>
        <source>Keyboard and Mouse Configuration Profiles</source>
        <translation>Tastatur- og muse-oppsettsprofiler</translation>
    </message>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="327"/>
        <source>Options</source>
        <translation>Valg</translation>
    </message>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="363"/>
        <source>Search Engines</source>
        <translation>Søkemotorer</translation>
    </message>
    <message>
        <location filename="../../src/core/Migrator.cpp" line="486"/>
        <source>Sessions</source>
        <translation>Økter</translation>
    </message>
</context>
<context>
    <name>notifications</name>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="87"/>
        <source>Feed Updated</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="87"/>
        <source>Feed update was completed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="88"/>
        <source>Download Completed</source>
        <translation>Nedlasting fullført</translation>
    </message>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="88"/>
        <source>File download was completed</source>
        <translation>Filnedlasting fullført</translation>
    </message>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="89"/>
        <source>Update Available</source>
        <translation>Oppdatering tilgjengelig</translation>
    </message>
    <message>
        <location filename="../../src/core/NotificationsManager.cpp" line="89"/>
        <source>Update is available to be downloaded</source>
        <translation>Oppgradering tilgjengelig for nedlasting</translation>
    </message>
</context>
<context>
    <name>proxies</name>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.cpp" line="693"/>
        <location filename="../../src/core/NetworkManagerFactory.h" line="90"/>
        <source>System Configuration</source>
        <translation>Systemoppsett</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.h" line="85"/>
        <source>No Proxy</source>
        <translation>Ingen mellomtjener</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.h" line="94"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
</context>
<context>
    <name>userAgents</name>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.cpp" line="582"/>
        <location filename="../../src/core/NetworkManagerFactory.cpp" line="723"/>
        <location filename="../../src/core/NetworkManagerFactory.h" line="118"/>
        <source>Default User Agent</source>
        <translation>Forvalgt brukeragent</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.h" line="123"/>
        <source>Mask as {name}</source>
        <translation>Masker som {name}</translation>
    </message>
    <message>
        <location filename="../../src/core/NetworkManagerFactory.h" line="127"/>
        <source>(Untitled)</source>
        <translation>(Uten tittel)</translation>
    </message>
</context>
<context>
    <name>utils</name>
    <message>
        <location filename="../../src/core/LocalListingNetworkReply.cpp" line="52"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitFtpListingNetworkReply.cpp" line="61"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="922"/>
        <source>Try Again</source>
        <translation>Prøv igjen</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="185"/>
        <source>You tried to access the address &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;, which was blocked by content blocker.</source>
        <translation>Du prøvde å nå adressen &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;, som ble blokkert av innholdsblokkering.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="189"/>
        <source>The owner of &lt;strong&gt;%1&lt;/strong&gt; has configured their page improperly. To protect your information from being stolen, connection to this website was aborted.</source>
        <translation>Eieren av &lt;strong&gt;%1&lt;/strong&gt; har ikke satt opp siden sin ordentlig. For å beskytte din informasjon fra å bli stjålet, ble tilkoblingen til denne nettsiden avbrutt.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="193"/>
        <source>This web page at &lt;strong&gt;%1&lt;/strong&gt; has been reported as a web forgery. To protect your information from being stolen, connection to this website was aborted.</source>
        <translation>Denne siden på &lt;strong&gt;%1&lt;/strong&gt; har blitt rapporter som en nettsvindel. For å beskytte din informasjon fra tyveri, har tilkoblingen til denne nettsiden blitt avbrutt.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="197"/>
        <source>You tried to access the address &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;, which is currently unavailable. Please make sure that the web address (URL) is correctly spelled and punctuated, then try reloading the page.</source>
        <translation>Du prøvde å nå adressen &lt;a href=&quot;%1&quot;&gt;%1&lt;/a&gt;, som for tiden er utilgjengelig. Forsikre at nettadressen (URL) er skrevet rett, for så å laste inn siden på nytt.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="201"/>
        <source>Check the file name for capitalization or other typing errors.</source>
        <translation>Sjekk at filnavnet for stor bokstav og andre skrivefeil.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="201"/>
        <source>Check to see if the file was moved, renamed or deleted.</source>
        <translation>Sjekk hvorvidt fila ble flyttet, gitt nytt navn, eller slettet.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="205"/>
        <source>Check the address for typing errors.</source>
        <translation>Sjekk adresse for skrivefeil.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="205"/>
        <source>Make sure your internet connection is active and check whether other applications that rely on the same connection are working.</source>
        <translation>Forsikre deg om at din internettilknytning er aktiv og sjekk hvorvidt andre programmer som belager seg på samme tilkobling fungerer.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="205"/>
        <source>Check that the setup of any internet security software is correct and does not interfere with ordinary web browsing.</source>
        <translation>Sjekk hvorvidt oppsettet av enhver kjørende internettsikkerhetsprogramvare har blitt gjort rett, og ikke forulemper vanlig surfing.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="205"/>
        <source>Try pressing the F12 key on your keyboard and disabling proxy servers, unless you know that you are required to use a proxy to connect to the internet, and then reload the page.</source>
        <translation>Prøv å trykke F12 på tastaturet ditt for å skru av mellomtjeneren, med mindre du vet at du trenger en mellomtjener for å koble til Internett, for så å laste inn siden igjen.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="216"/>
        <source>Address blocked</source>
        <translation>Adresse blokkert</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="220"/>
        <source>Connection is insecure</source>
        <translation>Usikret tilkobling</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="224"/>
        <source>Connection refused</source>
        <translation>Tilkobling nektet</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="228"/>
        <source>File not found</source>
        <translation>Fil ikke funnet</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="232"/>
        <source>Fraud attempt</source>
        <translation>Svindelforsøk</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="236"/>
        <source>Server not found</source>
        <translation>Tjener ikke funnet</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="240"/>
        <source>Unsupported address type</source>
        <translation>Ustøttet adressetype</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="244"/>
        <source>Network error</source>
        <translation>Nettverksfeil</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="279"/>
        <source>Advanced</source>
        <translation>Avansert</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="322"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="423"/>
        <source>Today at %1</source>
        <translation>I dag klokka %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="428"/>
        <source>Yesterday at %1</source>
        <translation>I går klokka %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="434"/>
        <source>%1 at %2</source>
        <translation>%1 på %2</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="474"/>
        <location filename="../../src/core/Utils.cpp" line="481"/>
        <location filename="../../src/core/Utils.cpp" line="551"/>
        <location filename="../../src/core/Utils.cpp" line="617"/>
        <source>All files (*)</source>
        <translation>Alle filer (*)</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="555"/>
        <source>Open Files</source>
        <translation>Åpne filer</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="559"/>
        <source>Open File</source>
        <translation>Åpne fil</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="613"/>
        <source>%1 files (*.%2)</source>
        <translation>%1 filer (*.%2)</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="623"/>
        <source>Save File</source>
        <translation>Lagre fil</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="645"/>
        <location filename="../../src/core/Utils.cpp" line="654"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="645"/>
        <source>This path is already used by different download, pick another one.</source>
        <translation>Samme filnavn i samme mappe brukes allerede av en annen nedlasting, velg noe annet.</translation>
    </message>
    <message>
        <location filename="../../src/core/Utils.cpp" line="654"/>
        <source>Target path is not writable.
Select another one.</source>
        <translation>Målmappe er ikke skrivbar.
Velg en annen.</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="890"/>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="906"/>
        <source>Go Back</source>
        <translation>Gå tilbake</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="895"/>
        <source>Load Blocked Page</source>
        <translation>Last blokkert side</translation>
    </message>
    <message>
        <location filename="../../src/modules/backends/web/qtwebkit/QtWebKitPage.cpp" line="911"/>
        <source>Load Insecure Page</source>
        <translation>Last usikker side</translation>
    </message>
</context>
</TS>